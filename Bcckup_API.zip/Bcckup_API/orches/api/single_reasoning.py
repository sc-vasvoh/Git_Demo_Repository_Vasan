import os
import json
import argparse
import time
import re
from datetime import datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from typing import Dict, List, Any, Optional, Tuple
import dotenv
from openai import OpenAI
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from tqdm import tqdm
dotenv.load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
INPUT_FILE: Optional[str] = None
OUTPUT_FILE: Optional[str] = None
MAX_WORKERS: int = 5
TOP_K: int = 20
START_INDEX: int = 0
API_KEY: str = OPENAI_API_KEY

def extract_json_safe(json_string: str) -> Dict[str, str]:

    try:
        return json.loads(json_string)
    except json.JSONDecodeError:
        pass
    
    try:
        last_brace = json_string.rfind('}')
        if last_brace != -1:
            truncated = json_string[:last_brace + 1]
            return json.loads(truncated)
    except json.JSONDecodeError:
        pass
    
    try:
        result = {}
        pattern = r'"([^"]+)"\s*:\s*"((?:[^"\\]|\\.)*)"'
        matches = re.findall(pattern, json_string)
        
        for key, value in matches:
            value = value.replace('\\"', '"').replace('\\n', '\n').replace('\\\\', '\\')
            result[key] = value
        
        if result:
            return result
    except Exception as e:
        print(f"⚠️ Regex extraction failed: {e}")

    try:
        start = json_string.find('{')
        end = json_string.rfind('}')
        if start != -1 and end != -1 and end > start:
            candidate = json_string[start:end + 1]
            return json.loads(candidate)
    except:
        pass
    
    print(f"⚠️ All JSON extraction strategies failed. Returning empty dict.")
    return {}

class OpenAIProcessor:
    
    def __init__(self, api_key: str):
        self.client = OpenAI(api_key=api_key)
    
    @retry(
        retry=retry_if_exception_type((Exception)),
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=4, max=60),
        reraise=True
    )
    def call_gpt4_mini_with_retry(self, messages: List[Dict[str, str]]) -> str:
        """
        Call GPT-4o-mini with retry logic for rate limits
        
        Args:
            messages: List of message dictionaries for chat completion
            
        Returns:
            Response content as string
        """
        try:
            response = self.client.chat.completions.create(
                model="gpt-4.1-mini",
                messages=messages,
                temperature=0.0,
                max_tokens=4000,
                response_format={"type": "json_object"}
            )
            return response.choices[0].message.content
        except Exception as e:
            if "rate_limit" in str(e).lower() or "quota" in str(e).lower():
                print(f"⚠️ Rate limit/quota hit, retrying... Error: {e}")
                raise  # Will trigger retry
            else:
                print(f"✗ Error calling API: {e}")
                raise
    
    def create_reasoning_prompt(self, record: Dict) -> str:
        """
        Create a prompt for GPT-4o-mini to generate structured reasoning for one-to-one product match validation.
        This validates a single candidate against a query product.
        
        Args:
            record: Dictionary containing both query product and candidate match info
            
        Returns:
            Formatted prompt string
        """
        
        prompt = f"""You are a product matching expert validating matches for Ferguson company products.

**YOUR TASK:**
Perform a detailed one-to-one comparison between the branded product and the matched product below. Provide clear reasoning explaining whether this is a valid match and why.

**BRANDED PRODUCT (Query Product):**
- ID: {record.get('query_product_id', 'N/A')}
- Description: {record.get('query_product_description', 'N/A')}

**MATCHED PRODUCT TO VALIDATE:**
- ID: {record.get('product_id', 'N/A')}
- Matched Description: {record.get('ob_complete_product_description', 'N/A')}
- Match Score: {record.get('match_perc', 'N/A')} (use as reference only, not as sole judgment)

**EVALUATION CRITERIA (in priority order):**
1. **Product Type/Category** - Are they the same type of product? (highest importance)
2. **Key Dimensions** - Do critical measurements match? Include exact values and units
3. **Material** - Are materials compatible or identical?
4. **Color/Finish** - Do finishes align?
5. **Technical Specifications** - Do other specs match?

**IMPORTANT INSTRUCTIONS:**
- DO NOT rely solely on the match score - judge based on actual product details
- Compare the products objectively using the criteria above
- **Use structured format with "Matches" and "Differs" sections with bullet points**
- **Focus on factual comparison** - state what matches and what differs
- **DO NOT use subjective judgments** like "valid/invalid match", "perfect match", or "strong match"
- Let the match score indicate strength - your job is to explain the similarities and differences
- Be specific with measurements (e.g., "1 in vs 3/4 in", "Schedule 40 vs Schedule 80")
- **KEEP TOTAL REASONING UNDER 60 WORDS - be concise and direct**
- **Use 1-3 bullet points per section maximum**

**OUTPUT FORMAT - STRUCTURED WITH BULLETS:**

Use this format:
**Matches**
- [alignment point 1]
- [alignment point 2 if needed]

**Differs**
- [difference 1 with specifics]
- [difference 2 if needed]

✅ GOOD EXAMPLES (Various Product Types):

Example 1 - Pipes:
**Matches**
- Both are 2 in diameter PVC pipes with white finish

**Differs**
- Query product is Schedule 40; matched product is Schedule 80 (thicker walls, higher pressure rating)

Example 2 - Faucets:
**Matches**
- Both are single-handle stainless steel kitchen faucets
- Brushed nickel finish

**Differs**
- Spout reach: query product 8 in; matched product 6 in

Example 3 - Hoses:
**Matches**
- Both are 50 ft garden hoses with 5/8 in diameter

**Differs**
- Material: query product is rubber; matched product is vinyl (different durability)

Example 4 - HVAC Registers:
**Matches**
- Both are 10 in x 10 in white HVAC registers

**Differs**
- Matched product specifies steel with 1-way airflow
- Query product lacks material and airflow details

Example 5 - Water Heaters:
**Matches**
- Both are tankless water heaters rated at 199,000 BTU

**Differs**
- Fuel type: query product uses natural gas; matched product uses propane

Example 6 - Cleaning Brushes:
**Matches**
- Both are cleaning brushes with wood handles
- Carbon steel bristles

**Differs**
- Diameter: query product 1 in; matched product 3/4 in inside / 7/8 in outside

Example 7 - LED Lights:
**Matches**
- Both are 4 in LED recessed lights with 3000K color temperature
- White finish

**Differs**
- Wattage: query product 9W; matched product 12W

Example 8 - Valves (Type Mismatch):
**Matches**
- Both are 1/2 in brass fittings

**Differs**
- Query product is ball valve; matched product is gate valve (different product types)

❌ AVOID:
- "This is a valid match" or "This is not a valid match"
- "Perfect match" or "Poor match" or "Strong match"
- "I recommend this product" or "This should work"
- Making conclusions about suitability - just state the facts

**GUIDELINES:**
- **Matches section:** List product type, material, dimensions, and finish that align
- **Differs section:** List key differences with specific measurements or specifications
- Use 1-3 bullets per section
- Keep under 60 words total
- Be direct and factual
- Always refer to products as "query product" and "matched product"

**OUTPUT JSON FORMAT:**
Return ONLY valid JSON in this exact format:
{{
  "{record.get('product_id', 'unknown')}": "**Matches**\n- [detail]\n- [detail]\n\n**Differs**\n- [detail]\n- [detail]"
}}

"""
        
        return prompt

class ProgressTracker:
    """Thread-safe progress tracker"""
    
    def __init__(self, total: int):
        self.total = total
        self.success_count = 0
        self.error_count = 0
        self.partial_count = 0
        self.lock = Lock()
        self.start_time = time.time()
    
    def increment_success(self):
        with self.lock:
            self.success_count += 1
    
    def increment_error(self):
        with self.lock:
            self.error_count += 1
    
    def increment_partial(self):
        with self.lock:
            self.partial_count += 1
    
    def get_stats(self) -> Dict[str, Any]:
        with self.lock:
            elapsed = time.time() - self.start_time
            processed = self.success_count + self.error_count
            return {
                'total': self.total,
                'processed': processed,
                'success': self.success_count,
                'errors': self.error_count,
                'partial': self.partial_count,
                'elapsed': elapsed,
                'avg_time': elapsed / processed if processed > 0 else 0
            }

def process_single_product(
    record: Dict,
    index: int,
    api_processor: OpenAIProcessor,
    progress_tracker: ProgressTracker
) -> Tuple[int, bool, int]:
    """
    Process a single product record with one-to-one validation.
    
    Args:
        record: Dictionary containing query product and candidate match
        index: Index of the record
        api_processor: OpenAI API processor
        progress_tracker: Progress tracker
        
    Returns:
        Tuple of (index, success, matches_processed)
    """
    
    query_id = record.get('query_product_id', 'Unknown')
    product_id = record.get('product_id', 'Unknown')
    
    try:
        prompt = api_processor.create_reasoning_prompt(record)
        print(prompt)
        messages = [
            {
                "role": "system",
                "content": "You are an expert at analyzing product matches for Ferguson company products. Provide structured, concise reasoning."
            },
            {
                "role": "user",
                "content": prompt
            }
        ]
        
        response = api_processor.call_gpt4_mini_with_retry(messages)
        structured_reasons = extract_json_safe(response)
        
        # Add structured reasoning to the record
        if product_id in structured_reasons:
            record['structured_reason'] = structured_reasons[product_id]
            progress_tracker.increment_success()
            return (index, True, 1)
        else:
            record['structured_reason'] = "Reasoning not available"
            progress_tracker.increment_partial()
            progress_tracker.increment_success()
            return (index, True, 0)
        
    except Exception as e:
        record['structured_reason'] = f"Error generating reasoning: {str(e)}"
        progress_tracker.increment_error()
        return (index, False, 0)


def process_batch_threaded(
    data: List[Dict],
    api_processor: OpenAIProcessor
) -> Dict[str, Any]:
    """
    Process a batch of records in parallel.
    Each record contains query product and candidate match for one-to-one validation.
    
    Args:
        data: List of records to process
        api_processor: OpenAI API processor
        
    Returns:
        Updated data with structured reasoning
    """
    total = len(data) - START_INDEX
    progress_tracker = ProgressTracker(total)

    print(f"\n{'='*70}")
    print(f"Starting parallel processing with {MAX_WORKERS} workers")
    print(f"Processing {total} records (indices {START_INDEX} to {len(data)-1})")
    print(f"Mode: One-to-one product match validation")
    print(f"{'='*70}\n")
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(
                process_single_product,
                data[i],
                i,
                api_processor,
                progress_tracker
            ): i for i in range(START_INDEX, len(data))
        }

        with tqdm(total=total, desc="Processing", unit="record") as pbar:
            for future in as_completed(futures):
                try:
                    index, success, matches_processed = future.result()
                    pbar.update(1)
                    
                    stats = progress_tracker.get_stats()
                    pbar.set_postfix({
                        'Success': stats['success'],
                        'Errors': stats['errors'],
                        'Avg Time': f"{stats['avg_time']:.1f}s"
                    })
                    
                except Exception as e:
                    print(f"\n✗ Unexpected error in thread: {e}")
                    pbar.update(1)
    
    final_stats = progress_tracker.get_stats()
    print(f"\n{'='*70}")
    print(f"PROCESSING COMPLETE")
    print(f"{'='*70}")
    print(f"Total Records: {final_stats['total']}")
    print(f"Successfully Processed: {final_stats['success']}")
    print(f"Errors: {final_stats['errors']}")
    print(f"Partial Success: {final_stats['partial']}")
    print(f"Total Time: {final_stats['elapsed']/60:.1f} minutes")
    print(f"Average Time per Record: {final_stats['avg_time']:.1f} seconds")
    print(f"{'='*70}\n")
    
    return data
