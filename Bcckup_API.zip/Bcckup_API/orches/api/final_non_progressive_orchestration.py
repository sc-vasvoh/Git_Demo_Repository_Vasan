import json
import os
import sys
import logging
import concurrent.futures
from datetime import datetime
from tqdm import tqdm
import numpy as np
sys.path.append(os.path.abspath(os.path.join(os.getcwd(), "..")))
from reranking.llm_exact_match_reranker import LLMExactMatchReranker
max_workers = 16

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
logger = logging.getLogger(__name__)

def check(a, b, c):
    logger.info("="*80)
    logger.info("Starting Analysis 2 Pipeline")
    logger.info("="*80)
    
    files_only_json = [a, b, c]
    json_files = []
    
    pipeline_data = {}
    for index, jsons in enumerate(files_only_json):
        data = jsons
        fname = f"pipeline_{index}"
        json_files.append(fname)
        pipeline_data[fname] = data
        logger.info(f"Loaded {os.path.basename(fname)}: {len(data)} products")
    
    logger.info("\nStep 3: Combining top 50 matches from all 3 pipelines...")
    
    combined_matches = {}
    unique_pairs = set()
    
    # Collect unique (branded_id, correct_ob_id) pairs from all files
    for fname in json_files:
        for prod in pipeline_data[fname]:
            logger.info(f"\n{prod}")
            branded_id = prod.get('product_id', prod.get('id'))
            unique_pairs.add(branded_id)
    
    # Convert set to list for further processing
    unique_pairs = list(unique_pairs)
    logger.info(f"Found {len(unique_pairs)} unique branded_id")
    
    before_dedup_lens = []
    for branded_id in unique_pairs:
        all_matches = []
        for fname in json_files:
            # Find the product in the file with this branded_id
            prod2 = next((p for p in pipeline_data[fname] if p.get('product_id', p.get('id')) == branded_id), None)
            if prod2:
                matches = prod2.get('raw_matches', prod2.get('top_matches', []))
                all_matches.extend(matches)
        before_dedup_lens.append(len(all_matches))
        # Remove duplicate matches by product_id or id
        seen = set()
        unique_matches = []
        for m in all_matches:
            pid = m.get('product_id', m.get('id'))
            if pid not in seen:
                seen.add(pid)
                unique_matches.append(m)
        combined_matches[branded_id] = unique_matches
    
    # Show distribution before deduplication
    logger.info(f"\nBefore deduplication:")
    logger.info(f"  Min number of matches: {min(before_dedup_lens)}")
    logger.info(f"  Max number of matches: {max(before_dedup_lens)}")
    logger.info(f"  Mean number of matches: {np.mean(before_dedup_lens):.2f}")
    
    # Show the distribution of the number of matches per branded_id after deduplication
    lens = [len(matches) for matches in combined_matches.values()]
    logger.info(f"\nAfter deduplication:")
    logger.info(f"  Min number of unique matches: {min(lens)}")
    logger.info(f"  Max number of unique matches: {max(lens)}")
    logger.info(f"  Mean number of unique matches: {np.mean(lens):.2f}")


    logger.info(f"\nStep 4: Reranking all matches using LLM reranker (max_workers={max_workers})...")
    
    llm_reranker = LLMExactMatchReranker()
    reranked_results = {}
    
    # Helper function for reranking one product
    def rerank_one(branded_id):
        matches = combined_matches[branded_id]
        seen = set()
        unique_matches = []
        for m in matches:
            pid = m.get('product_id', m.get('id'))
            if pid not in seen:
                seen.add(pid)
                unique_matches.append(m)
        query_text = None
        for fname in json_files:
            prod = next((p for p in pipeline_data[fname] if p.get('product_id', p.get('id')) == branded_id), None)
            if prod:
                query_text = prod.get('product_description', prod.get('query_text', ''))
                break
        logger.info(f"Reranking {branded_id} with {len(unique_matches)} unique matches")
        reranked = llm_reranker.rerank(branded_id, query_text, unique_matches, top_n=len(unique_matches))
        logger.info(f"Completed {branded_id}")
        return branded_id, reranked
    
    logger.info(f"Starting parallel reranking for {len(combined_matches)} products...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(rerank_one, branded_id): branded_id for branded_id in combined_matches}
        for future in tqdm(concurrent.futures.as_completed(futures), total=len(futures), desc="Reranking products"):
            branded_id, reranked = future.result()
            reranked_results[branded_id] = reranked
    return reranked_results