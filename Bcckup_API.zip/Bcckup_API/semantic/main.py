"""
Main pipeline for Ferguson Product Matching
Orchestrates data loading, indexing, search, and evaluation
"""

import argparse
import logging
import os
import time
from datetime import datetime

from common import config
from data_processing.data_loader import DataLoader
from search_engine.indexer import ProductIndexer
from search_engine.search import ProductSearcher
from evaluation.evaluator import ProductEvaluator


def setup_logging():
    """Setup logging configuration"""
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    
    logging.basicConfig(
        level=getattr(logging, config.LOG_LEVEL),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler()
        ]
    )


def build_index(force_rebuild=False):
    """
    Build or load product index
    
    Args:
        force_rebuild: If True, rebuild index even if it exists
    """
    logger = logging.getLogger(__name__)
    
    # Check if index already exists
    index_exists = os.path.exists(config.INDEX_PERSIST_DIR) and \
                   os.path.exists(os.path.join(config.INDEX_PERSIST_DIR, config.FAISS_INDEX_FILE))
    
    if index_exists and not force_rebuild:
        logger.info("Index already exists. Loading from disk...")
        indexer = ProductIndexer()
        indexer.load_index()
        return indexer
    
    logger.info("Building new index...")
    
    # Start total indexing timer
    total_start_time = time.time()
    
    # Load data
    logger.info("Step 1: Loading data...")
    loader = DataLoader()
    loader.load_all_data()
    
    stats = loader.get_stats()
    logger.info(f"Data loaded: {stats}")
    
    # Prepare documents
    logger.info("Step 2: Preparing documents for indexing...")
    documents = loader.prepare_ob_documents()
    logger.info(f"Total documents prepared for indexing: {len(documents)}")
    
    # Build index
    logger.info("Step 3: Building index...")
    index_start_time = time.time()
    
    indexer = ProductIndexer()
    indexer.build_index(documents)
    
    index_elapsed = time.time() - index_start_time
    logger.info(f"Index built in {index_elapsed:.2f} seconds ({index_elapsed/60:.2f} minutes)")
    
    # Save index
    logger.info("Step 4: Saving index to disk...")
    indexer.save_index()
    
    # Total time
    total_elapsed = time.time() - total_start_time
    logger.info(f"=" * 60)
    logger.info(f"TOTAL INDEXING TIME: {total_elapsed:.2f} seconds ({total_elapsed/60:.2f} minutes)")
    logger.info(f"=" * 60)
    
    return indexer

# Load data
loader_api = DataLoader()
loader_api.load_all_data()
indexer_api = ProductIndexer()
indexer_api.load_index()
searcher_api = ProductSearcher(indexer_api)
searcher_api.load_reranker()
searcher_api.load_llm_exact_match_reranker()

def run_evaluation_api(row, use_feature_reranking=True):
    """
    Run evaluation on the product matching pipeline

    Args:
        indexer: ProductIndexer instance
        use_reranking: Whether to use reranking
    """
    logging.basicConfig(
        level=getattr(logging, config.LOG_LEVEL),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler()
        ]
    )
    queries_final_from_enrich = loader_api.get_queries_from_input_one(row)
    print(f"INPUT QUERY - {queries_final_from_enrich}")
    # search_result = searcher_api.search(
    #     queries_final_from_enrich["text"],
    #     top_k=config.DEFAULT_SIMILARITY_TOP_K,
    #     use_reranking=use_reranking,
    #     hierarchy_level1 = queries_final_from_enrich["hierarchy_level1"],
    #     hierarchy_level2 = queries_final_from_enrich["hierarchy_level2"],
    #     query_id = queries_final_from_enrich["product_id"]
    # )
    print("YES")
    search_result = searcher_api.search(
        queries_final_from_enrich["text"],
        top_k=config.DEFAULT_SIMILARITY_TOP_K,
        use_feature_reranking= True,
        hierarchy_level1 = queries_final_from_enrich["hierarchy_level1"],
        hierarchy_level2 = queries_final_from_enrich["hierarchy_level2"],
        query_id = queries_final_from_enrich["branded_product_id"],
        query_dimensions= queries_final_from_enrich["dimension_extracted"],
        query_description=queries_final_from_enrich["description"],
        query_web_display_name=queries_final_from_enrich["web_display_name"]
    )

    return search_result, queries_final_from_enrich["description"]

def run_evaluation_api_all(df, use_feature_reranking=True):
    """
    Run evaluation on the product matching pipeline

    Args:
        indexer: ProductIndexer instance
        use_reranking: Whether to use reranking
    """
    logging.basicConfig(
        level=getattr(logging, config.LOG_LEVEL),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler()
        ]
    )
    queries_final_from_enrich_all, des_des, i_to_q = loader_api.get_queries_from_input_all(df)

    print(f"INPUT QUERY - \n{queries_final_from_enrich_all}")

    search_results = searcher_api.batch_search(
        queries_final_from_enrich_all,
        top_k=config.DEFAULT_SIMILARITY_TOP_K,
        use_feature_reranking=use_feature_reranking,
        use_batch_embeddings=config.USE_BATCH_EMBEDDINGS,
        use_parallel=config.USE_PARALLEL_SEARCH
    )

    return search_results, des_des, i_to_q

def run_evaluation(indexer, use_feature_reranking=True):
    """
    Run evaluation on the product matching pipeline
    
    Args:
        indexer: ProductIndexer instance
        use_feature_reranking: Whether to use reranking
    """
    logger = logging.getLogger(__name__)
    
    # Start total evaluation timer
    total_eval_start = time.time()
    
    # Load data
    logger.info("Loading data for evaluation...")
    loader = DataLoader()
    loader.load_all_data()
    
    # Get queries and ground truth efficiently - only loads branded products with ground truth
    logger.info("Building queries from ground truth (only loading needed branded products)...")
    queries_with_gt, ground_truth = loader.get_queries_from_ground_truth()
    
    logger.info(f"=" * 60)
    logger.info(f"EVALUATION DATASET:")
    logger.info(f"  Products with ground truth: {len(queries_with_gt)}")
    logger.info(f"  Ground truth mappings: {len(ground_truth)}")
    logger.info(f"=" * 60)
    
    # Initialize searcher
    searcher = ProductSearcher(indexer)
    if use_feature_reranking:
        searcher.load_reranker()
    
    # Load LLM exact match reranker if enabled
    searcher.load_llm_exact_match_reranker()
    
    # Run batch search
    logger.info("Running batch search...")
    logger.info(f"Batch embedding optimization: {'ENABLED ✅' if config.USE_BATCH_EMBEDDINGS else 'DISABLED'}")
    logger.info(f"Parallel processing: {'ENABLED ✅ (' + str(config.SEARCH_WORKERS) + ' workers)' if config.USE_PARALLEL_SEARCH else 'DISABLED'}")
    search_start_time = time.time()
    
    search_results = searcher.batch_search(
        queries_with_gt,
        top_k=config.DEFAULT_SIMILARITY_TOP_K,
        use_feature_reranking=use_feature_reranking,
        use_batch_embeddings=config.USE_BATCH_EMBEDDINGS,
        use_parallel=config.USE_PARALLEL_SEARCH
    )
    
    search_elapsed = time.time() - search_start_time
    logger.info(f"Search completed in {search_elapsed:.2f} seconds ({search_elapsed/60:.2f} minutes)")
    logger.info(f"Average time per query: {search_elapsed/len(queries_with_gt):.3f} seconds")
    
    # Flush query dimension logs to file (save all at once for performance)
    if config.USE_DIMENSION_FILTERING:
        from data_processing.dimension_extractor import flush_dimension_logs
        flush_dimension_logs()
    
    # Verify what batch_search returned
    logger.info("=" * 80)
    logger.info("🔍 VERIFICATION - What did batch_search return?")
    logger.info(f"Total queries in search_results: {len(search_results)}")
    
    # Check first 3 queries
    for i, (query_id, results) in enumerate(list(search_results.items())[:3]):
        logger.info(f"\nQuery {i+1} (ID: {query_id}):")
        logger.info(f"  Number of results: {len(results)}")
        if results:
            first_result = results[0]
            logger.info(f"  Top result keys: {list(first_result.keys())}")
            logger.info(f"  Has rerank_score: {'rerank_score' in first_result}")
            if 'rerank_score' in first_result:
                logger.info(f"  Top 3 with scores:")
                for j, r in enumerate(results[:3]):
                    logger.info(f"    {j+1}. Product {r.get('product_id', 'N/A')} - FAISS: {r.get('score', 'N/A'):.4f}, Bedrock: {r.get('rerank_score', 'N/A'):.4f}")
    logger.info("=" * 80)
    
    # Evaluate results
    logger.info("Evaluating results...")
    eval_start = time.time()
    
    # Prepare query texts (branded product full descriptions)
    logger.info("Collecting branded query texts and OB index texts...")
    query_texts = {}
    for query in queries_with_gt:
        # Use query_row_id as the unique identifier for each query
        query_texts[query['query_row_id']] = query['text']
    
    # Prepare index texts (OB product full descriptions from indexer)
    index_texts = {}
    if hasattr(indexer, 'documents') and indexer.documents:
        for doc in indexer.documents:
            # documents is a list of dictionaries
            product_id = doc.get('product_id', '')
            text = doc.get('text', '')
            if product_id and text:
                index_texts[product_id] = text
    
    logger.info(f"Collected {len(query_texts)} query texts and {len(index_texts)} index texts")
    
    logger.info(f"  Collected {len(query_texts)} branded query texts")
    logger.info(f"  Collected {len(index_texts)} OB index texts")
    
    evaluator = ProductEvaluator()
    metrics = evaluator.evaluate(search_results, ground_truth, query_texts, index_texts)
    eval_elapsed = time.time() - eval_start
    logger.info(f"Evaluation metrics computed in {eval_elapsed:.2f} seconds")
    
    # Save results
    evaluator.save_results()
    
    # Total evaluation time
    total_eval_elapsed = time.time() - total_eval_start
    logger.info(f"=" * 60)
    logger.info(f"TOTAL EVALUATION TIME: {total_eval_elapsed:.2f} seconds ({total_eval_elapsed/60:.2f} minutes)")
    logger.info(f"=" * 60)
    
    return metrics


def run_interactive_search(indexer, use_feature_reranking=True):
    """
    Run interactive search mode
    
    Args:
        indexer: SemanticSearchIndex instance
        use_feature_reranking: Whether to use feature/ML reranking (Bedrock/HuggingFace/Feature)
    """
    logger = logging.getLogger(__name__)
    
    # Initialize searcher
    searcher = ProductSearcher(indexer)
    if use_feature_reranking:
        searcher.load_reranker()
    
    # Load LLM exact match reranker if enabled
    searcher.load_llm_exact_match_reranker()
    
    logger.info("\n" + "="*60)
    logger.info("INTERACTIVE SEARCH MODE")
    logger.info("="*60)
    print("\nEnter product descriptions to find matches (or 'quit' to exit)")
    
    while True:
        try:
            query_text = input("\nQuery: ").strip()
            
            if query_text.lower() in ['quit', 'exit', 'q']:
                break
            
            if not query_text:
                continue
            
            # Search
            results = searcher.search(
                query_text,
                top_k=10,
                use_feature_reranking=use_feature_reranking
            )
            
            # Display results
            print(f"\nTop 10 matches:")
            print("-" * 80)
            for i, result in enumerate(results, 1):
                print(f"\n{i}. Product ID: {result['product_id']}")
                print(f"   Description: {result.get('description', '')[:150]}")
                if result.get('web_display_name'):
                    print(f"   Display Name: {result['web_display_name'][:150]}")
                print(f"   Score: {result.get('score', 0):.4f}")
                if 'rerank_score' in result:
                    print(f"   Rerank Score: {result['rerank_score']:.4f}")
                print(f"   Cost: ${result.get('cost', 0):.2f}")
            
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Error: {e}")
            logger.error(f"Search error: {e}", exc_info=True)
    
    print("\nExiting interactive mode.")


def main():
    """Main execution function"""
    parser = argparse.ArgumentParser(description="Ferguson Product Matching Pipeline")
    
    parser.add_argument(
        '--mode',
        choices=['build', 'evaluate', 'interactive', 'full'],
        default='full',
        help='Execution mode: build (index only), evaluate (eval only), interactive (search UI), full (build+eval)'
    )
    
    parser.add_argument(
        '--rebuild',
        action='store_true',
        help='Force rebuild of index even if it exists'
    )
    
    parser.add_argument(
        '--no-rerank',
        action='store_true',
        help='Disable reranking'
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging()
    logger = logging.getLogger(__name__)
    
    logger.info("="*60)
    logger.info("FERGUSON PRODUCT MATCHING PIPELINE")
    logger.info("="*60)
    logger.info(f"Mode: {args.mode}")
    logger.info(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"Configuration:")
    logger.info(f"  Embedding Model: {config.INDEX_EMBEDDING_MODEL}")
    logger.info(f"  Reranker Model: {config.RERANKER_MODEL}")
    logger.info(f"  Hybrid Search: {config.HYBRID_SEARCH_ENABLED}")
    logger.info(f"  Top-K: {config.DEFAULT_SIMILARITY_TOP_K}")
    logger.info("="*60 + "\n")
    
    use_feature_reranking = not args.no_rerank
    
    try:
        if args.mode in ['build', 'full']:
            # Build index
            indexer = build_index(force_rebuild=args.rebuild)
        else:
            # Load existing index
            logger.info("Loading existing index...")
            indexer = ProductIndexer()
            indexer.load_index()
        
        if args.mode in ['evaluate', 'full']:
            # Run evaluation
            metrics = run_evaluation(indexer, use_feature_reranking=use_feature_reranking)
            
            # Print summary
            print("\n" + "="*60)
            print("EVALUATION RESULTS")
            print("="*60)
            print(f"Queries Evaluated: {metrics['queries_with_ground_truth']}")
            print(f"\nTop-K Accuracy:")
            for k, acc in metrics['top_k_accuracy'].items():
                print(f"  Top-{k}: {acc*100:.2f}%")
            print(f"\nMean Rank: {metrics['mean_rank']:.2f}")
            print(f"MRR: {metrics['mrr']:.4f}")
            print(f"Coverage: {metrics['coverage']*100:.2f}%")
            print("="*60)
        
        elif args.mode == 'interactive':
            # Run interactive search
            run_interactive_search(indexer, use_feature_reranking=use_feature_reranking)
        
        logger.info("\nPipeline completed successfully!")
        
    except Exception as e:
        logger.error(f"Pipeline failed: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    main()
