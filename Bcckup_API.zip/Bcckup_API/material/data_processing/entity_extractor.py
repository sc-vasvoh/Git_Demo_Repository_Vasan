"""
Entity extraction module for Ferguson Product Matching Pipeline
Extracts multiple entity types (dimensions, materials, colors, electrical specs, etc.) from product descriptions
"""

import re
import logging
import json
import os
from typing import List, Dict, Optional, Any
from common import config

logger = logging.getLogger(__name__)

# Global storage for entity logs
_product_entities_file = None
_query_entities_file = None
_product_entities_data = []
_query_entities_data = []


def _initialize_entity_files():
    """Initialize entity log file paths"""
    global _product_entities_file, _query_entities_file

    if _product_entities_file is None:
        # Get file paths from config
        _product_entities_file = config.ENTITY_PRODUCTS_FILE
        _query_entities_file = config.ENTITY_QUERIES_FILE

        # Create directories if needed
        for file_path in [_product_entities_file, _query_entities_file]:
            entities_dir = os.path.dirname(file_path)
            if entities_dir:
                os.makedirs(entities_dir, exist_ok=True)

        logger.info(f"Entity logging initialized:")
        logger.info(f"  Products: {_product_entities_file}")
        logger.info(f"  Queries: {_query_entities_file}")


def calculate_jaccard_similarity(set_a: set, set_b: set) -> float:
    """
    Calculate Jaccard similarity coefficient between two sets

    Args:
        set_a: First set
        set_b: Second set

    Returns:
        Jaccard similarity (0.0 to 1.0)
    """
    if not set_a and not set_b:
        return 1.0  # Both empty = perfect match
    if not set_a or not set_b:
        return 0.0  # One empty = no match
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


class RegexEntityExtractor:
    """Extract structured entities from product descriptions using regex patterns"""

    def __init__(self):
        # Dimension patterns (e.g., "10 by 20 inch", "1/2 inch", "10x20mm", "2-1/2 inch")
        self.dimension_patterns = [
            r"(\d+(?:-\d+/\d+|\s+\d+/\d+|[/-]\d+)?)\s*(?:by|x)\s*(\d+(?:-\d+/\d+|\s+\d+/\d+|[/-]\d+)?)\s*(inch|in|mm|cm|ft|feet)",
            r"(\d+(?:-\d+/\d+|\s+\d+/\d+|[/-]\d+)?)\s*(inch|in|mm|cm|ft|feet|meter|m)",
        ]

        # Voltage patterns (e.g., "120 volts", "24V AC", "12VDC")
        self.voltage_patterns = [
            r"(\d+(?:\.\d+)?)\s*(?:volt|volts|V|VAC|VDC)",
            r"(\d+(?:\.\d+)?)\s*(?:volt|V)\s*(AC|DC|alternating current|direct current)",
        ]

        # Amperage patterns
        self.amperage_patterns = [
            r"(\d+(?:\.\d+)?)\s*(?:amp|amps|ampere|amperes|A)\b",
        ]

        # Wattage patterns
        self.wattage_patterns = [
            r"(\d+(?:\.\d+)?)\s*(?:watt|watts|W)\b",
        ]

        # Temperature patterns
        self.temperature_patterns = [
            r"(-?\d+(?:\.\d+)?)\s*(?:degree|degrees|°)?\s*(?:F|Fahrenheit|C|Celsius)\b",
        ]

        # Pressure patterns
        self.pressure_patterns = [
            r"(\d+(?:\.\d+)?)\s*(?:psi|PSI|bar|pascal|Pa)\b",
        ]

        # Material keywords (304 materials from notebook)
        self.material_keywords = [
            "pb polypropylene",
            "zinc plated carbon steel",
            "brass alloy",
            "painted brass",
            "ss 316l",
            "buna",
            "valox",
            "corrosion",
            "felt",
            "wrought iron",
            "alabaster dust glass",
            "316 ss",
            "oxygen-free",
            "platane wood",
            "polished carrara marble",
            "12-ounce dot-compliant material",
            "c46500",
            "rough brass",
            "oil rubbed bronze",
            "bamboo",
            "silk",
            "al6063",
            "pipe cement",
            "copper pipe",
            "light gauge",
            "acetal copolymer",
            "synthetic leather",
            "white cast iron",
            "zinc nickel",
            "tin",
            "molded wood",
            "solid copper",
            "galvanized iron",
            "diamond",
            "crystal glass",
            "brass",
            "cast aluminum",
            "high-density polyethylene",
            "solid pine",
            "acrylonitrile",
            "metal alloy",
            "ribbed etched opal white glass",
            "pipe",
            "clear seeded glass",
            "316l grade stainless steel",
            "engineered stone",
            "flexible polypropylene",
            "galvanized pipe",
            "phosphor bronze",
            "cultured marble",
            "polybutylene",
            "a320 b8",
            "mdf",
            "weathered timber",
            "ethylene propylene diene monomer",
            "mesh",
            "304-grade stainless steel",
            "corrosion resistant stainless steel",
            "clad steel",
            "recycled glass",
            "epdm rubber",
            "monel 500",
            "pex",
            "copper alloy",
            "pb pvd",
            "foam nitrile",
            "powdercoat",
            "natural stone",
            "chrome metal",
            "molded plastic",
            "natural wicker",
            "plated solid brass",
            "forged steel a105n",
            "forged iron",
            "log",
            "polycarbonate",
            "304 polished stainless steel",
            "carrara stone",
            "epoxy coated stainless steel",
            "321",
            "solid metal",
            "mirrored acrylic",
            "polished nickel",
            "american red oak",
            "para wood",
            "delrin",
            "rock crystal",
            "recycled",
            "oriented strand board",
            "sheetrock",
            "onyx",
            "solid steel",
            "mineral composite",
            "density polyethylene",
            "rubberwood",
            "a320",
            "phenolic bronze",
            "nylon fiber",
            "grade a fireclay",
            "lead-free chrome-plated bronze",
            "olefin",
            "schedule 40 pipe",
            "mild steel",
            "die cast zinc",
            "stone slate",
            "washed teak wood",
            "flexible graphite",
            "polytech",
            "dyneema",
            "lucite",
            "plate steel",
            "glass-filled nylon",
            "20 gauge t304 stainless steel",
            "drywall",
            "cast stainless steel",
            "galvanized carbon steel",
            "parawood",
            "brushed nickel pvd",
            "stainless steel",
            "430 stainless steel",
            "low density polyethylene",
            "14-gauge",
            "jute",
            "lime delight",
            "polysulfone",
            "brushed stainless steel",
            "aluminum 6061-t6",
            "stoneware",
            "incoloy",
            "natural oak",
            "hastelloy c276",
            "forged steel a105",
            "cork",
            "abrasive cloth",
            "insulation plate",
            "wicker",
            "high quality steel",
            "cast carbon steel",
            "copper plated steel",
            "closed cell polyethylene",
            "solid bronze",
            "celcon",
            "fireclay",
            "rough chrome",
            "melamine particle",
            "reclaimed barn wood",
            "peened stainless steel",
            "abs plastic",
            "galvanized brass",
            "neoprene",
            "silicone rubber",
            "iron pipe",
            "cabinetry",
            "physical vapor deposition brass",
            "nitrile",
            "santoprene",
            "styrene",
            "copper bonded steel",
            "grade a307",
            "natural latex",
            "hand hammered",
            "a193 b16",
            "silicon",
            "red copper",
            "a320 grade",
            "non-asbestos fiber",
            "plaster",
            "engineered hardwood",
            "cognac leather",
            "aluminium",
            "coal",
            "pex-b",
            "graphite",
            "natural rubber",
            "rubidium",
            "injection molded thermoplastic abs",
            "tempered steel",
            "cf8m stainless steel",
            "lead-free wrought copper",
            "chrome",
            "ferrous",
            "steel welded",
            "gunmetal",
            "mirrored lens",
            "17-4ph stainless steel",
            "opal acrylic",
            "foil",
            "copper clad steel",
            "sea glass",
            "pom",
            "free brass",
            "lumber",
            "rubber",
            "c12200",
            "lacquer wood",
            "cast bronze",
            "20 gauge",
            "black malleable iron",
            "nickel brass",
            "copper clad",
            "rebar steel",
            "synthetic",
            "solid brass",
            "chrome plated cast",
            "extruded aluminum",
            "sterling",
            "abaca",
            "316l alloy",
            "global 304 stainless steel",
            "22 gauge",
            "heavy cast brass",
            "acetal",
            "molded solid plastic",
            "galvanized piping",
            "laminate wood",
            "gasket",
            "investment cast body",
            "oil",
            "tile",
            "welded steel",
            "316l grade",
            "nickel metal",
            "oxidized",
            "plastic washerless",
            "hast c276",
            "300 grade stainless",
            "heat treated iron",
            "petroleum",
            "solid kiln-dried grade a hardwood",
            "forged bronze",
            "white oak",
            "16 gauge t304 stainless steel",
            "high density polyethylene",
            "rough iron",
            "1-way steel",
            "stainless steel 316",
            "pbt",
            "charcoal soapstone",
            "cadmium",
            "glass reinforced plastic composite",
            "alcohol",
            "oxide",
            "ironite",
            "leather",
            "carrara vita quartz",
            "acrylonitrile butadiene styrene",
            "zinc plated",
            "acacia",
            "malleable cast iron",
            "hollow brass",
            "laminate veneer",
            "pipe fitting",
            "sapele wood",
            "solid hardwoods",
            "sponge rubber",
            "plastic polyethylene",
            "lacquer",
            "epoxy putty",
            "clear glass",
            "natural oak wood",
            "butyl diaphragm",
            "zinc stainless steel",
            "peened steel",
            "kraft paper",
            "18 gauge stainless steel",
            "high impact plastic",
            "cast brass",
            "lead-free bronze",
            "pex a tubing",
            "aluminum alloy",
            "petroleum wax",
            "fiberboard",
            "pine wood",
            "synthetic fiber",
            "solid plastic",
            "cast steel",
            "silver",
            "clear hammered glass",
            "wool",
            "roofing cement",
            "c69300-ecobrass",
            "nbr rubber",
            "old world bronze",
            "particle board",
            "spring steel",
            "PTFE",
            "316 marine-grade stainless steel",
            "sandcast",
            "304l",
            "natural fibers",
            "flexible pvc",
            "marble",
            "plywood",
            "type 304 stainless steel",
            "foam",
            "tempered glass",
            "corrugated metal",
            "inconel 800",
            "steel",
            "high grade cast iron",
            "elastomeric",
            "high carbon steel",
            "alabaster glass",
            "forged carbon steel",
            "sbr",
            "430",
            "40 mil",
            "grade a320",
            "chrome steel",
            "pumice",
            "forged steel a105n s62",
            "epoxy coated",
            "plastic",
            "fabric",
            "g90 galvanized coating",
            "durable steel",
            "nickel plated",
            "stone composite",
            "woven",
            "walnut",
            "industrial building material",
            "satin brass",
            "high impact polystyrene",
            "lime delight quartz",
            "insulated hose",
            "insulation",
            "lead",
            "latex",
            "11 gauge",
            "mindi wood",
            "forged metal",
            "abs",
            "mindi",
            "soapstone",
            "plate",
            "uns c46500",
            "flexible piping",
            "paulownia wood",
            "fiberglass",
            "metal shade",
            "steel plated",
            "brass c85700",
            "unfinished maple",
            "high quality metals",
            "plated malleable iron",
            "solid hardwood",
            "metal alloys",
            "soybean oil",
            "brushed aluminum",
            "natural fiber",
            "oxygen-free low carbon",
            "low alloy steel",
            "zinc plated forged steel",
            "oak",
            "vinyl",
            "tin/copper alloy",
            "laminate",
            "high speed steel",
            "wrot copper",
            "natural jute blend",
            "linear low-density polyethylene",
            "cold rolled steel",
            "polystyrene",
            "ceramic cartridge",
            "woven polypropylene",
            "acrylic",
            "plated steel",
            "yellow brass",
            "sediment filtration",
            "lexan",
            "pewter",
            "zinc plated low carbon steel",
            "14 gauge",
            "granite composite",
            "monel 400",
            "nbr",
            "cf8m",
            "hydraulic cement",
            "natural",
            "inconel 718",
            "lead-free phosphor bronze",
            "epoxy coated steel",
            "grade 316l",
            "zinc dichromate",
            "abaca rope",
            "carrara white",
            "albalite",
            "grade 2 steel",
            "mirrored surface",
            "pb",
            "304",
            "mouth blown clear optic glass",
            "beech wood",
            "zinc",
            "iron",
            "closed cell polyethylene foam",
            "portland cement",
            "alloy steel",
            "distressed koa",
            "metalized polypropylene",
            "aluminum bronze",
            "tungsten",
            "red bronze",
            "mango wood",
            "cardboard",
            "forged steel",
            "chlorinated polyvinyl chloride (cpvc)",
            "engineered carrara stone",
            "chrome plated iron",
            "polyester",
            "porcelain",
            "varnish",
            "wrought steel",
            "natural ash wood",
            "panel",
            "heavy duty pvc",
            "16 gauge",
            "crystal",
            "kerosene",
            "cellulose",
            "brushed gold",
            "rust-resistant zinc-plated",
            "celcon plastic",
            "caulk",
            "pearl",
            "polished stainless steel",
            "neoprene rubber",
            "faux alabaster",
            "mahogany",
            "polyethylene",
            "polytetrafluoroethylene",
            "wood",
            "opal glass",
            "white steel",
            "grade cr",
            "c pvc",
            "lead-free dzr brass",
            "a193 b7m",
            "die cast",
            "copolymer",
            "no lead brass",
            "chrome plated",
            "plated brass",
            "lead brass",
            "calcium thiosulfate",
            "physical vapor deposition bronze",
            "weathered oak",
            "ceramic disc",
            "high performance material",
            "410",
            "24 gauge",
            "cast iron",
            "flexible hose",
            "alabaster",
            "water",
            "304 ss",
            "copper",
            "lead-free tin/copper alloy",
            "wrought",
            "galvanized steel",
            "alloy tool steel",
            "ductile cast",
            "galvanized ductile iron",
            "stainless steel type 304",
            "stainless",
            "polyvinyl chloride",
            "304 grade",
            "chestnut",
            "ss 304l",
            "chrome plated stainless steel",
            "aluminized",
            "crushed stone",
            "solid mahogany",
            "microfiber",
            "pietra charcoal quartz",
            "frosted glass",
            "clear acrylic",
            "silicon bronze",
            "natural teak",
            "alloy",
            "santoprene rubber",
            "pex piping",
            "honey alder",
            "foam polyethylene",
            "chrome plated brass",
            "grease",
            "physical vapor deposition coating",
            "lead free",
            "calacatta bianco quartz",
            "mixed material",
            "pipe lubricant",
            "die cast zinc alloy",
            "nylon",
            "t304l stainless steel",
            "inconel 600",
            "natural wood veneer",
            "teak wood",
            "fiber",
            "insulation adhesive",
            "electroplated",
            "eucalyptus",
            "physical vapor deposition",
            "a403 grade cr",
            "a105n",
            "natural nylon",
            "dowel",
            "grade a vitreous china",
            "sheet steel",
            "cage",
            "lead-free pex",
            "nitrile rubber",
            "optic glass",
            "birch",
            "pipe cap",
            "plated nickel",
            "coated aluminum",
            "carbon fiber",
            "viscose",
            "limestone",
            "slate",
            "teak",
            "chain",
            "pet",
            "lithium",
            "polymer",
            "sand cast aluminum",
            "316 stainless steel",
            "c69300",
            "nickel plated brass",
            "carrara marble",
            "heavy duty iron",
            "buna n",
            "stainless steel 304",
            "zinc alloy",
            "wrought copper",
            "6063-t6 aluminum",
            "strong steel",
            "brushed aluminum laminate",
            "hdpe",
            "oak wood",
            "oxygen barrier",
            "316",
            "cabinet",
            "pex tubing",
            "a193 b8",
            "aircraft aluminum alloy",
            "natural rope",
            "elastomer",
            "fusion bonded epoxy",
            "walnut wood",
            "engineered maple",
            "forged brass",
            "granite",
            "grade a320 b8",
            "nickel plated steel",
            "stellite",
            "cement",
            "nickel",
            "ash wood",
            "american walnut",
            "22 gauge 2b stainless steel",
            "316 l",
            "alder wood",
            "fiber reinforced vinyl",
            "oak hardwood",
            "pe100",
            "unfinished wood",
            "engineered wood",
            "mild",
            "t304 stainless steel",
            "chrome plated carbon steel",
            "cable",
            "coated cardboard",
            "galvanized zinc plated",
            "top grain leather",
            "bronze",
            "polyvinyl",
            "paper",
            "titanium",
            "welded wire",
            "g10",
            "eco brass",
            "durable brass",
            "concrete",
            "polished chrome",
            "316 l stainless steel",
            "ferrite",
            "uncoated stainless steel",
            "elastomeric compound",
            "feathered white quartz",
            "lead-free chrome",
            "rolled steel",
            "liquefied petroleum gas",
            "20 gauge 2b stainless steel",
            "stellite 6",
            "etched glass",
            "double paned glass",
            "polyurethane",
            "chrome vanadium steel",
            "sheet metal",
            "natural mindi wood",
            "wire",
            "insulated base rear panel",
            "ABS",
            "type 316l",
            "solid silver",
            "burnished brass",
            "aluminum oxide",
            "chrome plated copper",
            "die cast aluminum",
            "brushed nickel plated stainless steel",
            "carrara",
            "c38500",
            "faux leather",
            "natural bristle",
            "insulation kit",
            "stone",
            "rustic wood",
            "corrosion resistant",
            "engineered marble",
            "cloth",
            "nitrile butadiene rubber",
            "pipe joint compound",
            "rp glass",
            "11 gauge square tube",
            "driftwood",
            "black carbon steel",
            "plain steel",
            "zinc plated cast iron",
            "mixed materials",
            "red brass",
            "virgin plastic",
            "methyl methacrylate",
            "ceramic",
            "virgin fiber",
            "epdm",
            "white porcelain",
            "metals",
            "zinc die cast",
            "modified polytetrafluoroethylene",
            "grade a193 b7m",
            "durable aluminum",
            "hailstone white quartz",
            "platinum ash",
            "opal etched glass",
            "zinc coated",
            "carrara white marble",
            "oak veneers",
            "pine",
            "304l grade",
            "buna rubber",
            "roman-brass",
            "304 stainless steel",
            "gold",
            "die cast metal",
            "low carbon steel",
            "stainless steel grade 316l",
            "elastomeric foam",
            "galvanized",
            "dom steel",
            "a193",
            "birch wood",
            "stainless steel 316l",
            "zamac",
            "macassar ebony",
            "hand forged iron",
            "activated carbon",
            "high density molded polyethylene",
            "english oak",
            "cast copper",
            "oxygen-free low copper",
            "carbon",
            "paint",
            "memory foam",
            "a105",
            "CPVC",
            "satin stainless steel",
            "epoxy",
            "cross-linked polyethylene",
            "pietra grey",
            "monel",
            "sintered stone",
            "mirror",
            "polypropylene",
            "316l stainless steel",
            "pe2406",
            "low lead brass alloy",
            "calcatta marble",
            "natural gas",
            "zinc plated steel",
            "glass",
            "viton",
            "uhwmpe",
            "pc",
            "woven polyester",
            "synthetic polymer",
            "copper plated cast iron",
            "brushed nickel",
            "hardwood",
            "quartz",
            "carbon steel",
            "piano finish",
            "synthetic rubber",
            "pex a",
            "copper plated",
            "gum rubber",
            "PVC",
            "butyl",
            "k9 crystal",
            "faux marble",
            "painted galvanized",
            "pipe insulation",
            "ixpe foam",
            "glass stone",
            "dzr brass",
            "peen ground bar",
            "cotton",
            "distressed wood",
            "chain link",
            "alabaster stone",
            "17-4ph",
            "316 grade stainless steel",
            "vinyl adhesive",
            "nickel alloy",
            "type 304l",
            "hand-forged iron",
            "18 gauge",
            "10-ounce material",
            "water-resistant",
            "chrome brass",
            "schedule 40 pvc",
            "upvc",
            "heat treated steel",
            "lead free brass",
            "marine grade mdf",
            "301",
            "pvc",
            "teflon",
            "glass reinforced nylon",
            "high impact polypropylene",
            "optical grade paper",
            "para wood solids",
            "pearlnickel",
            "urethane",
            "stamped steel",
            "100% wicking polyester mesh",
            "galvanized metal",
            "aisi 1045 carbon steel",
            "plated brass steel",
            "alloy 20",
            "stainless steel-304",
            "rebar",
            "maple",
            "aluminum",
            "stainless steel grade 316",
            "malleable iron",
            "brushed steel",
            "low temperature forged steel sa350 lf2",
            "nickel bronze",
            "cowhide",
            "high-density composite",
            "oyster shagreen",
            "pe",
            "silver solder",
            "brushed chrome",
            "poplar",
            "ductile iron",
            "304l stainless steel",
            "timber",
            "plastic composite",
            "wound spring wire",
            "cherry",
            "natural parawood",
            "molded wood core",
            "galvanized malleable iron",
            "opal",
            "medium density fiberboard",
            "liquid propane gas",
            "high strength",
            "welded wire mesh",
            "ryton",
            "seeded glass",
            "zinc alloy die-cast",
            "magnesium",
            "316l",
            "vinyl composite",
            "wire mesh",
            "edpm",
            "solid oak",
            "packing material",
            "rubbed bronze",
            "low residual carbon steel",
            "sand glass",
            "vitreous china",
            "cast copper alloy",
            "sand cast bronze",
            "steel wool",
            "304 stainless-steel",
            "mother of pearl",
            "polished brass",
            "3003",
            "maple plywood",
            "pecan",
            "metal",
            "patina",
            "phosphate",
            "16 gauge fha",
            "chlorinated polyvinyl chloride",
            "plain carbon steel",
            "faux wood",
            "silicone",
            "laminated veneer lumber",
            "low lead brass",
            "lead-free plastic",
            "PEX",
            "solvent cement",
            "stainless steel 304l",
            "heavy duty steel",
        ]

        # Color keywords
        # self.color_keywords = [
        #     'white', 'black', 'gray', 'grey', 'silver', 'chrome', 'bronze',
        #     'brass', 'nickel', 'red', 'blue', 'green', 'yellow', 'brown',
        #     'beige', 'tan', 'ivory', 'gold'
        # ]

        self.color_keywords = [
            "absolute black",
            "absolute white",
            "acorn",
            "aged antique brass",
            "aged auburn",
            "aged brass",
            "aged bronze",
            "aged charcoal",
            "aged cognac",
            "aged gold",
            "aged iron",
            "aged silver",
            "alabaster",
            "almond",
            "amber",
            "amber birch",
            "amber oil rubbed bronze",
            "american walnut",
            "antique black",
            "antique brass",
            "antique bronze",
            "antique brown",
            "antique coffee",
            "antique copper",
            "antique gold",
            "antique gray",
            "antique iron",
            "antique nickel",
            "antique pewter",
            "antique rust",
            "antique silver",
            "antique walnut",
            "antique white",
            "apple pavement black",
            "arcadian black",
            "architect bronze",
            "arctic white",
            "artisan brass",
            "ash",
            "ash brown",
            "ash gray",
            "auburn",
            "autumn gold",
            "autumn wheat",
            "avocado",
            "beige",
            "birch",
            "biscuit",
            "black",
            "black bronze",
            "black charcoal",
            "black chrome",
            "black gloss",
            "black iron",
            "black matte",
            "black nickel",
            "black onyx",
            "black powder coat",
            "black rock",
            "black walnut",
            "blue",
            "blue gray",
            "blue linen",
            "blue patina",
            "blush",
            "bombay white",
            "bone",
            "bone white",
            "brass",
            "brass antique",
            "brass tones",
            "bright blue",
            "bright navy blue",
            "bright nickel",
            "bright white",
            "brilliant silver",
            "brio gold",
            "bronze",
            "bronze oxide",
            "bronze patina",
            "bronze red",
            "brown",
            "brushed nickel",
            "burnished brass",
            "burnished bronze",
            "burnished gold",
            "burnt orange",
            "cala blue",
            "capri",
            "caramel",
            "carbon black",
            "cardinal",
            "carob brown",
            "carrara white",
            "champagne",
            "champagne brass",
            "champagne bronze",
            "champagne gold",
            "champagne silver leaf",
            "charcoal",
            "cherry",
            "chestnut",
            "chestnut brown",
            "chianti",
            "china black",
            "chocolate",
            "chrome",
            "cinnamon",
            "citron yellow",
            "claret",
            "clear",
            "clear amber",
            "clear bronze",
            "clear brown",
            "clear gray",
            "cloud white",
            "coal",
            "coal black",
            "coastal driftwood",
            "cocoa bark",
            "coffee",
            "cola grey",
            "colonial black",
            "colonial bronze",
            "copper",
            "copper bronze patina",
            "copper clad",
            "copper plated",
            "copper tones",
            "coral",
            "cream",
            "creamy white",
            "dark amber",
            "dark antique brass",
            "dark antique bronze",
            "dark antique copper",
            "dark bronze",
            "dark brown",
            "dark chocolate",
            "dark gray",
            "dark green",
            "dark grey",
            "dark olive green",
            "dark teal",
            "dark walnut",
            "deep olive green",
            "deep taupe",
            "delft blue",
            "distressed bronze",
            "distressed cream",
            "dove",
            "driftwood",
            "driftwood brown",
            "dusk grey",
            "ebony",
            "eggplant",
            "emerald",
            "emerald green",
            "espresso",
            "fawn beige",
            "fawn gold",
            "flat black",
            "flat white",
            "fluorescent green",
            "fluorescent yellow",
            "fog gray",
            "forest green",
            "french beige",
            "french black",
            "french bronze",
            "french gold",
            "frost",
            "galala beige",
            "gilded",
            "gilded bronze",
            "glacier white",
            "gloss black",
            "gloss white",
            "glossy dark gray",
            "glossy white",
            "gold",
            "gold leaf",
            "golden",
            "goldenrod",
            "graphite",
            "gray",
            "green",
            "grey",
            "gunmetal",
            "hailstone white",
            "halcyon gold",
            "hammered copper",
            "harvest gold",
            "haze",
            "hazel",
            "hazelnut",
            "heavy gray",
            "honey",
            "honey gold",
            "hot",
            "hunter green",
            "ice",
            "indigo",
            "iron ore",
            "ivory",
            "jade",
            "jasmine",
            "khaki",
            "laguna blue",
            "light blue",
            "light gold",
            "light gray",
            "light green",
            "light grey",
            "light maple",
            "light mappa burl",
            "light natural oak",
            "light oak",
            "light oil rubbed bronze",
            "light silver",
            "light walnut",
            "lilac",
            "lime",
            "linen",
            "liquid nickel",
            "living bronze",
            "lush greens",
            "macassar ebony",
            "machine brass",
            "mahogany",
            "maple",
            "marble black",
            "marble white",
            "marine",
            "maroon",
            "matcha green",
            "matte black",
            "matte brass",
            "matte brushed nickel",
            "matte chrome",
            "matte gold",
            "matte nickel",
            "matte white",
            "medium antique copper",
            "medium brown",
            "medium gray",
            "medium grey",
            "medium maple",
            "metallic silver",
            "mid century acacia",
            "mid century walnut",
            "midnight black",
            "midnight graphite",
            "midnight iron",
            "midnight navy",
            "midnight navy blue",
            "mineral gray",
            "mineral grey",
            "mocha brown",
            "modern gold",
            "mosaic gold",
            "mother of pearl",
            "mottled antique pewter",
            "mottled brass",
            "mountain gold",
            "mountain mist",
            "mushroom",
            "mustard",
            "muted gray",
            "muted grey",
            "mystic gold",
            "natural",
            "natural aluminum",
            "natural applewood",
            "natural bamboo",
            "natural black",
            "natural bronze",
            "natural brushed brass",
            "natural copper",
            "natural iron",
            "natural mango wood",
            "natural maple",
            "natural mindi",
            "natural oak",
            "natural teak",
            "natural walnut",
            "natural white",
            "navy",
            "navy blue",
            "off white",
            "off-white",
            "oil rubbed bronze",
            "old copper",
            "old world bronze",
            "olive ash eclipse",
            "onyx",
            "onyx black",
            "opal",
            "opal white",
            "orange",
            "orb",
            "oxidated bronze",
            "oxide brass",
            "oxidized aged brass",
            "oyster",
            "painted black",
            "painted bronze",
            "painted copper bronze patina",
            "painted modern gold",
            "pale gold",
            "pandora gold leaf",
            "parisien bleu",
            "parisien blue",
            "pastel aqua",
            "patina",
            "patina iron",
            "pear",
            "pearl",
            "pearl nickel",
            "pecan",
            "pecan brown",
            "pewter",
            "pewter bronze",
            "piano finish",
            "piastra gold",
            "piastra white",
            "pink",
            "pistachio",
            "platinum",
            "platinum ash",
            "platinum grey",
            "platinum ivory",
            "polar white",
            "polished brass",
            "polished brass - pvd",
            "polished chrome",
            "polished copper",
            "polished nickel",
            "polished platinum",
            "polished rose gold",
            "polished stainless steel",
            "powder blue",
            "pure silver",
            "pure white",
            "purple",
            "putty",
            "radiant gold",
            "raven bronze",
            "red",
            "red oil rubbed bronze",
            "red primer",
            "red wrinkle",
            "reflective white",
            "regal bronze",
            "regency blue",
            "retro green",
            "rich antique hickory",
            "rich blues",
            "riverside gray",
            "riverside grey",
            "riverstone gray",
            "roman bronze",
            "rose",
            "rose gold",
            "rough brass",
            "rough bronze",
            "rust",
            "rusted",
            "rustic bronze",
            "rustic brown",
            "rustic oak",
            "sable",
            "sable bronze",
            "sable brown",
            "saddle brown",
            "safety yellow",
            "sage green",
            "sand",
            "sandstone",
            "sapphire",
            "satin black",
            "satin brass",
            "satin bronze",
            "satin chrome",
            "satin copper",
            "satin gold",
            "satin gray",
            "satin green",
            "satin nickel",
            "satin pewter",
            "satin red",
            "satin rose gold",
            "satin slate blue",
            "satin stainless",
            "satin white",
            "savannah grey",
            "scarob brown",
            "seafoam green",
            "seashell",
            "sepia",
            "serenity blue",
            "sienna",
            "silver",
            "silver dust",
            "silver gray",
            "silver grey",
            "silver leaf",
            "silver mist",
            "sky gray",
            "sky grey",
            "slate",
            "slate blue",
            "slate grey",
            "smoke",
            "smoke blue",
            "smoke grey",
            "smokey amethyst",
            "smokey celadon",
            "snow white",
            "soft blue",
            "soft brass",
            "soft gold",
            "soft gray",
            "soft white",
            "spanish iron",
            "speckled grey",
            "speckled white",
            "stainless",
            "stainless chrome",
            "stainless steel",
            "steel",
            "steel grey",
            "stone",
            "stone grey",
            "sun gold",
            "sunburst gold leaf",
            "tan",
            "taupe",
            "tea green",
            "teak",
            "teal",
            "tobacco",
            "tofino bronze",
            "topaz",
            "translucent blue",
            "translucent gray",
            "translucent green",
            "translucent ivory",
            "translucent pink",
            "translucent red",
            "translucent silver",
            "translucent white",
            "transparent blue",
            "transparent red",
            "tricorn black",
            "turquoise",
            "twilight blue",
            "urban gray",
            "urban grey",
            "vanilla oak",
            "velvet",
            "venetian bronze",
            "venetian pink",
            "vermeil gold",
            "victorian silver",
            "victory bleu",
            "victory blue",
            "vintage blue",
            "vintage brass",
            "vintage bronze",
            "vintage gold",
            "vintage navy",
            "vintage navy blue",
            "vintage rust",
            "vintage vanilla",
            "vintage white",
            "weathered black",
            "weathered nickel",
            "weathered oak",
            "weathered spruce",
            "western gold",
            "wet sands",
            "white",
            "white bronze",
            "white enamel",
            "white feathered white",
            "white frosted",
            "white glossy",
            "white iris",
            "white linen",
            "white marble",
            "white opal",
            "white rum",
            "white sahara",
            "white thassos",
            "white wash",
            "white zeus",
            "yellow",
            "yellow chromate",
            "yellow zinc",
            "yellow zinc chromate",
            "yellow zinc dichromate",
        ]

    def extract_dimensions_raw(self, text: str) -> List[Dict[str, Any]]:
        """Extract dimension measurements (raw format from notebook)"""
        dimensions = []
        for pattern in self.dimension_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                dimensions.append(
                    {
                        "type": "dimension",
                        "value": match.group(0),
                        "groups": match.groups(),
                    }
                )
        return dimensions

    def extract_voltage(self, text: str) -> List[Dict[str, Any]]:
        """Extract voltage specifications"""
        voltages = []
        for pattern in self.voltage_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                voltages.append(
                    {
                        "type": "voltage",
                        "value": match.group(0),
                        "numeric": match.group(1),
                    }
                )
        return voltages

    def extract_amperage(self, text: str) -> List[Dict[str, Any]]:
        """Extract amperage specifications"""
        amperages = []
        for pattern in self.amperage_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                amperages.append(
                    {
                        "type": "amperage",
                        "value": match.group(0),
                        "numeric": match.group(1),
                    }
                )
        return amperages

    def extract_wattage(self, text: str) -> List[Dict[str, Any]]:
        """Extract wattage specifications"""
        wattages = []
        for pattern in self.wattage_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                wattages.append(
                    {
                        "type": "wattage",
                        "value": match.group(0),
                        "numeric": match.group(1),
                    }
                )
        return wattages

    def extract_temperature(self, text: str) -> List[Dict[str, Any]]:
        """Extract temperature specifications"""
        temperatures = []
        for pattern in self.temperature_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                temperatures.append(
                    {
                        "type": "temperature",
                        "value": match.group(0),
                        "numeric": match.group(1),
                    }
                )
        return temperatures

    def extract_pressure(self, text: str) -> List[Dict[str, Any]]:
        """Extract pressure specifications"""
        pressures = []
        for pattern in self.pressure_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                pressures.append(
                    {
                        "type": "pressure",
                        "value": match.group(0),
                        "numeric": match.group(1),
                    }
                )
        return pressures

    def extract_materials_raw(self, text: str) -> List[Dict[str, Any]]:
        """Extract material mentions (raw format from notebook)"""
        materials = []
        text_lower = text.lower()
        for material in self.material_keywords:
            if material.lower() in text_lower:
                materials.append({"type": "material", "value": material})
        return materials

    def extract_colors(self, text: str) -> List[Dict[str, Any]]:
        """Extract color mentions"""
        colors = []
        text_lower = text.lower()
        for color in self.color_keywords:
            if re.search(r"\b" + color.lower() + r"\b", text_lower):
                colors.append({"type": "color", "value": color})
        return colors


# Global extractor instance
_extractor = RegexEntityExtractor()


def extract_all_entities(text: str) -> Dict[str, Any]:
    """
    Extract all entity types from text

    Returns standardized format:
    {
        "dimensions": {"inch": ["12", "3/8"], "foot": ["6"]},
        "materials": ["brass", "steel"],
        "colors": ["white", "chrome"],
        "electrical": {
            "voltage": [{"value": "120V", "numeric": "120"}],
            "amperage": [...],
            "wattage": [...]
        },
        "measurements": {
            "temperature": [...],
            "pressure": [...]
        }
    }
    """
    if not text or not isinstance(text, str):
        return {
            "dimensions": {"inch": [], "foot": []},
            "materials": [],
            "colors": [],
            "electrical": {"voltage": [], "amperage": [], "wattage": []},
            "measurements": {"temperature": [], "pressure": []},
        }

    # Extract using dimension_extractor for dimensions (maintains compatibility)
    from data_processing.dimension_extractor import extract_dimensions_with_units

    dimensions = extract_dimensions_with_units(text)

    # Extract materials as list of strings
    materials_raw = _extractor.extract_materials_raw(text)
    materials = list(set([m["value"] for m in materials_raw]))  # Unique materials

    # Extract colors as list of strings
    colors_raw = _extractor.extract_colors(text)
    colors = list(set([c["value"] for c in colors_raw]))  # Unique colors

    # Extract electrical specs
    voltage = _extractor.extract_voltage(text)
    amperage = _extractor.extract_amperage(text)
    wattage = _extractor.extract_wattage(text)

    # Extract measurements
    temperature = _extractor.extract_temperature(text)
    pressure = _extractor.extract_pressure(text)

    return {
        "dimensions": dimensions,
        "materials": materials,
        "colors": colors,
        "electrical": {"voltage": voltage, "amperage": amperage, "wattage": wattage},
        "measurements": {"temperature": temperature, "pressure": pressure},
    }


def _save_entity_log(
    product_id: str,
    description: str,
    web_display_name: str,
    llm_expansion: str,
    entities_extracted: Dict[str, Any],
    is_query: bool = False,
    enriched_text: str = "",
    matching_products: Optional[Dict[str, Any]] = None,
    matching_count: int = 0,
):
    """
    Save entity extraction to log file (on-the-fly, per product/query)

    Args:
        product_id: Product or query ID
        description: Original description
        web_display_name: Web display name
        llm_expansion: LLM expanded text
        entities_extracted: Dictionary of all extracted entities
        is_query: Whether this is a query (True) or product (False)
        enriched_text: Full enriched text with web data (for products)
        matching_products: Dict mapping product IDs to their match scores (only for queries)
        matching_count: Count of matching products (only for queries)
    """
    global _product_entities_data, _query_entities_data

    # Initialize files if not done yet
    _initialize_entity_files()

    # Build log entry
    log_entry = {
        "product_id" if not is_query else "query_id": product_id,
        "product_description" if not is_query else "query_description": description,
        "web_display_name": web_display_name,
        "llm_expansion": llm_expansion,
        "entities_extracted": entities_extracted,
    }

    # Add enriched_text for products
    if not is_query and enriched_text:
        log_entry["enriched_text"] = enriched_text

    # Add matching info for queries
    if is_query and matching_products is not None:
        log_entry["matching_products_before_search"] = matching_products
        log_entry["matching_count_before_search"] = matching_count

    # Add to in-memory list (don't save to file yet - will be saved at the end)
    if is_query:
        _query_entities_data.append(log_entry)
    else:
        _product_entities_data.append(log_entry)


def flush_entity_logs():
    """
    Save all entity logs to files at once (called at the end of processing)
    Uses separate config flags for product and query logs
    """
    global _product_entities_data, _query_entities_data, _product_entities_file, _query_entities_file

    # Save product entities
    if config.SAVE_PRODUCT_ENTITY_LOGS:
        if _product_entities_data:
            try:
                with open(_product_entities_file, "w", encoding="utf-8") as f:
                    json.dump(_product_entities_data, f, indent=2, ensure_ascii=False)
                logger.info(
                    f"✅ Saved {len(_product_entities_data)} product entity logs to {_product_entities_file}"
                )
            except Exception as e:
                logger.warning(f"Failed to save product entity logs: {e}")
        else:
            logger.info("No product entity logs to save")
    else:
        logger.info(
            "Product entity log saving disabled (SAVE_PRODUCT_ENTITY_LOGS=False)"
        )

    # Save query entities
    if config.SAVE_QUERY_ENTITY_LOGS:
        if _query_entities_data:
            try:
                with open(_query_entities_file, "w", encoding="utf-8") as f:
                    json.dump(_query_entities_data, f, indent=2, ensure_ascii=False)
                logger.info(
                    f"✅ Saved {len(_query_entities_data)} query entity logs to {_query_entities_file}"
                )
            except Exception as e:
                logger.warning(f"Failed to save query entity logs: {e}")
        else:
            logger.info("No query entity logs to save")
    else:
        logger.info("Query entity log saving disabled (SAVE_QUERY_ENTITY_LOGS=False)")


def log_product_entities(
    product_id: str,
    description: str,
    web_display_name: str,
    llm_expansion: str,
    enriched_text: str,
    entities_extracted: Dict[str, Any],
):
    """
    Log product entities to file (on-the-fly)

    Args:
        product_id: Product ID
        description: Original description
        web_display_name: Web display name
        llm_expansion: LLM expanded text (before web data)
        enriched_text: Full enriched text with web data
        entities_extracted: Dictionary of all extracted entities
    """
    _save_entity_log(
        product_id=product_id,
        description=description,
        web_display_name=web_display_name,
        llm_expansion=llm_expansion,
        entities_extracted=entities_extracted,
        is_query=False,
        enriched_text=enriched_text,
    )

    logger.debug(
        f"Logged product {product_id} with entities: "
        f"materials={len(entities_extracted.get('materials', []))}, "
        f"dimensions={entities_extracted.get('dimensions')}"
    )


def log_query_entities(
    query_id: str,
    description: str,
    web_display_name: str,
    entities_extracted: Dict[str, Any],
    matching_products_before_search: Dict[str, Any] = None,
    matching_count_before_search: int = 0,
):
    """
    Log query entities to file (on-the-fly)

    Args:
        query_id: Query ID
        description: Query description
        web_display_name: Web display name
        entities_extracted: Dictionary of all extracted entities
        matching_products_before_search: Dict mapping product IDs to match scores (matched BEFORE semantic search)
        matching_count_before_search: Count of matching products BEFORE semantic search
    """
    _save_entity_log(
        product_id=query_id,
        description=description,
        web_display_name=web_display_name,
        llm_expansion="",  # Queries don't need LLM expansion logged separately
        entities_extracted=entities_extracted,
        is_query=True,
        matching_products=matching_products_before_search or {},
        matching_count=matching_count_before_search,
    )

    logger.debug(
        f"Logged query {query_id} with entities: "
        f"materials={len(entities_extracted.get('materials', []))}, "
        f"dimensions={entities_extracted.get('dimensions')}, "
        f"matches={matching_count_before_search}"
    )


# ============================================================================
# Backward Compatibility Functions (for dimension_extractor.py compatibility)
# ============================================================================


def extract_dimensions(text: str) -> Dict[str, List[str]]:
    """
    Backward compatible function - extracts only dimensions

    Args:
        text: Text to extract dimensions from

    Returns:
        Dictionary with "inch" and "foot" keys
    """
    entities = extract_all_entities(text)
    return entities.get("dimensions", {"inch": [], "foot": []})


def extract_materials(text: str) -> List[str]:
    """
    Extract materials from text

    Args:
        text: Text to extract materials from

    Returns:
        List of material strings
    """
    entities = extract_all_entities(text)
    return entities.get("materials", [])


# Legacy aliases for dimension logging
def log_product_dimensions(
    product_id: str,
    description: str,
    web_display_name: str,
    llm_expansion: str,
    dimension_extracted: Dict[str, List[str]],
):
    """Legacy function - use log_product_entities instead"""
    entities = {
        "dimensions": dimension_extracted,
        "materials": [],
        "colors": [],
        "electrical": {"voltage": [], "amperage": [], "wattage": []},
        "measurements": {"temperature": [], "pressure": []},
    }
    log_product_entities(
        product_id=product_id,
        description=description,
        web_display_name=web_display_name,
        llm_expansion=llm_expansion,
        enriched_text=llm_expansion,
        entities_extracted=entities,
    )


def log_query_dimensions(
    query_id: str,
    description: str,
    web_display_name: str,
    dimension_extracted: Dict[str, List[str]],
    matching_products_before_search: Dict[str, List[str]] = None,
    matching_count_before_search: int = 0,
):
    """Legacy function - use log_query_entities instead"""
    entities = {
        "dimensions": dimension_extracted,
        "materials": [],
        "colors": [],
        "electrical": {"voltage": [], "amperage": [], "wattage": []},
        "measurements": {"temperature": [], "pressure": []},
    }
    log_query_entities(
        query_id=query_id,
        description=description,
        web_display_name=web_display_name,
        entities_extracted=entities,
        matching_products_before_search=matching_products_before_search,
        matching_count_before_search=matching_count_before_search,
    )
