"""
Data loading and preprocessing module for Ferguson Product Matching Pipeline
"""

import pandas as pd
import numpy as np
from typing import Dict, Tuple
import logging
import time
from common import config
import json
import os

logger = logging.getLogger(__name__)


class DataLoader:
    """Handles loading and preprocessing of product data"""
    
    def __init__(self):
        self.ob_products = None
        self.branded_products = None
        self.hierarchy = None
        self.verified_crosses = None
        self.hierarchy_dict = None
        self.web_data_branded = None
        self.web_data_ob = None
        self.web_data_ob_extra = None
        self.web_data_branded_extra = None
        # Tracking counters for extra web data
        self.ob_extra_data_calls = 0
        self.ob_extra_data_success = 0
    
    @staticmethod
    def clean_product_id(product_id) -> str:
        """
        Clean product ID to remove trailing .0 from float conversions
        
        Args:
            product_id: Product ID (can be int, float, or string)
            
        Returns:
            Cleaned product ID as string
            
        Examples:
            1234.0 -> "1234"
            1234 -> "1234"
            "1234.0" -> "1234"
            "ABC123" -> "ABC123"
        """
        product_id_str = str(product_id)
        # Remove trailing .0 if present
        if product_id_str.endswith('.0'):
            product_id_str = product_id_str[:-2]
        return product_id_str
    
    def _load_file(self, file_path: str) -> pd.DataFrame:
        """
        Load a file that can be either Excel (.xlsx, .xls) or CSV (.csv)
        
        Args:
            file_path: Path to the file
            
        Returns:
            DataFrame with loaded data
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Get file extension
        _, ext = os.path.splitext(file_path)
        ext = ext.lower()
        
        # Load based on extension
        if ext in ['.xlsx', '.xls']:
            logger.debug(f"Loading Excel file: {file_path}")
            return pd.read_excel(file_path)
        elif ext == '.csv':
            logger.debug(f"Loading CSV file: {file_path}")
            return pd.read_csv(file_path)
        else:
            raise ValueError(f"Unsupported file format: {ext}. Supported formats: .xlsx, .xls, .csv")
        
    def load_all_data(self) -> None:
        """Load all datasets"""
        logger.info(f"\n{'='*80}")
        logger.info(f"⏱️  DATA LOADING START")
        logger.info(f"{'='*80}")
        load_start_time = time.time()
        
        if config.USE_SAMPLE_DATA:
            logger.info(f"Using pre-sampled data from: {config.DATA_DIR}")
        else:
            logger.info(f"Using full data from: {config.DATA_DIR}")
        
        # Load product hierarchy
        logger.info("⏱️  Step 1: Loading hierarchy...")
        hierarchy_start = time.time()
        self.hierarchy = self._load_file(config.HIERARCHY_FILE)
        self._build_hierarchy_dict()
        hierarchy_elapsed = time.time() - hierarchy_start
        logger.info(f"✅ Loaded {len(self.hierarchy)} hierarchy entries in {hierarchy_elapsed:.3f}s")
        
        # Load OB products (no sampling - already sampled if using sample data)
        logger.info("⏱️  Step 2: Loading OB products...")
        ob_start = time.time()
        self.ob_products = self._load_file(config.OB_PRODUCTS_FILE)
        ob_elapsed = time.time() - ob_start
        logger.info(f"✅ Loaded {len(self.ob_products)} OB products in {ob_elapsed:.3f}s")
        
        # Load branded products
        logger.info("⏱️  Step 3: Loading branded products...")
        branded_start = time.time()
        self.branded_products = self._load_file(config.BRANDED_PRODUCTS_FILE)
        branded_elapsed = time.time() - branded_start
        logger.info(f"✅ Loaded {len(self.branded_products)} branded products in {branded_elapsed:.3f}s")
        
        # Load verified crosses
        logger.info("⏱️  Step 4: Loading verified crosses...")
        crosses_start = time.time()
        self.verified_crosses = self._load_file(config.VERIFIED_CROSSES_FILE)
        crosses_elapsed = time.time() - crosses_start
        logger.info(f"✅ Loaded {len(self.verified_crosses)} verified crosses in {crosses_elapsed:.3f}s")

        # Load web data
        logger.info("⏱️  Step 5: Loading web data...")
        web_start = time.time()
        
        self.web_data_branded = pd.read_csv(config.WEB_BRANDED_PRODUCTS_FILE, encoding='utf-8')
        self.web_data_branded["product_id"] = self.web_data_branded["product_id"].apply(self.clean_product_id)
        self.web_data_branded["answer"] = self.web_data_branded["answer"].apply(json.loads)
        
        self.web_data_ob = pd.read_csv(config.WEB_OB_PRODUCTS_FILE, encoding='utf-8')
        self.web_data_ob["product_id"] = self.web_data_ob["product_id"].apply(self.clean_product_id)
        self.web_data_ob["answer"] = self.web_data_ob["answer"].apply(json.loads)
        
        # Load extra OB web data
        self.web_data_ob_extra = pd.read_csv(config.WEB_OB_PRODUCTS_EXTRA_FILE, encoding='utf-8')
        self.web_data_ob_extra["product_id"] = self.web_data_ob_extra["product_id"].apply(self.clean_product_id)
        # Note: answer column in extra file is already formatted text, not JSON
        
        # Load extra branded web data
        self.web_data_branded_extra = pd.read_csv(config.WEB_BRANDED_PRODUCTS_EXTRA_FILE, encoding='utf-8')
        self.web_data_branded_extra["product_id"] = self.web_data_branded_extra["product_id"].apply(self.clean_product_id)
        # Note: answer column in extra file is already formatted text, not JSON

        web_elapsed = time.time() - web_start
        logger.info(f"✅ Loaded web data in {web_elapsed:.3f}s")

        # Clean data
        logger.info("⏱️  Step 6: Cleaning data...")
        clean_start = time.time()
        self._clean_data()
        clean_elapsed = time.time() - clean_start
        logger.info(f"✅ Data cleaned in {clean_elapsed:.3f}s")
        
        # Total loading time
        total_elapsed = time.time() - load_start_time
        logger.info(f"\n{'='*80}")
        logger.info(f"⏱️  DATA LOADING COMPLETE - TIMING SUMMARY")
        logger.info(f"{'='*80}")
        logger.info(f"  1. Hierarchy:          {hierarchy_elapsed:>8.3f}s  ({hierarchy_elapsed/total_elapsed*100:>5.1f}%)")
        logger.info(f"  2. OB products:        {ob_elapsed:>8.3f}s  ({ob_elapsed/total_elapsed*100:>5.1f}%)")
        logger.info(f"  3. Branded products:   {branded_elapsed:>8.3f}s  ({branded_elapsed/total_elapsed*100:>5.1f}%)")
        logger.info(f"  4. Verified crosses:   {crosses_elapsed:>8.3f}s  ({crosses_elapsed/total_elapsed*100:>5.1f}%)")
        logger.info(f"  5. Web data:           {web_elapsed:>8.3f}s  ({web_elapsed/total_elapsed*100:>5.1f}%)")
        logger.info(f"  6. Data cleaning:      {clean_elapsed:>8.3f}s  ({clean_elapsed/total_elapsed*100:>5.1f}%)")
        logger.info(f"  {'─'*40}")
        logger.info(f"  TOTAL LOADING TIME:    {total_elapsed:>8.3f}s  ({total_elapsed/60:>5.2f} minutes)")
        logger.info(f"{'='*80}\n")
        
    def _build_hierarchy_dict(self) -> None:
        """Build dictionary for fast hierarchy lookups"""
        self.hierarchy_dict = {}
        for _, row in self.hierarchy.iterrows():
            self.hierarchy_dict[row['HIERARCHY']] = {
                'level1': row.get('LEVEL1', ''),
                'level2': row.get('LEVEL2', ''),
                'level3': row.get('LEVEL3', ''),
                'level4': row.get('LEVEL4', '')
            }
        logger.info(f"Built hierarchy dictionary with {len(self.hierarchy_dict)} entries")
    
    def _clean_data(self) -> None:
        """Clean and preprocess data"""
        # Fill NaN values
        for df in [self.ob_products, self.branded_products]:
            df['description'] = df['description'].fillna('')
            df['Web_Display_Name'] = df['Web_Display_Name'].fillna('')
            df['MP_GLBL_PROD_HIER'] = df['MP_GLBL_PROD_HIER'].fillna('')
            
        logger.info("Data cleaning completed")
    
    def get_enriched_description(self, row: pd.Series) -> str:
        """
        Get enriched description with hierarchy information
        
        Args:
            row: Product row from dataframe
            
        Returns:
            Enriched description string
        """
        # Use product description
        # base_desc = row['description'] 
        base_desc = "Description: " + str(row['description']) + "\nWeb Display Name: " + str(row['Web_Display_Name']) 
        

        # THIS IS WRONG USE OF HIERARCHY INFO. Put it in metadata and filter.
        # ADD LOGIC FOR THIS.
        if not config.USE_HIERARCHY_ENRICHMENT:
            return base_desc
        
        # Get hierarchy info
        hier_id = row['MP_GLBL_PROD_HIER']
        if hier_id and hier_id in self.hierarchy_dict:
            hier_info = self.hierarchy_dict[hier_id]
            enriched = config.HIERARCHY_TEMPLATE.format(
                description=base_desc,
                level1=hier_info['level1'],
                #level2=hier_info['level2'],
                #evel3=hier_info['level3']
            )
            return enriched
        
        return base_desc


    def get_answer_web_branded(self, product_id: str):
        try:
            # First, check the primary web data (JSON format)
            row = self.web_data_branded[self.web_data_branded["product_id"] == product_id]
            if not row.empty:
                logger.debug(f"Found web data for branded product {product_id} in primary source")
                return row.iloc[0]["answer"]
            
            # If not found, check the extra web data (plain text format)
            row_extra = self.web_data_branded_extra[self.web_data_branded_extra["product_id"] == product_id]
            if not row_extra.empty:
                logger.info(f"Found web data for branded product {product_id} in extra data source")
                # Return the answer as-is (it's already formatted text, not JSON)
                answer = row_extra.iloc[0]["answer"]
                if pd.notna(answer) and answer:
                    return answer
        except Exception as e:
            logger.warning(f"Error fetching web data for branded product {product_id}: {e}")
        return None

    def get_answer_web_ob(self, product_id: str):
        try:
            # First, check the primary web data (JSON format)
            row = self.web_data_ob[self.web_data_ob["product_id"] == product_id]
            if not row.empty:
                logger.debug(f"Found web data for OB product {product_id} in primary source")
                return row.iloc[0]["answer"]
            
            # If not found, check the extra web data (plain text format)
            row_extra = self.web_data_ob_extra[self.web_data_ob_extra["product_id"] == product_id]
            self.ob_extra_data_calls += 1
            if not row_extra.empty:
                logger.info(f"Found web data for OB product {product_id} in extra data source")
                # Return the answer as-is (it's already formatted text, not JSON)
                answer = row_extra.iloc[0]["answer"]
                if pd.notna(answer) and answer:
                    self.ob_extra_data_success += 1
                    return answer
            
            logger.debug(f"No web data found for OB product {product_id} in any source")
                
        except Exception as e:
            logger.warning(f"Error fetching web data for OB product {product_id}: {e}")
        return None

    def build_base_description(self, row: pd.Series) -> str:
        """
        Build base description from product row with optional hierarchy enrichment.
        
        Args:
            row: Product row from dataframe
            
        Returns:
            Base description string (before LLM expansion)
        """
        base_desc = "Description: " + str(row['description']) + "\nWeb Display Name: " + str(row['Web_Display_Name'])
        
        # Add hierarchy enrichment BEFORE LLM expansion
        if config.USE_HIERARCHY_ENRICHMENT:
            hier_id = row['MP_GLBL_PROD_HIER']
            if hier_id and hier_id in self.hierarchy_dict:
                hier_info = self.hierarchy_dict[hier_id]
                base_desc = config.HIERARCHY_TEMPLATE.format(
                    description=base_desc,
                    level1=hier_info['level1']
                )
        
        return base_desc
    
    def format_web_data(self, data_from_web) -> str:
        """
        Format web scraped data into text.
        
        Args:
            data_from_web: Web data (dict or string)
            
        Returns:
            Formatted web text string
        """
        web_text = ""
        
        if not data_from_web:
            return web_text
        
        if isinstance(data_from_web, dict):
            # JSON format from primary source
            product_details_web = data_from_web.get("Product Details")
            specifications_web = data_from_web.get("Specifications")
            
            # Case: Product Details exists and is a list
            if product_details_web and isinstance(product_details_web, list):
                details_lines = [f"- {item}" for item in product_details_web]
                formatted_details = "\n".join(details_lines)
                web_text += f"\n\nAdditional Product Details:\n{formatted_details}"

            # Case: Specifications exists and is a dict
            if specifications_web and isinstance(specifications_web, dict):
                specs_lines = [f"- {key}: {value}" for key, value in specifications_web.items()]
                formatted_specs = "\n".join(specs_lines)
                web_text += f"\n\nSpecifications:\n{formatted_specs}"
        elif isinstance(data_from_web, str):
            # Plain text format from extra source
            web_text += f"\n\n{data_from_web}"
        
        return web_text

    def get_answer_web_branded_extra(self, product_id: str):
        # if not found, check the extra web data (plain text format)
        try:
            row_extra = self.web_data_branded_extra[self.web_data_branded_extra["product_id"] == product_id]
            if not row_extra.empty:
                logger.info(f"Found web data for branded product {product_id} in extra data source")
                logger.info(f"Found branded web data in extra data source for product_id: {product_id}")
                answer = row_extra.iloc[0]["answer"]
                if pd.notna(answer) and answer:
                    return answer
            else:
                logger.info(f"No branded web data found in extra data source for product_id: {product_id}")
        except Exception as e:
            logger.warning(f"Error fetching extra web data for branded product {product_id}: {e}")
            logger.warning(f"Error fetching extra web data for branded product {product_id}: {e}")
        return None

    def get_answer_web_ob_extra(self, product_id: str):
        # if not found, check the extra web data (plain text format)
        self.ob_extra_data_calls += 1
        try:
            row_extra = self.web_data_ob_extra[self.web_data_ob_extra["product_id"] == product_id]
            if not row_extra.empty:
                logger.info(f"Found web data for OB product {product_id} in extra data source")
                logger.info(f"Found OB web data in extra data source for product_id: {product_id}")
                answer = row_extra.iloc[0]["answer"]
                if pd.notna(answer) and answer:
                    self.ob_extra_data_success += 1
                    return answer
            else:
                logger.info(f"No OB web data found in extra data source for product_id: {product_id}")
        except Exception as e:
            logger.warning(f"Error fetching extra web data for OB product {product_id}: {e}")
            logger.warning(f"Error fetching extra web data for OB product {product_id}: {e}")
        return None
    
    def extract_dimensions(self, text: str, product_id: str) -> list:
        """
        Extract dimensions from text if dimension filtering is enabled.
        
        Args:
            text: Text to extract dimensions from
            product_id: Product ID for logging
            
        Returns:
            List of extracted dimensions
        """
        dimension_extracted = []
        
        if config.USE_DIMENSION_FILTERING:
            from data_processing.dimension_extractor import extract_dimensions
            dimension_extracted = extract_dimensions(text)
            
            if dimension_extracted:
                logger.info(f"Product {product_id} - Extracted dimensions from LLM expansion: {dimension_extracted}")
        
        return dimension_extracted
    
    def batch_expand_descriptions(self, base_descriptions: Dict[str, str], is_query: bool = False) -> Dict[str, str]:
        """
        Batch expand descriptions using LLM if enabled.
        
        Args:
            base_descriptions: Dict mapping product_id -> base_description
            is_query: Whether these are query texts (True) or document texts (False)
            
        Returns:
            Dict mapping product_id -> expanded_description
        """
        if config.USE_LLM_EXPANSION:
            from data_processing.text_expander import expand_batch
            # Prepare batch: list of (text, product_id, is_query)
            batch = [(base_desc, pid, is_query) for pid, base_desc in base_descriptions.items()]
            # Get expanded results: dict mapping product_id -> expanded_text
            expansion_results = expand_batch(batch)
            # Results are already keyed by product_id
            return expansion_results
        else:
            return base_descriptions
    
    def process_product_batch(self, products_df: pd.DataFrame, is_query: bool = False, 
                                get_web_data_func=None, log_dimensions: bool = False) -> Tuple[Dict[str, str], Dict[str, str]]:
        """
        Generic function to process a batch of products through the standard pipeline.
        
        Steps:
        1. Build base descriptions with hierarchy enrichment
        2. Batch expand with LLM if enabled
        
        Args:
            products_df: DataFrame with product rows
            is_query: Whether processing queries (True) or documents (False)
            get_web_data_func: Optional function to get web data for a product_id
            log_dimensions: Whether to log dimensions (only for OB products)
            
        Returns:
            Tuple of (base_descriptions dict, expanded_descriptions dict)
        """
        base_descriptions = {}
        
        # Step 1: Build base descriptions
        for idx, row in products_df.iterrows():
            product_id = self.clean_product_id(row['product_id'])
            
            # Skip if description or Web_Display_Name are integers (invalid data)
            if isinstance(row['description'], (int, float)) or isinstance(row['Web_Display_Name'], (int, float)):
                logger.warning(f"Skipping product {product_id} - description or Web_Display_Name is numeric (invalid data)")
                continue
            
            base_descriptions[product_id] = self.build_base_description(row)
        
        # Step 2: Batch expand if enabled
        expanded_descriptions = self.batch_expand_descriptions(base_descriptions, is_query=is_query)
        
        return base_descriptions, expanded_descriptions


    def prepare_ob_documents(self) -> list:
        """
        Prepare OB products for indexing with optional LLM batch expansion
        
        Returns:
            List of document dictionaries
        """
        # Steps 1-2: Build and expand descriptions
        base_descriptions, expanded_descriptions = self.process_product_batch(
            self.ob_products, 
            is_query=False
        )
        
        # Step 3: Build documents with enriched content
        documents = []
        for idx, row in self.ob_products.iterrows():
            product_id = self.clean_product_id(row['product_id'])
            
            # Skip if product was filtered out in Step 1 (invalid data)
            if product_id not in base_descriptions:
                continue
            
            original_desc = base_descriptions[product_id]
            base_desc = expanded_descriptions[product_id]
            logger.info(f"------ORIGINAL DESCRIPTION------ : \n\n{original_desc}\n")
            logger.info(f"------NEW DESCRIPTION------ : \n\n{base_desc}\n")

            # Extract hierarchy metadata for filtering
            hier_id = row['MP_GLBL_PROD_HIER']
            hierarchy_level1 = None
            hierarchy_level2 = None
            if hier_id and hier_id in self.hierarchy_dict:
                hierarchy_level1 = self.hierarchy_dict[hier_id]['level1']
                hierarchy_level2 = self.hierarchy_dict[hier_id]['level2']
            
            # Extract dimensions BEFORE adding web scraped data
            dimension_extracted = self.extract_dimensions(base_desc, product_id)
            
            # Log dimensions for OB products (on-the-fly)
            if config.USE_DIMENSION_FILTERING and dimension_extracted:
                from data_processing.dimension_extractor import log_product_dimensions
                log_product_dimensions(
                    product_id=product_id,
                    description=str(row['description']),
                    web_display_name=str(row['Web_Display_Name']),
                    llm_expansion=base_desc,
                    dimension_extracted=dimension_extracted
                )
            
            # Add web scraped data AFTER dimension extraction
            enriched_desc = base_desc
            web_text = self.format_web_data(self.get_answer_web_ob(product_id))
            if web_text.strip():
                enriched_desc += web_text

            if enriched_desc == base_desc:
                logger.info(f"Appending extra web data for OB product {product_id}")
                data_from_web = self.get_answer_web_ob_extra(product_id)
                if data_from_web and isinstance(data_from_web, str):
                    logger.info(f"Added extra web data for OB product {product_id}")
                    enriched_desc += f"\n\n{data_from_web}"

            logger.info(f"------FINAL DESCRIPTION INDEX------ : \n\n{enriched_desc}\n")
    
            doc = {
                'text': enriched_desc,
                'description_with_hierarchy': original_desc,
                'product_id': product_id,
                'description': row['description'],
                'web_display_name': row['Web_Display_Name'],
                'hierarchy': row['MP_GLBL_PROD_HIER'],
                'hierarchy_level1': hierarchy_level1,
                'hierarchy_level2': hierarchy_level2,
                'dimension_extracted': dimension_extracted,
                'supplier_name': row.get('supplier_name', ''),
                'mpn': row.get('mpn', ''),
                'uom': row.get('uom', ''),
                'cost': row.get('cost', 0.0)
            }
            documents.append(doc)
        
        msg = f"Prepared {len(documents)} OB documents for indexing"
        if config.USE_LLM_EXPANSION:
            msg += " (with batch LLM expansion)"
        logger.info(msg)
        
        # Log extra web data statistics
        logger.info(f"\n{'='*80}")
        logger.info(f"OB EXTRA WEB DATA STATISTICS")
        logger.info(f"{'='*80}")
        logger.info(f"Total products checked for extra web data: {self.ob_extra_data_calls}")
        logger.info(f"Products with valid extra web data: {self.ob_extra_data_success}")
        logger.info(f"Success rate: {(self.ob_extra_data_success/self.ob_extra_data_calls*100) if self.ob_extra_data_calls > 0 else 0:.2f}%")
        logger.info(f"{'='*80}\n")
        
        # Flush dimension logs to file (save all at once for performance)
        if config.USE_DIMENSION_FILTERING:
            from data_processing.dimension_extractor import flush_dimension_logs
            flush_dimension_logs()
        
        return documents
    
    def get_branded_queries(self, filter_product_ids=None) -> list:
        """
        Prepare branded products as queries with optional LLM batch expansion
        
        Args:
            filter_product_ids: Optional set of product IDs to filter queries (for evaluation efficiency)
        
        Returns:
            List of query dictionaries
        """
        # Filter products if needed
        if filter_product_ids is not None:
            filtered_df = self.branded_products[
                self.branded_products['product_id'].astype(str).isin(filter_product_ids)
            ].reset_index(drop=True)
        else:
            filtered_df = self.branded_products
        
        # Steps 1-2: Build and expand descriptions
        base_descriptions, expanded_descriptions = self.process_product_batch(
            filtered_df, 
            is_query=True
        )
        
        # Step 3: Build query objects
        queries = []
        for idx, row in filtered_df.iterrows():
            product_id = self.clean_product_id(row['product_id'])
            
            # Skip if product was filtered out in Step 1 (invalid data)
            if product_id not in base_descriptions:
                continue
            
            original_desc = base_descriptions[product_id]
            base_desc = expanded_descriptions[product_id]
            
            # Get hierarchy metadata for filtering
            hier_id = row['MP_GLBL_PROD_HIER']
            hierarchy_level1 = None
            hierarchy_level2 = None
            if hier_id and hier_id in self.hierarchy_dict:
                hierarchy_level1 = self.hierarchy_dict[hier_id]['level1']
                hierarchy_level2 = self.hierarchy_dict[hier_id]['level2']
            
            # Extract dimensions from the query BEFORE adding web data
            dimension_extracted = self.extract_dimensions(base_desc, product_id)
            
            # Add web scraped data to query
            enriched_desc = base_desc
            web_text = self.format_web_data(self.get_answer_web_branded(product_id))
            if web_text.strip():
                enriched_desc += web_text
            
            query = {
                'text': enriched_desc,
                'description_with_hierarchy': original_desc,
                'product_id': product_id,
                'description': row['description'],
                'web_display_name': row['Web_Display_Name'],
                'hierarchy': row['MP_GLBL_PROD_HIER'],
                'hierarchy_level1': hierarchy_level1,
                'hierarchy_level2': hierarchy_level2,
                'dimension_extracted': dimension_extracted
            }
            queries.append(query)
        
        msg = f"Prepared {len(queries)} branded queries"
        if filter_product_ids is not None:
            msg += f" (filtered from {len(self.branded_products)} total)"
        if config.USE_LLM_EXPANSION:
            msg += " (with LLM expansion)"
        logger.info(msg)
        return queries
    
    def get_queries_from_ground_truth(self) -> Tuple[list, Dict[str, str]]:
        """
        Build queries only for products that have ground truth mappings.
        Each row in verified_crosses becomes a separate query (handles duplicate branded_ids).
        More efficient for evaluation - loads only needed records.
        
        Returns:
            Tuple of (queries list, ground_truth dict)
            - Each query has a unique ID: "branded_id_row_index" 
            - Ground truth maps unique query ID to ob_product_id
        """
        # Build ground truth mapping - one entry per row (not per branded_id)
        ground_truth = {}
        branded_product_ids = set()
        
        for idx, row in self.verified_crosses.iterrows():
            branded_id = self.clean_product_id(row['branded_product_id'])
            ob_id = self.clean_product_id(row['ob_product_id'])
            
            # Create unique row identifier for this verification row
            query_row_id = f"{branded_id}_row_{idx}"
            ground_truth[query_row_id] = ob_id
            branded_product_ids.add(branded_id)
        
        logger.info(f"Ground truth contains {len(ground_truth)} mappings from {len(branded_product_ids)} unique branded products")
        
        # Convert product IDs to int for filtering (assuming they're integers in the CSV)
        branded_product_ids_int = {int(pid) for pid in branded_product_ids}
        
        # Load only the branded products we need
        logger.info(f"Loading branded products from file (filtering to {len(branded_product_ids)} with ground truth)...")
        branded_products_full = self._load_file(config.BRANDED_PRODUCTS_FILE)
        branded_products_filtered = branded_products_full[
            branded_products_full['product_id'].isin(branded_product_ids_int)
        ].reset_index(drop=True)
        
        logger.info(f"Loaded {len(branded_products_filtered)} branded products with ground truth")
        
        # Clean the filtered data
        branded_products_filtered['description'] = branded_products_filtered['description'].fillna('')
        branded_products_filtered['Web_Display_Name'] = branded_products_filtered['Web_Display_Name'].fillna('')
        
        # Steps 1-2: Build and expand descriptions
        base_descriptions, expanded_descriptions = self.process_product_batch(
            branded_products_filtered, 
            is_query=True
        )
        
        # Step 3: Build query objects - ONE QUERY PER VERIFICATION ROW
        queries = []
        for idx, verification_row in self.verified_crosses.iterrows():
            branded_id = self.clean_product_id(verification_row['branded_product_id'])
            ob_id = self.clean_product_id(verification_row['ob_product_id'])
            
            # Create unique row identifier for this verification row
            query_row_id = f"{branded_id}_row_{idx}"
            
            # Skip if product was filtered out in Step 1 (invalid data)
            if branded_id not in base_descriptions:
                logger.warning(f"Skipping verification row {idx}: branded_id {branded_id} has invalid data")
                continue
            
            # Get the branded product data
            branded_row = branded_products_filtered[branded_products_filtered['product_id'] == int(branded_id)].iloc[0]
            
            original_desc = base_descriptions[branded_id]
            base_desc = expanded_descriptions[branded_id]
            # logger.info(f"------ORIGINAL DESCRIPTION TESTING (Row {idx})------ : \n\n{original_desc}\n")
            # logger.info(f"------NEW DESCRIPTION TESTING (Row {idx})------ : \n\n{base_desc}\n")
            
            # Get hierarchy metadata for filtering
            hier_id = branded_row['MP_GLBL_PROD_HIER']
            hierarchy_level1 = None
            hierarchy_level2 = None
            if hier_id and hier_id in self.hierarchy_dict:
                hierarchy_level1 = self.hierarchy_dict[hier_id]['level1']
                hierarchy_level2 = self.hierarchy_dict[hier_id]['level2']
            
            # Extract dimensions from the query BEFORE adding web data
            dimension_extracted = self.extract_dimensions(base_desc, query_row_id)
            
            # Add web scraped data
            enriched_desc = base_desc
            web_text = self.format_web_data(self.get_answer_web_branded(branded_id))
            if web_text.strip():
                enriched_desc += web_text

            if enriched_desc == base_desc:
                logger.info(f"Appending extra web data for branded product {branded_id}")
                data_from_web = self.get_answer_web_branded_extra(branded_id)
                if data_from_web and isinstance(data_from_web, str):
                    logger.info(f"Added extra web data for branded product {branded_id}")
                    enriched_desc += f"\n\n{data_from_web}"

            logger.info(f"------FINAL DESCRIPTION TEST (Row {idx})------ : \n\n{enriched_desc}\n")

            query = {
                'text': enriched_desc,  # Potentially expanded text
                'description_with_hierarchy': original_desc,  # Preserved original
                'query_row_id': query_row_id,  # Unique ID for this verification row
                'branded_product_id': branded_id,  # Branded product ID
                'ground_truth_ob_id': ob_id,  # Ground truth for this row
                'description': branded_row['description'],
                'web_display_name': branded_row['Web_Display_Name'],
                'hierarchy': branded_row['MP_GLBL_PROD_HIER'],
                'hierarchy_level1': hierarchy_level1,
                'hierarchy_level2': hierarchy_level2,
                'dimension_extracted': dimension_extracted  # Add extracted dimensions
            }
            queries.append(query)
        
        msg = f"Prepared {len(queries)} queries from ground truth"
        if config.USE_LLM_EXPANSION:
            msg += " (with LLM expansion)"
        logger.info(msg)
        
        return queries, ground_truth
    
    def get_queries_from_input_all(self, rows):
        """
        Batch-safe version of get_queries_from_input_one
        with SIMPLE batch expansion (GT-style).

        - Expansion happens ONCE per internal_key
        - Everything else remains identical
        """

        queries = []
        des_with_id = {}
        internal_to_query = {} 

        # ------------------------------------------------
        # Step 0: Collect ONE representative row per key
        # ------------------------------------------------
        unique_rows = {}
        for row in rows:
            key = row["_internal_key"]
            if key not in unique_rows:
                unique_rows[key] = row

        # ------------------------------------------------
        # Step 1: Resolve DB rows / fallback (same logic)
        # ------------------------------------------------
        resolved_rows = {}
        for key, row in unique_rows.items():
            row1 = None

            if row.get("product_id") is not None:
                try:
                    product_id_int = int(row["product_id"])
                    df_match = self.branded_products[
                        self.branded_products["product_id"] == product_id_int
                    ]
                    df_match_ob = self.ob_products[
                        self.ob_products["product_id"] == product_id_int
                    ]
                    if not df_match.empty:
                        row1 = df_match.iloc[0]
                    elif not df_match_ob.empty:
                        row1 = df_match_ob.iloc[0]
                except Exception:
                    pass

            if row1 is None:
                KEY_MAP = {
                    "product_id": "product_id",
                    "product_description": "description",
                    "web_display_name": "Web_Display_Name",
                    "global_product_hierarchy_id": "MP_GLBL_PROD_HIER",
                    "supplier_name": "supplier_name",
                    "mpn": "mpn",
                    "cost": "cost",
                }
                row1 = {KEY_MAP[k]: v for k, v in row.items() if k in KEY_MAP}

            if not isinstance(row1, dict):
                row1 = row1.to_dict()

            # 🔒 Preserve identity
            row1["_internal_key"] = key
            row1["product_id"] = key

            resolved_rows[key] = row1

        # ------------------------------------------------
        # Step 2: Batch expansion (🔥 NEW PART)
        # ------------------------------------------------
        df = pd.DataFrame(resolved_rows.values())
        df["description"] = df["description"].fillna("")
        df["Web_Display_Name"] = df["Web_Display_Name"].fillna("")

        base_descs, expanded_descs = self.process_product_batch(
            df,
            is_query=True
        )

        # ------------------------------------------------
        # Step 3: Build queries (per input row)
        # ------------------------------------------------
        for idx, row in enumerate(rows):
            key = row["_internal_key"]
            row1 = resolved_rows[key]

            branded_id = self.clean_product_id(row1["product_id"])

            original_desc = base_descs[branded_id]
            base_desc = expanded_descs[branded_id]

            query_row_id = f"{branded_id}_row_{idx}"

            internal_to_query[key] = query_row_id

            hierarchy_level1 = None
            hierarchy_level2 = None
            print(row1.get("MP_GLBL_PROD_HIER"))
            hier_id = row1.get("MP_GLBL_PROD_HIER")
            if hier_id:
                hier_id = int(hier_id)
            if hier_id and hier_id in self.hierarchy_dict:
                hierarchy_level1 = self.hierarchy_dict[hier_id].get("level1")
                hierarchy_level2 = self.hierarchy_dict[hier_id].get("level2")

            dimension_extracted = self.extract_dimensions(
                base_desc,
                query_row_id
            )

            enriched_desc = base_desc
            web_text_branded = self.format_web_data(
                self.get_answer_web_branded(branded_id)
            )

            web_text_ob = self.format_web_data(
                self.get_answer_web_ob(branded_id)
            )

            if web_text_branded.strip():
                enriched_desc += web_text_branded
            elif web_text_ob.strip():
                enriched_desc += web_text_ob

            if enriched_desc == base_desc:
                extra_web_data_branded = self.get_answer_web_branded_extra(branded_id)
                extra_web_data_ob = self.get_answer_web_ob_extra(branded_id)
                if extra_web_data_branded and isinstance(extra_web_data_branded, str):
                    enriched_desc += f"\n\n{extra_web_data_branded}"
                elif extra_web_data_ob and isinstance(extra_web_data_ob, str):
                    enriched_desc += f"\n\n{extra_web_data_ob}"

            query = {
                "text": enriched_desc,
                "description_with_hierarchy": original_desc,
                "query_row_id": query_row_id,
                "branded_product_id": branded_id,
                "ground_truth_ob_id": None,
                "description": row1.get("description", ""),
                "web_display_name": row1.get("Web_Display_Name", ""),
                "hierarchy": hier_id,
                "hierarchy_level1": hierarchy_level1,
                "hierarchy_level2": hierarchy_level2,
                "dimension_extracted": dimension_extracted,
            }

            queries.append(query)
            des_with_id[row["_internal_key"]] = enriched_desc

        return queries, des_with_id, internal_to_query
        
    def get_stats(self) -> Dict:
        """Get dataset statistics"""
        return {
            'ob_products': len(self.ob_products) if self.ob_products is not None else 0,
            'branded_products': len(self.branded_products) if self.branded_products is not None else 0,
            'hierarchy_entries': len(self.hierarchy) if self.hierarchy is not None else 0,
            'verified_crosses': len(self.verified_crosses) if self.verified_crosses is not None else 0
        }


if __name__ == "__main__":
    # Test data loading
    logging.basicConfig(level=logging.INFO)
    
    loader = DataLoader()
    loader.load_all_data()
    
    print("\nDataset Statistics:")
    for key, value in loader.get_stats().items():
        print(f"  {key}: {value:,}")
    
    print("\nSample OB Document:")
    docs = loader.prepare_ob_documents()
    if docs:
        print(f"  Product ID: {docs[0]['product_id']}")
        print(f"  Text: {docs[0]['text'][:200]}...")
    
    print("\nSample Branded Query:")
    queries = loader.get_branded_queries()
    if queries:
        print(f"  Product ID: {queries[0]['product_id']}")
        print(f"  Text: {queries[0]['text'][:200]}...")
