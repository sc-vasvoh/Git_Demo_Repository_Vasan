from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, model_validator
import uvicorn
from typing import List, Optional, Literal
from main import run_evaluation_api, run_evaluation_api_all
import uuid

class ProductInput(BaseModel):
    product_id: Optional[str] = None
    product_description: Optional[str] = None
    web_display_name: Optional[str] = None
    global_product_hierarchy_id: Optional[str] = None
    supplier_name: Optional[str] = None
    mpn: Optional[str] = None
    cost: Optional[str] = None

    @model_validator(mode="before")
    def validate_input(cls, values):
        if not values.get("product_id") and not values.get("product_description"):
            raise ValueError("Each product must have at least one of 'product_id' or 'product_description'")
        return values

    model_config = {
        "extra": "forbid"
    }


class ProductMatchRequest(BaseModel):
    products: List[ProductInput] = Field(..., min_items=1)

class RawProductMatchResponse(BaseModel):
    status: str = "success"
    message: str = "API executed successfully."
    data: dict

class ErrorResponse(BaseModel):
    status: str = "error"
    message: str
    data: dict = {}

def answer_all(products: List[ProductInput]):
    """
    Batch-safe evaluation.
    - Generates a stable internal key per product
    - Replaces product_id in input with internal key
    - Keeps original product_id ONLY for response usage
    """

    keyed_inputs = []
    key_order = []
    original_product_ids = {}

    for p in products:
        if p.product_id and p.product_id.strip():
            key = p.product_id.strip()

        key_order.append(key)
        original_product_ids[key] = p.product_id  # store original

        product_dict = p.dict()

        product_dict["product_id"] = key
        product_dict["_internal_key"] = key  # internal only

        keyed_inputs.append(product_dict)

    all_results, des_des, i_to_q = run_evaluation_api_all(keyed_inputs)

    return all_results, des_des, i_to_q, key_order, original_product_ids


app = FastAPI(title="Product Match API (Dummy)", version="1.0.0")


@app.exception_handler(ValueError)
async def handle_value_error(request: Request, exc: ValueError):
    return JSONResponse(status_code=400, content=ErrorResponse(message=str(exc)).dict())

# convert ALL FastAPI/Pydantic validation errors (422) into 400
from fastapi.exceptions import RequestValidationError

@app.exception_handler(RequestValidationError)
async def handle_request_validation_error(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=400,
        content=ErrorResponse(
            message=str(exc),
            data={}
        ).dict()
    )

@app.post("/api/v1/product-match")
async def product_match_batch(req: ProductMatchRequest):
    try:
        all_results, des_with_id, i_to_q, key_order, original_product_ids = answer_all(req.products)
        results = []

        for p, key in zip(req.products, key_order):
            query_row_id = i_to_q[key]

            raw_matches = all_results.get(query_row_id, [])

            description = des_with_id[key]

            results.append(
                {
                    "product_id": original_product_ids[key],
                    "product_description": description,
                    "raw_matches": raw_matches
                }
            )

        return RawProductMatchResponse(
            data={"products": results}
        )

    except Exception as e:
        return JSONResponse(
            status_code=500,
            content=ErrorResponse(
                message="Internal Server Error: " + str(e),
                data={}
            ).dict()
        )

if __name__ == "__main__":
    uvicorn.run("fastapi_product_match_dummy:app", host="0.0.0.0", port=8023, reload=True)
