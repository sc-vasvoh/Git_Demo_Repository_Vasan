"""
Dimension extraction module for Ferguson Product Matching Pipeline
Extracts dimension values from product descriptions using regex patterns
"""

import re
import logging
import json
import os
from typing import List, Dict, Optional
from common import config

logger = logging.getLogger(__name__)

# Global storage for dimension logs
PRODUCT_DIMENSIONS_FILE_PATH = None
QUERY_DIMENSIONS_FILE_PATH = None
PRODUCT_DIMENSIONS_LIST = []
QUERY_DIMENSIONS_LIST = []


def initialize_dimension_files():
    """Initialize dimension log file paths"""
    global PRODUCT_DIMENSIONS_FILE_PATH, QUERY_DIMENSIONS_FILE_PATH
    
    if PRODUCT_DIMENSIONS_FILE_PATH is None:
        # Get file paths from config
        PRODUCT_DIMENSIONS_FILE_PATH = config.DIMENSION_PRODUCTS_FILE
        QUERY_DIMENSIONS_FILE_PATH = config.DIMENSION_QUERIES_FILE
        
        # Create directories if needed
        for file_path in [PRODUCT_DIMENSIONS_FILE_PATH, QUERY_DIMENSIONS_FILE_PATH]:
            dimensions_dir = os.path.dirname(file_path)
            if dimensions_dir:
                os.makedirs(dimensions_dir, exist_ok=True)
        
        logger.info(f"Dimension logging initialized:")
        logger.info(f"  Products: {PRODUCT_DIMENSIONS_FILE_PATH}")
        logger.info(f"  Queries: {QUERY_DIMENSIONS_FILE_PATH}")


def save_dimension_log(
    product_id: str,
    description: str,
    web_display_name: str,
    llm_expansion: str,
    dimension_extracted: List[str],
    is_query: bool = False,
    matching_products: Optional[Dict[str, List[str]]] = None,
    matching_count: int = 0
):
    """
    Log dimension extraction to in-memory list (saves to file only when flush is called)
    Also logs to console for visibility during processing
    
    Args:
        product_id: Product or query ID
        description: Original description
        web_display_name: Web display name
        llm_expansion: LLM expanded text
        dimension_extracted: List of extracted dimension values
        is_query: Whether this is a query (True) or product (False)
        matching_products: Dict mapping product IDs to their dimensions (only for queries, before semantic search)
        matching_count: Count of matching products (only for queries, before semantic search)
    """
    global PRODUCT_DIMENSIONS_LIST, QUERY_DIMENSIONS_LIST
    
    # Initialize files if not done yet
    initialize_dimension_files()
    
    # Log to console for visibility
    item_type = "QUERY" if is_query else "PRODUCT"
    logger.info(f"{'='*80}")
    logger.info(f"📏 DIMENSION EXTRACTION - {item_type}: {product_id}")
    logger.info(f"Original Description: {description[:100]}..." if len(description) > 100 else f"Original Description: {description}")
    logger.info(f"Web Display Name: {web_display_name}")
    
    # Show LLM expansion if available
    if llm_expansion:
        logger.info(f"LLM Expansion: {llm_expansion[:200]}..." if len(llm_expansion) > 200 else f"LLM Expansion: {llm_expansion}")
    
    # Format and log extracted dimensions
    if dimension_extracted:
        inch_dims = dimension_extracted.get('inch', [])
        foot_dims = dimension_extracted.get('foot', [])
        if inch_dims or foot_dims:
            logger.info(f"✅ Dimensions Found:")
            if inch_dims:
                logger.info(f"   • Inch: {', '.join(inch_dims)}")
            if foot_dims:
                logger.info(f"   • Foot: {', '.join(foot_dims)}")
        else:
            logger.info(f"⚠️  No dimensions extracted")
    else:
        logger.info(f"⚠️  No dimensions extracted")
    
    # For queries, log matching info
    if is_query and matching_count > 0:
        logger.info(f"🔍 Matching products before search: {matching_count}")
    
    logger.info(f"{'='*80}")
    
    # Build log entry
    log_entry = {
        'product_id' if not is_query else 'query_id': product_id,
        'product_description' if not is_query else 'query_description': description,
        'web_display_name': web_display_name,
        'llm_expansion': llm_expansion,
        'dimension_extracted': dimension_extracted
    }
    
    # Add matching_products and matching_count for queries
    if is_query and matching_products is not None:
        log_entry['matching_products_before_search'] = matching_products
        log_entry['matching_count_before_search'] = matching_count
    
    # Add to in-memory list (don't save to file yet - will be saved at the end)
    if is_query:
        QUERY_DIMENSIONS_LIST.append(log_entry)
    else:
        PRODUCT_DIMENSIONS_LIST.append(log_entry)


def flush_dimension_logs():
    """
    Save all dimension logs to files at once (called at the end of processing)
    Uses separate config flags for product and query logs
    """
    global PRODUCT_DIMENSIONS_LIST, QUERY_DIMENSIONS_LIST, PRODUCT_DIMENSIONS_FILE_PATH, QUERY_DIMENSIONS_FILE_PATH
    
    # Save product dimensions
    if config.SAVE_PRODUCT_DIMENSION_LOGS:
        if PRODUCT_DIMENSIONS_LIST:
            try:
                with open(PRODUCT_DIMENSIONS_FILE_PATH, 'w', encoding='utf-8') as f:
                    json.dump(PRODUCT_DIMENSIONS_LIST, f, indent=2, ensure_ascii=False)
                logger.info(f"✅ Saved {len(PRODUCT_DIMENSIONS_LIST)} product dimension logs to {PRODUCT_DIMENSIONS_FILE_PATH}")
            except Exception as e:
                logger.warning(f"Failed to save product dimension logs: {e}")
        else:
            logger.info("No product dimension logs to save")
    else:
        logger.info("Product dimension log saving disabled (SAVE_PRODUCT_DIMENSION_LOGS=False)")
    
    # Save query dimensions
    if config.SAVE_QUERY_DIMENSION_LOGS:
        if QUERY_DIMENSIONS_LIST:
            try:
                with open(QUERY_DIMENSIONS_FILE_PATH, 'w', encoding='utf-8') as f:
                    json.dump(QUERY_DIMENSIONS_LIST, f, indent=2, ensure_ascii=False)
                logger.info(f"✅ Saved {len(QUERY_DIMENSIONS_LIST)} query dimension logs to {QUERY_DIMENSIONS_FILE_PATH}")
            except Exception as e:
                logger.warning(f"Failed to save query dimension logs: {e}")
        else:
            logger.info("No query dimension logs to save")
    else:
        logger.info("Query dimension log saving disabled (SAVE_QUERY_DIMENSION_LOGS=False)")



def extract_dimensions_with_units(text: str) -> Dict[str, List[str]]:
    """
    Extract dimension values from text and separate by unit type.
    
    Patterns supported:
    - Fractions: "3/8", "1/2"
    - Mixed numbers (hyphen): "1-1/4", "54-1/4"
    - Mixed numbers (space): "1 1/2", "2 1/4"
    - Whole numbers: "12", "3", "54"
    - Multi-dimensional: "12 by 6", "3 x 4" (split into individual values)
    
    Units supported:
    - inch, inches, in. -> mapped to "inch"
    - foot, feet, ft. -> mapped to "foot"
    
    Example:
        "12 inch panel with 6 foot hose" -> {"inch": ["12"], "foot": ["6"]}
        "3/8 inch and 1/2 foot" -> {"inch": ["3/8"], "foot": ["1/2"]}
    
    Args:
        text: Text to extract dimensions from
        
    Returns:
        Dictionary with "inch" and "foot" keys, each containing list of dimension values
    """
    if not text or not isinstance(text, str):
        return {"inch": [], "foot": []}
    
    # Normalize text to lowercase for matching
    text_lower = text.lower()
    
    # Separate lists for each unit type
    inch_dimensions = []
    foot_dimensions = []
    
    # Track positions of already-matched multi-dimensional patterns
    # to avoid extracting individual dimensions from within them
    excluded_ranges = []
    
    # Define sub-patterns for different number formats
    # Order matters: match more complex patterns first to avoid partial matches
    mixed_hyphen = r'\d+-\d+/\d+'      # 1-1/4, 54-1/4
    mixed_space = r'\d+\s+\d+/\d+'     # 1 1/2
    fraction = r'\d+/\d+'               # 3/8
    whole = r'\d+(?!-\d+/\d+)'          # 12, 54 (but NOT if followed by -digit/digit like in 1-1/4)
    
    # Combined number pattern: matches any valid number format
    number_pattern = rf'(?:{mixed_hyphen}|{mixed_space}|{fraction}|{whole})'
    single_number_pattern = rf'(?:{mixed_hyphen}|{mixed_space}|{fraction}|{whole})'
    
    # ===== INCH PATTERNS =====
    
    # Multi-dimensional inch pattern
    multi_dim_inch_pattern = rf'({number_pattern}(?:\s*(?:by|x)\s*{number_pattern})+)\s*(?:inch(?:es)?\b|in\.)'
    multi_dim_inch_matches = re.finditer(multi_dim_inch_pattern, text_lower, re.IGNORECASE)
    for match in multi_dim_inch_matches:
        dim_value = match.group(1).strip()
        inch_dimensions.append(dim_value)
        excluded_ranges.append((match.start(), match.end()))
    
    # Single dimension inch pattern
    single_inch_pattern = rf'({single_number_pattern})\s*(?:inch(?:es)?\b|in\.)'
    single_inch_matches = re.finditer(single_inch_pattern, text_lower, re.IGNORECASE)
    for match in single_inch_matches:
        match_start = match.start()
        match_end = match.end()
        is_excluded = False
        
        for excluded_start, excluded_end in excluded_ranges:
            if not (match_end <= excluded_start or match_start >= excluded_end):
                is_excluded = True
                break
        
        if not is_excluded:
            dim_value = match.group(1).strip().rstrip('-')
            # Keep all matches, including duplicates (e.g., "1 inch by 1 inch" should extract both)
            inch_dimensions.append(dim_value)
    
    # ===== FOOT PATTERNS =====
    
    # Multi-dimensional foot pattern (matches: foot, feet, ft.)
    multi_dim_foot_pattern = rf'({number_pattern}(?:\s*(?:by|x)\s*{number_pattern})+)\s*(?:foot|feet\b|ft\.)'
    multi_dim_foot_matches = re.finditer(multi_dim_foot_pattern, text_lower, re.IGNORECASE)
    for match in multi_dim_foot_matches:
        dim_value = match.group(1).strip()
        foot_dimensions.append(dim_value)
        excluded_ranges.append((match.start(), match.end()))
    
    # Single dimension foot pattern (matches: foot, feet, ft.)
    single_foot_pattern = rf'({single_number_pattern})\s*(?:foot|feet\b|ft\.)'
    single_foot_matches = re.finditer(single_foot_pattern, text_lower, re.IGNORECASE)
    for match in single_foot_matches:
        match_start = match.start()
        match_end = match.end()
        is_excluded = False
        
        for excluded_start, excluded_end in excluded_ranges:
            if not (match_end <= excluded_start or match_start >= excluded_end):
                is_excluded = True
                break
        
        if not is_excluded:
            dim_value = match.group(1).strip().rstrip('-')
            # Keep all matches, including duplicates (e.g., "6 foot by 6 foot" should extract both)
            foot_dimensions.append(dim_value)
    
    # Split multi-dimensional values (e.g., "12 x 6" -> ["12", "6"])
    def split_multi_dim(dimensions):
        split_dims = []
        for dim in dimensions:
            if ' x ' in dim or ' by ' in dim:
                parts = re.split(r'\s*(?:x|by)\s*', dim, flags=re.IGNORECASE)
                split_dims.extend(parts)
            else:
                split_dims.append(dim)
        return split_dims
    
    inch_dimensions = split_multi_dim(inch_dimensions)
    foot_dimensions = split_multi_dim(foot_dimensions)
    
    # Clean up dimensions (strip whitespace) but keep duplicates
    # Duplicates are meaningful (e.g., "1 inch by 1 inch" is a 1x1 square)
    def clean_dimensions(items):
        cleaned = []
        for item in items:
            item = item.strip()
            if item:
                cleaned.append(item)
        return cleaned
    
    return {
        "inch": clean_dimensions(inch_dimensions),
        "foot": clean_dimensions(foot_dimensions)
    }


def extract_dimensions(text: str) -> Dict[str, List[str]]:
    """
    Extract dimension values from text using regex patterns - returns dictionary separated by unit
    
    Extraction rules:
    - Fraction: "3/8 inch" -> {"inch": ["3/8"], "foot": []}
    - Mixed number with hyphen: "1-1/4 inch" -> {"inch": ["1-1/4"], "foot": []}
    - Whole number with hyphen: "4-inch" -> {"inch": ["4"], "foot": []}
    - Multiple dimensions: "1/4 inch by 2-1/4 inches" -> {"inch": ["1/4", "2-1/4"], "foot": []}
    - Dimensions with "by": "12 by 6 inch" -> {"inch": ["12", "6"], "foot": []} (split)
    - Mixed number with space: "1 1/2 inch" -> {"inch": ["1 1/2"], "foot": []}
    - Dimensions with "x": "3 x 4 inch" -> {"inch": ["3", "4"], "foot": []} (split)
    - Mixed units: "12 inch and 6 foot" -> {"inch": ["12"], "foot": ["6"]}
    
    Args:
        text: Text to extract dimensions from
        
    Returns:
        Dictionary with "inch" and "foot" keys, each containing list of dimension values
    """
    return extract_dimensions_with_units(text)


def extract_dimensions_legacy(text: str) -> List[str]:
    """
    Legacy function that returns a flat list of dimensions (for backward compatibility if needed)
    
    Args:
        text: Text to extract dimensions from
        
    Returns:
        List of extracted dimension values (as strings) - combines inch and foot dimensions
    """
    # Use the new function and combine results
    dims_by_unit = extract_dimensions_with_units(text)
    
    # Combine inch and foot dimensions into a single list
    combined = []
    combined.extend(dims_by_unit["inch"])
    combined.extend(dims_by_unit["foot"])
    
    return combined


def log_product_dimensions(
    product_id: str,
    description: str,
    web_display_name: str,
    llm_expansion: str,
    dimension_extracted: Dict[str, List[str]]
):
    """
    Log product dimensions to file (on-the-fly)
    
    Args:
        product_id: Product ID
        description: Original description
        web_display_name: Web display name
        llm_expansion: LLM expanded text
        dimension_extracted: Dictionary with "inch" and "foot" keys, each containing list of dimensions
    """
    save_dimension_log(
        product_id=product_id,
        description=description,
        web_display_name=web_display_name,
        llm_expansion=llm_expansion,
        dimension_extracted=dimension_extracted,
        is_query=False
    )
    
    logger.debug(f"Logged product {product_id} with {len(dimension_extracted)} dimensions")


def log_query_dimensions(
    query_id: str,
    description: str,
    web_display_name: str,
    dimension_extracted: Dict[str, List[str]],
    matching_products_before_search: Dict[str, List[str]] = None,
    matching_count_before_search: int = 0
):
    """
    Log query dimensions to file (on-the-fly)
    
    Args:
        query_id: Query ID
        description: Query description
        web_display_name: Web display name
        dimension_extracted: Dictionary with "inch" and "foot" keys, each containing list of dimensions
        matching_products_before_search: Dict mapping product IDs to their dimensions (matched BEFORE semantic search)
        matching_count_before_search: Count of matching products BEFORE semantic search
    """
    save_dimension_log(
        product_id=query_id,
        description=description,
        web_display_name=web_display_name,
        llm_expansion="",  # Queries don't need LLM expansion logged here
        dimension_extracted=dimension_extracted,
        is_query=True,
        matching_products=matching_products_before_search or {},
        matching_count=matching_count_before_search
    )
    
    logger.debug(f"Logged query {query_id} with {len(dimension_extracted)} dimensions and {matching_count_before_search} matches before search")
