import uuid
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, model_validator
from typing import List, Optional


# =========================
# Input Models (UNCHANGED)
# =========================

class ProductInput(BaseModel):
    product_id: Optional[str] = None
    product_description: Optional[str] = None
    web_display_name: Optional[str] = None
    global_product_hierarchy_id: Optional[str] = None
    supplier_name: Optional[str] = None
    mpn: Optional[str] = None
    cost: Optional[str] = None

    @model_validator(mode="before")
    def validate_input(cls, values):
        if not values.get("product_id") and not values.get("product_description"):
            raise ValueError(
                "Each product must have at least one of 'product_id' or 'product_description'"
            )
        return values

    model_config = {"extra": "forbid"}

class ProductInputReason(BaseModel):
    product_id: Optional[str] = None
    product_description: Optional[str] = None
    web_display_name: Optional[str] = None
    global_product_hierarchy_id: Optional[str] = None
    supplier_name: Optional[str] = None
    mpn: Optional[str] = None
    cost: Optional[str] = None
    ob_complete_product_description: str
    query_product_id: str
    query_product_description: str
    # match_perc: float
    # match_reasoning: str

class ProductMatchRequest(BaseModel):
    products: List[ProductInput] = Field(..., min_items=1)


class MatchedProduct(BaseModel):
    product_id: str
    product_description: str
    web_display_name: Optional[str]
    global_product_hierarchy_id: Optional[str]
    supplier_name: Optional[str]
    mpn: Optional[str]
    cost: Optional[str]
    match_perc: float
    match_reasoning: str
    ob_product_complete_description: str


class ProductMatchResult(BaseModel):
    product_id: Optional[str]
    product_description: Optional[str]
    match_products: List[MatchedProduct]

class ProductReasonResult(BaseModel):
    reason: str

class ProductMatchResponseData(BaseModel):
    products: List[ProductMatchResult]


class SuccessResponse(BaseModel):
    status: str = "success"
    message: str = "API executed successfully."
    data: ProductMatchResponseData

class SuccessResponse2(BaseModel):
    status: str = "success"
    message: str = "API executed successfully."
    data: ProductReasonResult

class ErrorResponse(BaseModel):
    status: str = "error"
    message: str
    data: dict = {}


# =========================
# Helpers
# =========================

def inject_canonical_ids(products: List[ProductInput]):
    updated_products = []
    key_map = {}
    desc_map = {}

    for p in products:
        if p.product_id and p.product_id.strip():
            canonical_id = p.product_id.strip()
        else:
            canonical_id = f"agg_dummy_{uuid.uuid4().hex}"

        key_map[canonical_id] = p.product_id
        desc_map[canonical_id] = p.product_description

        prod_dict = p.dict()
        prod_dict["product_id"] = canonical_id
        updated_products.append(prod_dict)

    return updated_products, key_map, desc_map


def generate_dummy_matches(description: str, count: int = 20) -> List[MatchedProduct]:
    results = []

    for i in range(count):
        results.append(
            MatchedProduct(
                product_id=f"DUMMY_MATCH_{i+1}",
                product_description=f"Dummy matched product {i+1} for {description}",
                web_display_name=f"Dummy Product {i+1}",
                global_product_hierarchy_id=str(1000 + i),
                supplier_name="Dummy Supplier",
                mpn=f"DUMMY-MPN-{i+1}",
                cost=str(round(10 + i * 1.5, 2)),
                match_perc=round(98 - i * 1.1, 2),
                match_reasoning="Dummy match generated for UI testing.",
                ob_product_complete_description="DUMMY DESCRIPTION"
            )
        )

    return results


# =========================
# FastAPI App
# =========================

app = FastAPI(
    title="Product Match Dummy API",
    version="1.0.0",
)


@app.exception_handler(ValueError)
async def handle_value_error(request: Request, exc: ValueError):
    return JSONResponse(
        status_code=400,
        content=ErrorResponse(message=str(exc)).dict(),
    )


@app.post(
    "/api/v1/product-match",
    response_model=SuccessResponse,
)
async def product_match_dummy(req: ProductMatchRequest):
    products_with_ids, key_map, desc_map = inject_canonical_ids(req.products)
    final_products = []

    for prod in products_with_ids:
        canonical_id = prod["product_id"]

        final_products.append(
            ProductMatchResult(
                product_id=key_map.get(canonical_id),
                product_description=desc_map.get(canonical_id),
                match_products=generate_dummy_matches(
                    desc_map.get(canonical_id) or "Unknown product"
                ),
            )
        )

    return SuccessResponse(
        data=ProductMatchResponseData(products=final_products)
    )

@app.post(
    "/api/v1/product-match-reason",
    response_model=SuccessResponse2,
)
async def product_match_dummy(req: ProductInputReason):
    print(req)
    a = ProductReasonResult(reason="Dummy Reasoning")
    print(a)
    return SuccessResponse2(
        data=a
    )

# @app.post(
#     "/api/v1/product-match-non-progressive",
#     response_model=SuccessResponse,
# )
# async def product_match_non_progressive_dummy(req: ProductMatchRequest):
#     products_with_ids, key_map, desc_map = inject_canonical_ids(req.products)
#     final_products = []

#     for prod in products_with_ids:
#         canonical_id = prod["product_id"]

#         final_products.append(
#             ProductMatchResult(
#                 product_id=key_map.get(canonical_id),
#                 product_description=desc_map.get(canonical_id),
#                 match_products=generate_dummy_matches(
#                     desc_map.get(canonical_id) or "Unknown product"
#                 ),
#             )
#         )

#     return SuccessResponse(
#         data=ProductMatchResponseData(products=final_products)
#     )
