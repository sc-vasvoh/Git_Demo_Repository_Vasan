#__all__ = [
#    "progressive_merge_multiple_lists",
#    "compute_metrics_for_k"
#]
"""
Progressive Reranking Algorithm - Two-Stage with Boundary-Based Merging

This module implements a two-stage progressive reranking algorithm:

STAGE 1: Individual Group Sorting
1. Split top_100 into groups of 20 each (5 groups: A, B, C, D, E)
2. LLM rerank each group individually (5 LLM calls)
   - Ensures each group is internally optimized
   - Best items rise to the top of each group

STAGE 2: Progressive Merging with Boundary Detection
3. Progressively merge sorted groups using the boundary-based algorithm:
   - Take K items from each list (e.g., K=10)
   - Deduplicate and combine
   - LLM rerank the combined batch
   - Find boundary (minimum of last items from each batch in reranked list)
   - Promote all items up to boundary to result
   - Keep unpromoted items for next iteration
   - Repeat until one list is exhausted
   - Append remaining items from both lists

This combines the benefits of:
- Pre-sorted groups (Stage 1)
- Intelligent boundary-based promotion (Stage 2)
- Multiple LLM passes for quality refinement

Note: This module contains only the core algorithm functions.
For parallel processing, use run_progressive_rerank.py
"""

import time
from typing import List, Dict, Optional
import json
import concurrent.futures


def progressive_merge_two_lists(
    query_id: str,
    query_text: str,
    list_a: List[Dict],
    list_b: List[Dict],
    batch_size: int,
    llm_reranker,
    log_file: Optional[object] = None
) -> tuple[List[Dict], int]:
    """
    Progressively merge two ALREADY SORTED lists using boundary-based promotion.
    
    This function implements the progressive merge algorithm:
    1. Take K items from each list
    2. Deduplicate and combine them
    3. Use LLM to re-rank the combined batch
    4. Find boundary (min of last items from each batch in reranked list)
    5. Promote all items up to boundary
    6. Keep unpromoted items for next iteration
    7. Repeat until one list is exhausted
    
    Args:
        query_id: The branded product ID
        query_text: The search query
        list_a: First sorted list of matches
        list_b: Second sorted list of matches
        batch_size: Number of items to take from each list per iteration (K)
        llm_reranker: LLM reranker instance with rerank() method
        log_file: File handle for logging (optional)
    
    Returns:
        Tuple of (merged_list, llm_calls_count):
        - merged_list: Merged and re-ranked list
        - llm_calls_count: Number of LLM calls made during merging
    """
    
    def log(msg: str):
        """Log to file if available"""
        if log_file:
            log_file.write(msg + '\n')
            log_file.flush()
    
    merge_start = time.time()
    
    # Work with copies to avoid modifying originals
    A = list_a.copy()
    B = list_b.copy()
    R = []  # Result list
    
    # Track LLM calls for this merge
    merge_llm_calls = 0
    
    log(f"  Progressive merge: A ({len(A)} items) with B ({len(B)} items)")
    log(f"  Batch size (K): {batch_size}")
    
    iteration = 0
    
    while len(A) > 0 and len(B) > 0:
        iteration += 1
        iter_start = time.time()
        
        # Take batch_size elements from the START of each list
        a_batch = A[:batch_size]
        b_batch = B[:batch_size]
        
        # Combine batches
        combined_batch = a_batch + b_batch
        
        # Deduplicate combined batch BEFORE sending to LLM
        seen_ids = set()
        unique_batch = []
        duplicate_count = 0
        
        for node in combined_batch:
            node_id = node.get('product_id', node.get('id'))
            if node_id not in seen_ids:
                seen_ids.add(node_id)
                unique_batch.append(node)
            else:
                duplicate_count += 1
        
        log(f"    Iteration {iteration}: {len(a_batch)} from A + {len(b_batch)} from B = {len(combined_batch)} nodes")
        if duplicate_count > 0:
            log(f"      → Removed {duplicate_count} duplicates, sending {len(unique_batch)} unique to LLM")
        
        # LLM re-rank the UNIQUE batch only
        llm_start = time.time()
        reranked_batch = llm_reranker.rerank(
            query_id=query_id,
            query_text=query_text,
            results=unique_batch,
            top_n=len(unique_batch)
        )
        merge_llm_calls += 1  # Count LLM call for this iteration
        llm_time = time.time() - llm_start
        
        # Find the last position of elements from each batch in the reranked list
        a_batch_ids = {node.get('product_id', node.get('id')) for node in a_batch}
        b_batch_ids = {node.get('product_id', node.get('id')) for node in b_batch}
        
        a_last_rank = None
        a_last_id = None
        b_last_rank = None
        b_last_id = None
        
        # Find the maximum position of any element from a_batch
        for idx, node in enumerate(reranked_batch):
            node_id = node.get('product_id', node.get('id'))
            if node_id in a_batch_ids:
                a_last_rank = idx
                a_last_id = node_id
        
        # Find the maximum position of any element from b_batch
        for idx, node in enumerate(reranked_batch):
            node_id = node.get('product_id', node.get('id'))
            if node_id in b_batch_ids:
                b_last_rank = idx
                b_last_id = node_id
        
        # Determine boundary (minimum of the two last ranks)
        if a_last_rank is not None and b_last_rank is not None:
            if a_last_rank < b_last_rank:
                boundary_id = a_last_id
                boundary_rank = a_last_rank
            else:
                boundary_id = b_last_id
                boundary_rank = b_last_rank
        elif a_last_rank is not None:
            boundary_id = a_last_id
            boundary_rank = a_last_rank
        elif b_last_rank is not None:
            boundary_id = b_last_id
            boundary_rank = b_last_rank
        else:
            log(f"      Warning: Could not find boundary, breaking")
            break
        
        # Promote all nodes ranked up to and including boundary
        promoted = reranked_batch[:boundary_rank + 1]
        
        log(f"      Boundary: {boundary_id} at rank {boundary_rank}")
        log(f"      Promoting {len(promoted)} nodes")
        
        # Add promoted nodes to result
        R.extend(promoted)
        
        # Remove promoted nodes from A and B (keep unpromoted for next iteration)
        promoted_ids = {node.get('product_id', node.get('id')) for node in promoted}
        
        A = [node for node in A if node.get('product_id', node.get('id')) not in promoted_ids]
        B = [node for node in B if node.get('product_id', node.get('id')) not in promoted_ids]
        
        iter_time = time.time() - iter_start
        log(f"      Remaining: A has {len(A)}, B has {len(B)}")
        log(f"      Iteration time: {iter_time:.2f}s (LLM: {llm_time:.2f}s)")
    
    # Append remaining elements from A and B
    log(f"    Appending {len(A)} remaining from A, {len(B)} remaining from B")
    R.extend(A)
    R.extend(B)
    
    merge_total_time = time.time() - merge_start
    log(f"    Final merged list: {len(R)} nodes in {merge_total_time:.2f}s")
    log(f"    LLM calls for this merge: {merge_llm_calls}\n")
    
    return R, merge_llm_calls


def progressive_merge_multiple_lists(
    query_id: str,
    query_text: str,
    lists: List[List[Dict]],
    batch_size: int,
    llm_reranker,
    log_file: Optional[object] = None
) -> tuple[List[Dict], int]:
    """
    Progressively merge N sorted lists (from different pipelines) using boundary-based promotion.
    No group splitting or sorting is performed; input lists are assumed to be in pipeline order.
    
    Args:
        query_id: The branded product ID
        query_text: The search query
        lists: List of lists, each from a pipeline
        batch_size: Number of items to take from each list per iteration (K)
        llm_reranker: LLM reranker instance with rerank() method
        log_file: File handle for logging (optional)
    
    Returns:
        Tuple of (merged_list, llm_calls_count):
        - merged_list: Merged and re-ranked list
        - llm_calls_count: Number of LLM calls made during merging
    """
    def log(msg: str):
        if log_file:
            log_file.write(msg + '\n')
            log_file.flush()

    merge_start = time.time()
    # Work with copies to avoid modifying originals
    lists = [lst.copy() for lst in lists]
    n = len(lists)
    log(f"  Progressive pairwise merge: {n} pipelines, batch size (K): {batch_size}")
    if n == 0:
        return [], 0
    if n == 1:
        return lists[0], 0
    log(f" \nMerging first two lists...\n")

    # Start by merging the first two lists
    merged, llm_calls = progressive_merge_two_lists(
        query_id=query_id,
        query_text=query_text,
        list_a=lists[0],
        list_b=lists[1],
        batch_size=batch_size,
        llm_reranker=llm_reranker,
        log_file=log_file
    )
    log(f" \nMerging of subsequent lists...\n")

    # Merge the result with each subsequent list
    for i in range(2, n):
        merged, llm_calls_new = progressive_merge_two_lists(
            query_id=query_id,
            query_text=query_text,
            list_a=merged,
            list_b=lists[i],
            batch_size=batch_size,
            llm_reranker=llm_reranker,
            log_file=log_file
        )
        llm_calls += llm_calls_new
    merge_total_time = time.time() - merge_start
    log(f"    Final merged list: {len(merged)} nodes in {merge_total_time:.2f}s")
    log(f"    LLM calls for this merge: {llm_calls}\n")
    return merged, llm_calls


def compute_metrics_for_k(reranked_results: List[Dict]) -> Dict:
    """
    Compute comprehensive metrics for reranked results.
    
    Args:
        reranked_results: List of reranked records with reranked_matches
    
    Returns:
        Dictionary containing all metrics:
        - total_products: Total number of products
        - found_in_results: Number of products where correct match was found
        - Top-K Accuracy: Accuracy for K in [1, 3, 5, 10, 20, 35, 50]
        - Top-K Count: Count for K in [1, 3, 5, 10, 20, 35, 50]
        - Mean Rank: Average rank of correct product
        - Median Rank: Median rank of correct product
        - MRR: Mean Reciprocal Rank
    """
    top_k_values = [1, 3, 5, 10, 20, 35, 50, 100]
    top_k_correct = {k: 0 for k in top_k_values}
    ranks = []
    reciprocal_ranks = []
    total = len(reranked_results)
    
    for record in reranked_results:
        correct_ob_id = record['correct_ob_product_id']
        # Use reranked_matches (the full reranked list of 100 items)
        reranked_list = record['reranked_matches']
        
        # Find rank of correct product in the reranked list
        rank = None
        for idx, match in enumerate(reranked_list, 1):
            if match.get('product_id', match.get('id')) == correct_ob_id:
                rank = idx
                break
        
        if rank is not None:
            ranks.append(rank)
            reciprocal_ranks.append(1.0 / rank)
            
            # Count for each top-k
            for k in top_k_values:
                if rank <= k:
                    top_k_correct[k] += 1
        else:
            # Correct product not found
            ranks.append(float('inf'))
            reciprocal_ranks.append(0.0)
    
    # Compute metrics
    metrics = {
        'total_products': total,
        'found_in_results': sum(1 for r in ranks if r != float('inf'))
    }
    
    for k in top_k_values:
        accuracy = (top_k_correct[k] / total) * 100
        metrics[f'Top-{k} Accuracy'] = accuracy
        metrics[f'Top-{k} Count'] = top_k_correct[k]
    
    valid_ranks = [r for r in ranks if r != float('inf')]
    metrics['Mean Rank'] = sum(valid_ranks) / len(valid_ranks) if valid_ranks else 0
    metrics['Median Rank'] = sorted(valid_ranks)[len(valid_ranks)//2] if valid_ranks else 0
    metrics['MRR'] = sum(reciprocal_ranks) / len(reciprocal_ranks) if reciprocal_ranks else 0
    
    return metrics


def save_reranked_results(reranked_results: List[Dict], output_path: str):
    """
    Save reranked results to JSON file.
    
    Args:
        reranked_results: List of reranked records
        output_path: Output JSON file path
    """
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(reranked_results, f, indent=2, ensure_ascii=False)
    print(f"✓ Saved reranked results to: {output_path}")
