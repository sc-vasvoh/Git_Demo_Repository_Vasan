import os
import json
import argparse
import time
import re
from datetime import datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from typing import Dict, List, Any, Optional, Tuple
import dotenv
from openai import OpenAI
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from tqdm import tqdm
dotenv.load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
INPUT_FILE: Optional[str] = None
OUTPUT_FILE: Optional[str] = None
MAX_WORKERS: int = 5
TOP_K: int = 20
START_INDEX: int = 0
API_KEY: str = OPENAI_API_KEY

def extract_json_safe(json_string: str) -> Dict[str, str]:

    try:
        return json.loads(json_string)
    except json.JSONDecodeError:
        pass
    
    try:
        last_brace = json_string.rfind('}')
        if last_brace != -1:
            truncated = json_string[:last_brace + 1]
            return json.loads(truncated)
    except json.JSONDecodeError:
        pass
    
    try:
        result = {}
        pattern = r'"([^"]+)"\s*:\s*"((?:[^"\\]|\\.)*)"'
        matches = re.findall(pattern, json_string)
        
        for key, value in matches:
            value = value.replace('\\"', '"').replace('\\n', '\n').replace('\\\\', '\\')
            result[key] = value
        
        if result:
            return result
    except Exception as e:
        print(f"⚠️ Regex extraction failed: {e}")

    try:
        start = json_string.find('{')
        end = json_string.rfind('}')
        if start != -1 and end != -1 and end > start:
            candidate = json_string[start:end + 1]
            return json.loads(candidate)
    except:
        pass
    
    print(f"⚠️ All JSON extraction strategies failed. Returning empty dict.")
    return {}

class OpenAIProcessor:
    
    def __init__(self, api_key: str):
        self.client = OpenAI(api_key=api_key)
    
    @retry(
        retry=retry_if_exception_type((Exception)),
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=4, max=60),
        reraise=True
    )
    def call_gpt4_mini_with_retry(self, messages: List[Dict[str, str]]) -> str:
        """
        Call GPT-4o-mini with retry logic for rate limits
        
        Args:
            messages: List of message dictionaries for chat completion
            
        Returns:
            Response content as string
        """
        try:
            response = self.client.chat.completions.create(
                model="gpt-4.1-mini",
                messages=messages,
                temperature=0.0,
                max_tokens=4000,
                response_format={"type": "json_object"}
            )
            return response.choices[0].message.content
        except Exception as e:
            if "rate_limit" in str(e).lower() or "quota" in str(e).lower():
                print(f"⚠️ Rate limit/quota hit, retrying... Error: {e}")
                raise  # Will trigger retry
            else:
                print(f"✗ Error calling API: {e}")
                raise
    
    def create_reasoning_prompt(self, branded_product: Dict, matches: List[Dict]) -> str:
        """
        Create a prompt for GPT-4o-mini to generate structured reasoning
        
        Args:
            branded_product: Dictionary containing branded product info
            matches: List of top-k matched products
            
        Returns:
            Formatted prompt string
        """
        
        prompt = f"""You are analyzing product matches for Ferguson company products. 

**BRANDED PRODUCT (Query Product):**
- ID: {branded_product.get('branded_product_id', branded_product.get('branded_product_id_cleaned', 'N/A'))}
- Description: {branded_product.get('branded_query_text', 'N/A')}

**YOUR TASK:**
Compare the branded product above with EACH of the following {len(matches)} candidate products independently and provide structured reasoning for why each is recommended.

**MATCHING CRITERIA (in order of importance):**
1. Product type / category (highest weight)
2. Key dimensions and units
3. Material
4. Color / finish
5. Technical specifications

**CANDIDATE PRODUCTS TO ANALYZE:**
"""
        
        for idx, match in enumerate(matches, start=1):
            prompt += f"""
---
**Candidate #{idx} (ID: {match['product_id']})**
- Category: {match.get('hierarchy_level1', 'N/A')}
- Full Description: {match.get('text', 'N/A')}
- Current Reason: {match.get('llm_exact_match_reason_for_score', match.get('llm_rerank_score', 'N/A'))}
"""
        
        prompt += """

**OUTPUT FORMAT:**
Return a JSON object where each key is the candidate product ID and the value is a structured reasoning string.

**REASONING STYLE:**
- Be concise and specific (1-2 sentences max)
- Focus on similarities first, then differences
- Mention exact values when comparing (e.g., "1 in vs 3/4 in")
- Example style: "The finish type is identical; however the dimensions vary and the materials are inconsistent, as one is coated while the other is galvanized"
- Example style: "Same product type, material, and color; diameter matches at 1 in, but length differs (300 ft vs 100 ft)"

Return ONLY valid JSON in this format:
{
  "product_id_1": "structured reasoning here",
  "product_id_2": "structured reasoning here",
  ...
}
"""
        
        return prompt

class ProgressTracker:
    """Thread-safe progress tracker"""
    
    def __init__(self, total: int):
        self.total = total
        self.success_count = 0
        self.error_count = 0
        self.partial_count = 0
        self.lock = Lock()
        self.start_time = time.time()
    
    def increment_success(self):
        with self.lock:
            self.success_count += 1
    
    def increment_error(self):
        with self.lock:
            self.error_count += 1
    
    def increment_partial(self):
        with self.lock:
            self.partial_count += 1
    
    def get_stats(self) -> Dict[str, Any]:
        with self.lock:
            elapsed = time.time() - self.start_time
            processed = self.success_count + self.error_count
            return {
                'total': self.total,
                'processed': processed,
                'success': self.success_count,
                'errors': self.error_count,
                'partial': self.partial_count,
                'elapsed': elapsed,
                'avg_time': elapsed / processed if processed > 0 else 0
            }

def process_single_product(
    branded_product: Dict,
    index: int,
    top_k: int,
    api_processor: OpenAIProcessor,
    progress_tracker: ProgressTracker
) -> Tuple[int, bool, int]:
    
    branded_id = branded_product.get('branded_product_id', branded_product.get('branded_product_id_cleaned', 'Unknown'))
    all_matches = branded_product.get('reranked_matches', [])
    matches = all_matches[:top_k]
    
    try:
        prompt = api_processor.create_reasoning_prompt(branded_product, matches)
        print(prompt)
        messages = [
            {
                "role": "system",
                "content": "You are an expert at analyzing product matches for Ferguson company products. Provide structured, concise reasoning."
            },
            {
                "role": "user",
                "content": prompt
            }
        ]
        
        response = api_processor.call_gpt4_mini_with_retry(messages)
        structured_reasons = extract_json_safe(response)
        matches_found = 0
        matches_missing = 0
        
        for match in matches:
            match_id = match['product_id']
            if match_id in structured_reasons:
                match['structured_reason'] = structured_reasons[match_id]
                matches_found += 1
            else:
                match['structured_reason'] = "Reasoning not available"
                matches_missing += 1
        
        # Track statistics
        if matches_missing > 0:
            progress_tracker.increment_partial()
        
        progress_tracker.increment_success()
        return (index, True, len(matches))
        
    except Exception as e:
        for match in matches:
            match['structured_reason'] = f"Error generating reasoning: {str(e)}"
        
        progress_tracker.increment_error()
        return (index, False, 0)


def process_batch_threaded(
    data: List[Dict],
    api_processor: OpenAIProcessor
) -> Dict[str, Any]:
    total = len(data) - START_INDEX
    progress_tracker = ProgressTracker(total)

    print(f"\n{'='*70}")
    print(f"Starting parallel processing with {MAX_WORKERS} workers")
    print(f"Processing {total} products (indices {START_INDEX} to {len(data)-1})")
    print(f"Top-K matches per product: {TOP_K}")
    print(f"{'='*70}\n")
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(
                process_single_product,
                data[i],
                i,
                TOP_K,
                api_processor,
                progress_tracker
            ): i for i in range(START_INDEX, len(data))
        }

        with tqdm(total=total, desc="Processing", unit="product") as pbar:
            for future in as_completed(futures):
                try:
                    index, success, matches_processed = future.result()
                    pbar.update(1)
                    
                    stats = progress_tracker.get_stats()
                    pbar.set_postfix({
                        'Success': stats['success'],
                        'Errors': stats['errors'],
                        'Avg Time': f"{stats['avg_time']:.1f}s"
                    })
                    
                except Exception as e:
                    print(f"\n✗ Unexpected error in thread: {e}")
                    pbar.update(1)
    print(progress_tracker.get_stats())
    return data
