import json
import pandas as pd
import json
import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from datetime import datetime
from reranking.llm_exact_match_reranker import LLMExactMatchReranker
from api.progressive_rerank import progressive_merge_multiple_lists
llm_reranker = LLMExactMatchReranker()
K_VALUE = 20

def get_top_n_from_record(record, n=35):
    top_keys = ['raw_matches']
    for key in top_keys:
        if key in record and isinstance(record[key], list):
            return record[key][:n]
    all_matches = []
    seen_ids = set()
    for key in top_keys:
        if key in record and isinstance(record[key], list):
            for match in record[key]:
                if isinstance(match, dict) and 'product_id' in match:
                    if match['product_id'] not in seen_ids:
                        seen_ids.add(match['product_id'])
                        all_matches.append(match)
                        if len(all_matches) >= n:
                            return all_matches[:n]
    return all_matches[:n]

def prepare_separate_pipelines(records, n=35):
    result = {}
    for idx, rec in enumerate(records, 1):
        result[f'pipeline_{idx}'] = get_top_n_from_record(rec, n)
    return result

def deduplicate_pipeline_matches_cascading_pipeline_matches(record):
    seen = set()
    dedup_lists = []
    match_lengths = []
    original_branded_id = record['branded_product_id']
    cleaned_branded_id = original_branded_id
    for match_list in record.get('pipeline_matches', []):
        deduped = []
        for match in match_list:
            if not isinstance(match, dict):
                continue
            product_id = match.get('product_id', match.get('id'))
            if not product_id:
                continue
            if product_id in seen:
                continue
            seen.add(product_id)
            deduped.append(match)
        dedup_lists.append(deduped)
        match_lengths.append(len(deduped))
    print("PIPELINE MATCH RESULTS", match_lengths)
    return {
        'branded_product_id': original_branded_id,
        'branded_product_id_cleaned': cleaned_branded_id,
        'branded_query_text': record.get('branded_query_text'),
        'pipeline_matches': dedup_lists,
        'pipeline_match_lengths': match_lengths
    }
    
def convert_json_format(pipeline1, pipeline2, pipeline3):
    pipeline_experiments = []
    pipeline_experiments.append(pipeline1)
    pipeline_experiments.append(pipeline2)
    pipeline_experiments.append(pipeline3)
    
    separate_pipeline_results = []
    all_product_ids = set()
    for exp in pipeline_experiments:
        all_product_ids.update(record['product_id'] for record in exp)
    for i, product_id in enumerate(sorted(all_product_ids)):
        matches = []
        branded_query_text = None
        for exp in pipeline_experiments:
            rec = next((r for r in exp if r['product_id'] == product_id), None)
            if rec:
                matches.append(get_top_n_from_record(rec, n=35))
                if branded_query_text is None:
                    branded_query_text = rec.get('product_description', "")
            else:
                matches.append([]) 
        
        separate_pipeline_results.append({
            'branded_product_id': product_id,
            'branded_query_text': branded_query_text,
            'pipeline_matches': matches
        })
    deduplicated_results = []
    for record in separate_pipeline_results:
        dedup_record = deduplicate_pipeline_matches_cascading_pipeline_matches(record)
        deduplicated_results.append(dedup_record)
    
    return deduplicated_results

def process_record(record):
    query_id = record['branded_product_id']
    query_id_cleaned = record['branded_product_id_cleaned']
    query_text = record.get('branded_query_text')
    pipeline_lists = record['pipeline_matches']
    merged, llm_calls = progressive_merge_multiple_lists(
        query_id=query_id_cleaned,
        query_text=query_text,
        lists=pipeline_lists,
        batch_size=K_VALUE,
        llm_reranker=llm_reranker
    )
    print("LLM CALLS", llm_calls)
    return {
        'branded_product_id': query_id,
        'branded_product_id_cleaned': query_id_cleaned,
        'branded_query_text': query_text,
        'reranked_matches': merged,
        'llm_calls': llm_calls
    }
    
def final_pipeline(pipeline1, pipeline2, pipeline3):
    deduplicated_results = convert_json_format(pipeline1, pipeline2, pipeline3)
    merged_results = []
    max_workers = 32
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(process_record, record) for record in deduplicated_results]
        for f in tqdm.tqdm(as_completed(futures), total=len(futures), desc="Progressive merging"):
            merged_results.append(f.result())
    return merged_results
