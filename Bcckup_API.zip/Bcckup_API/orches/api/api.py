import uuid
import asyncio
import httpx
import pandas as pd
from pathlib import Path
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, model_validator
from typing import List, Optional, Literal
import time
from api.final_non_progressive_orchestration import check
from api.final_progressive_orchestration import final_pipeline
import api.reasoning_for_results as reason_final
import os
import dotenv
from common import config
dotenv.load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

USE_PROMT_RESTRUCTURING = True
CACHE_STATUS = False

CACHE_FILE_PATH = Path("/root/him/ferguson/cache_files/ferguson_cache_from_progressive_files.parquet")

PIPELINE_1_URL = "http://localhost:8024/api/v1/product-match"
PIPELINE_2_URL = "http://localhost:8025/api/v1/product-match"
PIPELINE_3_URL = "http://localhost:8026/api/v1/product-match"


# =========================
# Input Models (UNCHANGED)
# =========================

class ProductInput(BaseModel):
    product_id: Optional[str] = None
    product_description: Optional[str] = None
    web_display_name: Optional[str] = None
    global_product_hierarchy_id: Optional[str] = None
    supplier_name: Optional[str] = None
    mpn: Optional[str] = None
    cost: Optional[str] = None

    @model_validator(mode="before")
    def validate_input(cls, values):
        if not values.get("product_id") and not values.get("product_description"):
            raise ValueError(
                "Each product must have at least one of 'product_id' or 'product_description'"
            )
        return values

    model_config = {"extra": "forbid"}


class ProductMatchRequest(BaseModel):
    products: List[ProductInput] = Field(..., min_items=1)


class MatchedProduct(BaseModel):
    product_id: str
    product_description: str
    web_display_name: Optional[str]
    global_product_hierarchy_id: Optional[str]
    supplier_name: Optional[str]
    mpn: Optional[str]
    cost: Optional[str]
    match_perc: float
    match_reasoning: str


class ProductMatchResult(BaseModel):
    product_id: Optional[str]
    product_description: Optional[str]
    match_products: List[MatchedProduct]


class ProductMatchResponseData(BaseModel):
    products: List[ProductMatchResult]


class SuccessResponse(BaseModel):
    status: str = "success"
    message: str = "API executed successfully."
    data: ProductMatchResponseData


class ErrorResponse(BaseModel):
    status: str = "error"
    message: str
    data: dict = {}


def load_cache_df() -> pd.DataFrame:
    if CACHE_FILE_PATH.exists():
        return pd.read_parquet(CACHE_FILE_PATH)
    return pd.DataFrame(columns=["product_id", "cached_result"])

def save_to_cache(product_id: str, result: ProductMatchResult):
    df = load_cache_df()

    new_row = {
        "product_id": product_id,
        "cached_result": result.dict(),
    }

    df = df[df["product_id"] != product_id]
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

    df.to_parquet(CACHE_FILE_PATH, index=False)


def get_from_cache(product_id: str) -> Optional[ProductMatchResult]:
    if not CACHE_FILE_PATH.exists():
        return None

    df = pd.read_parquet(CACHE_FILE_PATH)
    match = df[df["product_id"] == product_id]

    if match.empty:
        return None

    return ProductMatchResult(**match.iloc[0]["cached_result"])

def load_file(file_path: str):
    return pd.read_csv(file_path)
        
def load_all_data():
    ob_products = load_file(config.OB_PRODUCTS_FILE)
    branded_products = load_file(config.BRANDED_PRODUCTS_FILE)
    return branded_products, ob_products

def is_valid_product_id(product_id: str, branded_products, ob_products) -> bool:
    try:
        product_id_int = int(product_id)
    except (TypeError, ValueError):
        return False

    df_match = branded_products[branded_products["product_id"] == product_id_int]
    if not df_match.empty:
        return True

    df_match_ob = ob_products[ob_products["product_id"] == product_id_int]
    if not df_match_ob.empty:
        return True

    return False

def inject_canonical_ids(products: List[ProductInput]):
    """
    Generates one canonical ID per product.
    Tracks:
    - original product_id
    - frontend product_description
    """
    updated_products = []
    key_map = {}     # canonical_id -> original_product_id
    desc_map = {}    # canonical_id -> frontend product_description

    for p in products:
        if p.product_id and p.product_id.strip():
            canonical_id = p.product_id.strip()
        else:
            canonical_id = f"agg_dummy_{uuid.uuid4().hex}"

        key_map[canonical_id] = p.product_id
        desc_map[canonical_id] = p.product_description

        prod_dict = p.dict()
        prod_dict["product_id"] = canonical_id

        updated_products.append(prod_dict)

    return updated_products, key_map, desc_map

async def call_pipeline(url: str, payload: dict):
    async with httpx.AsyncClient(timeout=300) as client:
        resp = await client.post(url, json=payload)
        resp.raise_for_status()
        return resp.json()

def non_progressive_merge(resp1: dict, resp2: dict, resp3: dict) -> dict:
    r = check(resp1['data']['products'], resp2['data']['products'], resp3['data']['products'])
    return r

def progressive_merge(resp1: dict, resp2: dict, resp3: dict) -> dict:
    d = final_pipeline(resp1['data']['products'], resp2['data']['products'], resp3['data']['products'])
    return d

def convert_to_matched_products(raw_results: list[dict]) -> List[MatchedProduct]:
    matched_products = []

    # sorted_results = sorted(raw_results, key=lambda x: x.get("llm_exact_match_score", 0.0), reverse=True)

    for item in raw_results:
        score = (
            item.get("llm_exact_match_score")
            or item.get("rerank_score")
            or item.get("normalized_score")
            or item.get("semantic_score")
            or item.get("original_score")
            or 0.0
        )

        matched_products.append(
            MatchedProduct(
                product_id=str(item.get("product_id", "")),
                product_description=item.get("description", ""),
                web_display_name=item.get("web_display_name", ""),
                global_product_hierarchy_id=(
                    str(int(item["hierarchy"]))
                    if item.get("hierarchy") not in (None,"")
                    else None
                ),
                supplier_name=item.get("supplier_name"),
                mpn=item.get("mpn"),
                cost=str(item["cost"]) if item.get("cost") is not None else None,
                match_perc=round(float(score) * 100, 2),
                match_reasoning=str(item.get("structured_reason",item.get("llm_exact_match_reason_for_score", ""))),
            )
        )

    return matched_products[:20]

# =========================
# FastAPI App
# =========================

app = FastAPI(title="Product Match Aggregator API", version="1.0.0")


@app.exception_handler(ValueError)
async def handle_value_error(request: Request, exc: ValueError):
    return JSONResponse(
        status_code=400,
        content=ErrorResponse(message=str(exc)).dict(),
    )


@app.post(
    "/api/v1/product-match",
    response_model=SuccessResponse,
)
async def aggregated_product_match(req: ProductMatchRequest):
    branded_products, ob_products = load_all_data()
    try:
        pipeline_products = []
        skipped_products = []
        cached_products = []

        for p in req.products:
            has_product_id = bool(p.product_id and p.product_id.strip())
            has_description = bool(p.product_description and p.product_description.strip())

            if not has_product_id:
                # No product_id → always pipeline
                pipeline_products.append(p)
                continue

            # product_id exists → validate
            is_valid = is_valid_product_id(
                p.product_id,
                branded_products,
                ob_products,
            )

            if is_valid:
                if CACHE_STATUS:
                    cached = get_from_cache(p.product_id)
                    if cached:
                        cached_products.append(cached)
                    else:
                        pipeline_products.append(p)
                else:
                    pipeline_products.append(p)
            else:
                if has_description:
                    # Invalid ID but description exists → allow pipeline
                    pipeline_products.append(p)
                else:
                    # Invalid ID AND no description → skip pipeline
                    skipped_products.append(
                        ProductMatchResult(
                            product_id=p.product_id,
                            product_description=p.product_description,
                            match_products=[],
                        )
                    )

        final_products = []

        if pipeline_products:
            products_with_ids, key_map, desc_map = inject_canonical_ids(pipeline_products)
            payload = {"products": products_with_ids}

            tt = time.time()
            res1, res2, res3 = await asyncio.gather(
                call_pipeline(PIPELINE_1_URL, payload),
                call_pipeline(PIPELINE_2_URL, payload),
                call_pipeline(PIPELINE_3_URL, payload),
            )

            merged = progressive_merge(res1, res2, res3)

            if USE_PROMT_RESTRUCTURING:
                open_ai_processor = reason_final.OpenAIProcessor(OPENAI_API_KEY)
                merged = reason_final.process_batch_threaded(merged, open_ai_processor)

            for prod in merged:
                canonical_id = prod["branded_product_id"]
                frontend_desc = desc_map.get(canonical_id)
                pipeline_desc = prod.get("branded_query_text")

                final_description = (
                    pipeline_desc
                    if frontend_desc in (None, "")
                    else frontend_desc
                )
                
                original_product_id = key_map.get(canonical_id)
                
                result_obj = ProductMatchResult(
                    product_id=original_product_id,
                    product_description=final_description,
                    match_products=convert_to_matched_products(
                        prod.get("reranked_matches", [])
                    ),
                )

                final_products.append(result_obj)
                if CACHE_STATUS and original_product_id:
                    save_to_cache(original_product_id, result_obj)

            aa = time.time()
            print("TIME TAKEN", aa - tt)

        final_products.extend(cached_products)
        final_products.extend(skipped_products)

        return SuccessResponse(
            data=ProductMatchResponseData(products=final_products)
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
# async def aggregated_product_match(req: ProductMatchRequest):
#     try:
#         products_with_ids, key_map, desc_map = inject_canonical_ids(req.products)
#         payload = {"products": products_with_ids}
#         tt = time.time()
#         res1, res2, res3 = await asyncio.gather(
#             call_pipeline(PIPELINE_1_URL, payload),
#             call_pipeline(PIPELINE_2_URL, payload),
#             call_pipeline(PIPELINE_3_URL, payload),
#         )
#         print(res1)
#         merged = progressive_merge(res1, res2, res3)
        
#         if USE_PROMT_RESTRUCTURING:
#             open_ai_processor = reason_final.OpenAIProcessor(OPENAI_API_KEY)
#             merged = reason_final.process_batch_threaded(merged, open_ai_processor)
    
#         final_products = []

#         for prod in merged:
#             canonical_id = prod["branded_product_id"]
#             frontend_desc = desc_map.get(canonical_id)
#             pipeline_desc = prod.get("branded_query_text")

#             final_description = (
#                 pipeline_desc
#                 if frontend_desc is None
#                 else frontend_desc
#             )

#             final_products.append(
#                 ProductMatchResult(
#                     product_id=key_map.get(canonical_id),
#                     product_description=final_description,
#                     match_products=convert_to_matched_products(
#                         prod.get("reranked_matches", [])
#                     )
#                 )
#             )
#         aa = time.time()
#         print("TIME TAKEN", aa-tt)
#         return SuccessResponse(
#             data=ProductMatchResponseData(products=final_products)
#         )

#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))


@app.post(
    "/api/v1/product-match-non-progressive",
    response_model=SuccessResponse,
)
async def aggregated_product_match(req: ProductMatchRequest):
    try:
        products_with_ids, key_map, desc_map = inject_canonical_ids(req.products)
        payload = {"products": products_with_ids}
        tt = time.time()
        res1, res2, res3 = await asyncio.gather(
            call_pipeline(PIPELINE_1_URL, payload),
            call_pipeline(PIPELINE_2_URL, payload),
            call_pipeline(PIPELINE_3_URL, payload),
        )
        print(res1)
        merged = non_progressive_merge(res1, res2, res3)
        final_products = []

        for canonical_id, raw_matches in merged.items():
            frontend_desc = desc_map.get(canonical_id)

            final_description = frontend_desc  # pipeline desc not present here

            final_products.append(
                ProductMatchResult(
                    product_id=key_map.get(canonical_id),
                    product_description=final_description,
                    match_products=convert_to_matched_products(raw_matches),
                )
            )
        aa = time.time()
        print("TIME TAKEN", aa-tt)
        return SuccessResponse(
            data=ProductMatchResponseData(products=final_products)
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
# @app.post(
#     "/api/v1/product-match-test-endpoint"
# )
# async def aggregated_product_match(req: ProductMatchRequest):
#     products_with_ids, key_map, desc_map = inject_canonical_ids(req.products)
#     payload = {"products": products_with_ids}
#     tt = time.time()
#     res1, res2, res3 = await asyncio.gather(
#         call_pipeline(PIPELINE_1_URL, payload),
#         call_pipeline(PIPELINE_2_URL, payload),
#         call_pipeline(PIPELINE_3_URL, payload),
#     )
#     merged = progressive_merge(res1, res2, res3)
#     open_ai_processor = reason_final.OpenAIProcessor(OPENAI_API_KEY)
#     data_restructured = reason_final.process_batch_threaded(merged, open_ai_processor)
#     return data_restructured