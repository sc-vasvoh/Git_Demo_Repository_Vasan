"""Common utilities and configuration"""
