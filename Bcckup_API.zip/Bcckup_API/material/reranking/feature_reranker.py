"""
Feature-based Reranker for Product Matching
Uses engineered features to enhance reranking without XGBoost
"""

import logging
import numpy as np
import pandas as pd
from typing import List, Dict, Optional
from reranking.feature_engineering import FeatureEngineer

logger = logging.getLogger(__name__)


class FeatureBasedReranker:
    """
    Reranker that uses engineered features with weighted scoring
    No ML training required - uses rule-based feature weighting
    """
    
    def __init__(self, feature_engineer=None):
        """
        Initialize feature-based reranker
        
        Args:
            feature_engineer: FeatureEngineer instance (will create if None)
        """
        if feature_engineer is None:
            self.feature_engineer = FeatureEngineer()
        else:
            self.feature_engineer = feature_engineer
        
        # Feature weights (can be tuned based on your domain)
        self.feature_weights = {
            # Semantic baseline (from embeddings)
            'embedding_cosine_similarity': 0.30,  # 30% weight
            
            # Technical features (CRITICAL for products)
            'numbers_jaccard_similarity': 0.25,   # 25% - number matching is crucial
            'all_numbers_match': 0.10,            # 10% - bonus for exact match
            'unit_match_boolean': 0.10,           # 10% - prevent unit confusion
            
            # Fuzzy text features
            'fuzz_token_sort_ratio': 0.15,        # 15% - handles word order
            'fuzz_token_set_ratio': 0.05,         # 5% - handles subsets
            
            # Token features
            'token_jaccard_similarity': 0.05      # 5% - word overlap
        }
    
    def compute_combined_score(self, features: Dict[str, float]) -> float:
        """
        Compute weighted combination of features
        
        Args:
            features: Dictionary of feature values
            
        Returns:
            Combined score (0-1)
        """
        score = 0.0
        
        for feature_name, weight in self.feature_weights.items():
            if feature_name in features:
                score += weight * features[feature_name]
        
        return score
    
    def rerank(
        self, 
        query_text: str, 
        results: List[Dict], 
        top_n: int = None
    ) -> List[Dict]:
        """
        Rerank results using feature-based scoring
        
        Args:
            query_text: Query text (branded product description)
            results: Initial search results
            top_n: Number of top results to return
            
        Returns:
            Reranked results
        """
        if len(results) == 0:
            return results
        
        logger.debug(f"Reranking {len(results)} results using feature-based scoring...")
        
        # Compute features and scores for all results
        for result in results:
            # Extract features
            features = self.feature_engineer.compute_all_features(
                branded_text=query_text,
                ob_text=result.get('text', ''),
                vector_score=result.get('score', 0.0),
                hierarchy_level1=result.get('metadata', {}).get('hierarchy_level1')
            )
            
            # Store features in result (for debugging/analysis)
            result['features'] = features
            
            # Compute combined score
            combined_score = self.compute_combined_score(features)
            
            # Store scores
            result['feature_score'] = float(combined_score)
            result['original_score'] = result.get('score', 0.0)
        
        # Sort by feature score
        results.sort(key=lambda x: x['feature_score'], reverse=True)
        
        # Update ranks
        for idx, result in enumerate(results):
            result['rank'] = idx + 1
        
        if top_n:
            return results[:top_n]
        
        return results
    
    def set_feature_weights(self, weights: Dict[str, float]):
        """
        Update feature weights
        
        Args:
            weights: Dictionary of feature weights (should sum to ~1.0)
        """
        self.feature_weights.update(weights)
        logger.info(f"Updated feature weights: {self.feature_weights}")
    
    def get_feature_weights(self) -> Dict[str, float]:
        """Get current feature weights"""
        return self.feature_weights.copy()


if __name__ == "__main__":
    # Test feature-based reranking
    logging.basicConfig(level=logging.INFO)
    
    from feature_engineering import FeatureEngineer
    
    engineer = FeatureEngineer()
    reranker = FeatureBasedReranker(feature_engineer=engineer)
    
    # Test case: "2 inch" should rank higher than "3 inch"
    query = "2 inch PVC ball valve"
    results = [
        {
            'text': '3 inch PVC ball valve',
            'score': 0.98,  # High embedding score!
            'product_id': '001',
            'metadata': {'hierarchy_level1': 'Plumbing'}
        },
        {
            'text': 'Ball valve PVC 2 in',
            'score': 0.95,  # Lower embedding score
            'product_id': '002',
            'metadata': {'hierarchy_level1': 'Plumbing'}
        },
        {
            'text': '2 inch gate valve PVC',
            'score': 0.90,
            'product_id': '003',
            'metadata': {'hierarchy_level1': 'Plumbing'}
        }
    ]
    
    print(f"\n{'='*60}")
    print(f"Query: {query}")
    print(f"{'='*60}")
    
    print("\n📊 BEFORE Reranking (by embedding score):")
    for r in results:
        print(f"  {r['product_id']}: {r['text']}")
        print(f"      Embedding Score: {r['score']:.3f}")
    
    # Rerank
    reranked = reranker.rerank(query, results, top_n=3)
    
    print("\n✨ AFTER Feature-Based Reranking:")
    for r in reranked:
        print(f"\n  Rank {r['rank']}: {r['text']} (ID: {r['product_id']})")
        print(f"      Original Score: {r['original_score']:.3f}")
        print(f"      Feature Score:  {r['feature_score']:.3f}")
        
        # Show key features
        features = r['features']
        print(f"      Key Features:")
        print(f"        - Embedding: {features['embedding_cosine_similarity']:.3f}")
        print(f"        - Numbers Match: {features['numbers_jaccard_similarity']:.3f}")
        print(f"        - All Numbers Match: {features['all_numbers_match']:.1f}")
        print(f"        - Fuzzy Token Sort: {features['fuzz_token_sort_ratio']:.3f}")
    
    print("\n" + "="*60)
    print("✅ Correct match (2 inch) should now rank #1!")
    print("="*60)
