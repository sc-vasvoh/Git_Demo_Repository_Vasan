"""
Helper utilities for Ferguson Product Matching Pipeline
"""

import os
import json
import pandas as pd
from typing import Dict, List
import config
from data_loader import load_data_file


def print_evaluation_summary(results_file: str = None):
    """Print a formatted summary of evaluation results"""
    if results_file is None:
        results_file = os.path.join(config.OUTPUT_DIR, config.RESULTS_FILENAME)
    
    if not os.path.exists(results_file):
        print(f"Results file not found: {results_file}")
        return
    
    with open(results_file, 'r') as f:
        metrics = json.load(f)
    
    print("\n" + "="*60)
    print("EVALUATION RESULTS SUMMARY")
    print("="*60)
    
    print(f"\nDataset:")
    print(f"  Total Queries: {metrics['total_queries']}")
    print(f"  Queries with Ground Truth: {metrics['queries_with_ground_truth']}")
    
    print(f"\nTop-K Accuracy:")
    for k, acc in sorted(metrics['top_k_accuracy'].items()):
        print(f"  Top-{k:2d}: {float(acc)*100:5.2f}%")
    
    print(f"\nRanking Metrics:")
    print(f"  Mean Rank: {metrics['mean_rank']:.2f}")
    print(f"  MRR (Mean Reciprocal Rank): {metrics['mrr']:.4f}")
    print(f"  Coverage: {metrics['coverage']*100:.2f}%")
    
    if 'rank_distribution' in metrics:
        dist = metrics['rank_distribution']
        print(f"\nRank Distribution:")
        print(f"  Min Rank: {dist.get('min_rank', 'N/A')}")
        print(f"  25th Percentile: {dist.get('percentile_25', 'N/A')}")
        print(f"  Median: {dist.get('median_rank', 'N/A')}")
        print(f"  75th Percentile: {dist.get('percentile_75', 'N/A')}")
        print(f"  Max Rank: {dist.get('max_rank', 'N/A')}")
        print(f"  Not Found: {dist.get('not_found', 'N/A')}")
    
    print("="*60 + "\n")


def analyze_top_matches(matches_file: str = None):
    """Analyze and print statistics from top matches"""
    if matches_file is None:
        matches_file = os.path.join(
            config.OUTPUT_DIR, config.TOP_MATCHES_CSV_FILENAME
        )
    
    if not os.path.exists(matches_file):
        print(f"Matches file not found: {matches_file}")
        return
    
    # Load data file (supports CSV and XLSX)
    df = load_data_file(matches_file)
    
    print("\n" + "="*60)
    print("TOP MATCHES ANALYSIS")
    print("="*60)
    
    total = len(df)
    correct = df['is_correct'].sum()
    incorrect = total - correct
    
    print(f"\nOverall:")
    print(f"  Total Queries: {total}")
    print(f"  Correct Top-1 Matches: {correct} ({correct/total*100:.2f}%)")
    print(f"  Incorrect Top-1 Matches: {incorrect} ({incorrect/total*100:.2f}%)")
    
    # Analyze correct matches
    correct_df = df[df['is_correct'] == True]
    if len(correct_df) > 0:
        print(f"\nCorrect Matches:")
        print(f"  Average Score: {correct_df['top_match_score'].mean():.4f}")
        if 'top_match_rerank_score' in correct_df.columns:
            print(f"  Average Rerank Score: {correct_df['top_match_rerank_score'].mean():.4f}")
    
    # Analyze incorrect matches
    incorrect_df = df[df['is_correct'] == False]
    if len(incorrect_df) > 0:
        print(f"\nIncorrect Matches:")
        print(f"  Average Score: {incorrect_df['top_match_score'].mean():.4f}")
        if 'top_match_rerank_score' in incorrect_df.columns:
            print(f"  Average Rerank Score: {incorrect_df['top_match_rerank_score'].mean():.4f}")
        
        # Show where correct matches were found
        found_later = incorrect_df[incorrect_df['correct_rank'] != 'Not Found']
        if len(found_later) > 0:
            print(f"  Correct match found in results: {len(found_later)} ({len(found_later)/len(incorrect_df)*100:.1f}%)")
            print(f"  Average rank of correct match: {pd.to_numeric(found_later['correct_rank'], errors='coerce').mean():.1f}")
        
        not_found = incorrect_df[incorrect_df['correct_rank'] == 'Not Found']
        if len(not_found) > 0:
            max_k = max(config.EVAL_TOP_K_VALUES)
            print(f"  Correct match not in top-{max_k}: "
                  f"{len(not_found)} "
                  f"({len(not_found)/len(incorrect_df)*100:.1f}%)")
    
    print("="*60 + "\n")
    
    # Show some example incorrect matches
    if len(incorrect_df) > 0:
        print("Sample Incorrect Matches (first 5):")
        print("-" * 60)
        for idx, row in incorrect_df.head(5).iterrows():
            print(f"\nBranded Product ID: {row['branded_product_id']}")
            print(f"  Expected: {row['correct_ob_product_id']}")
            print(f"  Got: {row['top_match_ob_product_id']}")
            print(f"  Correct Rank: {row['correct_rank']}")
            print(f"  Top Match: {row['top_match_text'][:100]}...")


def compare_configurations(results_files: Dict[str, str]):
    """Compare results from different configurations"""
    print("\n" + "="*60)
    print("CONFIGURATION COMPARISON")
    print("="*60)
    
    all_results = {}
    for name, file_path in results_files.items():
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                all_results[name] = json.load(f)
    
    if not all_results:
        print("No results files found")
        return
    
    # Print comparison table
    print(f"\n{'Configuration':<20} Top-1   Top-5   Top-10  Top-20   MRR    Mean Rank")
    print("-" * 80)
    
    for name, metrics in all_results.items():
        top_k = metrics['top_k_accuracy']
        print(f"{name:<20} {top_k.get('1', 0)*100:5.1f}% {top_k.get('5', 0)*100:5.1f}% "
              f"{top_k.get('10', 0)*100:5.1f}% {top_k.get('20', 0)*100:5.1f}% "
              f"{metrics['mrr']:6.3f}  {metrics['mean_rank']:6.2f}")
    
    print("="*60 + "\n")


def check_data_files():
    """Check if all required data files exist"""
    print("\n" + "="*60)
    print("DATA FILES CHECK")
    print("="*60 + "\n")
    
    required_files = {
        'OB Products': 'data/ob_product_attributes.csv',
        'Branded Products': 'data/branded_product_attributes.csv',
        'Product Hierarchy': 'data/global_prod_hierarchy.csv',
        'Verified Crosses': 'data/verified_crosses.csv'
    }
    
    all_present = True
    for name, path in required_files.items():
        exists = os.path.exists(path)
        status = "✓" if exists else "✗"
        print(f"{status} {name:<20} {path}")
        if not exists:
            all_present = False
    
    print()
    if all_present:
        print("✓ All data files present")
    else:
        print("✗ Some data files are missing")
    
    print("="*60 + "\n")
    return all_present


def check_index_exists():
    """Check if index has been built"""
    index_dir = "storage/index"
    faiss_index = os.path.join(index_dir, "faiss_index.bin")
    
    exists = os.path.exists(faiss_index)
    
    print("\n" + "="*60)
    print("INDEX CHECK")
    print("="*60 + "\n")
    
    if exists:
        print("✓ Index exists at:", index_dir)
        
        # Check all index files
        files = {
            'FAISS Index': 'faiss_index.bin',
            'BM25 Index': 'bm25_index.pkl',
            'Documents': 'documents.pkl'
        }
        
        print("\nIndex files:")
        for name, filename in files.items():
            path = os.path.join(index_dir, filename)
            if os.path.exists(path):
                size_mb = os.path.getsize(path) / (1024 * 1024)
                print(f"  ✓ {name:<15} {filename:<20} ({size_mb:.1f} MB)")
            else:
                print(f"  ✗ {name:<15} {filename:<20} (missing)")
    else:
        print("✗ Index not found. Run: python main.py --mode build")
    
    print("="*60 + "\n")
    return exists


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == "summary":
            print_evaluation_summary()
        
        elif command == "analyze":
            analyze_top_matches()
        
        elif command == "check":
            check_data_files()
            check_index_exists()
        
        elif command == "all":
            check_data_files()
            check_index_exists()
            print_evaluation_summary()
            analyze_top_matches()
        
        else:
            print(f"Unknown command: {command}")
            print("\nUsage:")
            print("  python utils.py summary   # Print evaluation summary")
            print("  python utils.py analyze   # Analyze top matches")
            print("  python utils.py check     # Check data and index files")
            print("  python utils.py all       # Run all checks and summaries")
    else:
        print("Ferguson Product Matching - Utility Functions")
        print("\nUsage:")
        print("  python utils.py summary   # Print evaluation summary")
        print("  python utils.py analyze   # Analyze top matches")
        print("  python utils.py check     # Check data and index files")
        print("  python utils.py all       # Run all checks and summaries")
        print("\nOr import in Python:")
        print("  from utils import print_evaluation_summary, analyze_top_matches")
