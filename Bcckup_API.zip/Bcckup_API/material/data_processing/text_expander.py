"""
LLM-based text expansion module for Ferguson Product Matching Pipeline
"""

import logging
import json
import os
from openai import OpenAI
from common import config

logger = logging.getLogger(__name__)

# Global cache for expansion results
DOCUMENT_EXPANSION_CACHE = {}
QUERY_EXPANSION_CACHE = {}

# Global OpenAI client
OPENAI_CLIENT = None

# Persistent storage for expansions
DOCUMENT_EXPANSIONS_FILE_PATH = None
DOCUMENT_EXPANSIONS_LIST = []
QUERY_EXPANSIONS_FILE_PATH = None
QUERY_EXPANSIONS_LIST = []


def initialize_expansion_cache():
    """Initialize the expansions file path and load existing data"""
    global DOCUMENT_EXPANSIONS_FILE_PATH, DOCUMENT_EXPANSIONS_LIST, QUERY_EXPANSIONS_FILE_PATH, QUERY_EXPANSIONS_LIST
    
    if DOCUMENT_EXPANSIONS_FILE_PATH is None:
        # Get file paths from config
        DOCUMENT_EXPANSIONS_FILE_PATH = config.LLM_EXPANSIONS_FILE
        QUERY_EXPANSIONS_FILE_PATH = config.LLM_QUERY_EXPANSIONS_FILE
        
        # Create directories if needed
        for file_path in [DOCUMENT_EXPANSIONS_FILE_PATH, QUERY_EXPANSIONS_FILE_PATH]:
            expansions_dir = os.path.dirname(file_path)
            if expansions_dir:
                os.makedirs(expansions_dir, exist_ok=True)
        
        # Load existing document expansions if file exists
        if os.path.exists(DOCUMENT_EXPANSIONS_FILE_PATH):
            try:
                with open(DOCUMENT_EXPANSIONS_FILE_PATH, 'r', encoding='utf-8') as f:
                    DOCUMENT_EXPANSIONS_LIST = json.load(f)
                logger.info(f"Loaded {len(DOCUMENT_EXPANSIONS_LIST)} existing document expansions from {DOCUMENT_EXPANSIONS_FILE_PATH}")
                
                # Build cache from loaded data using product_id as key
                for item in DOCUMENT_EXPANSIONS_LIST:
                    DOCUMENT_EXPANSION_CACHE[item['product_id']] = item['expanded_description']
                
                logger.info(f"Document cache uses product_id as key for {len(DOCUMENT_EXPANSION_CACHE)} entries")
                
                # Log mode
                if config.USE_EXISTING_DOCUMENT_EXPANSIONS:
                    logger.info("MODE: Cache ENABLED for documents - will use cached expansions and call LLM for missing items")
                else:
                    logger.info("MODE: Cache DISABLED for documents - will always call LLM and skip cache")
            except Exception as e:
                logger.warning(f"Failed to load document expansions file: {e}")
                DOCUMENT_EXPANSIONS_LIST = []
        else:
            DOCUMENT_EXPANSIONS_LIST = []
            if config.USE_EXISTING_DOCUMENT_EXPANSIONS:
                logger.info(f"Document cache file not found: {DOCUMENT_EXPANSIONS_FILE_PATH} - will create on first save")
            else:
                logger.info(f"Document cache DISABLED - expansions will not be saved")
        

        # Load existing query expansions if file exists
        if os.path.exists(QUERY_EXPANSIONS_FILE_PATH):
            try:
                with open(QUERY_EXPANSIONS_FILE_PATH, 'r', encoding='utf-8') as f:
                    QUERY_EXPANSIONS_LIST = json.load(f)
                logger.info(f"Loaded {len(QUERY_EXPANSIONS_LIST)} existing query expansions from {QUERY_EXPANSIONS_FILE_PATH}")
                
                # Build cache from loaded data using product_id as key
                for item in QUERY_EXPANSIONS_LIST:
                    QUERY_EXPANSION_CACHE[item['product_id']] = item['expanded_description']
                
                logger.info(f"Query cache uses product_id as key for {len(QUERY_EXPANSION_CACHE)} entries")
                
                # Log mode
                if config.USE_EXISTING_QUERY_EXPANSIONS:
                    logger.info("MODE: Cache ENABLED for queries - will use cached expansions and call LLM for missing items")
                else:
                    logger.info("MODE: Cache DISABLED for queries - will always call LLM and skip cache")
            except Exception as e:
                logger.warning(f"Failed to load query expansions file: {e}")
                QUERY_EXPANSIONS_LIST = []
        else:
            QUERY_EXPANSIONS_LIST = []
            if config.USE_EXISTING_QUERY_EXPANSIONS:
                logger.info(f"Query cache file not found: {QUERY_EXPANSIONS_FILE_PATH} - will create on first save")
            else:
                logger.info(f"Query cache DISABLED - expansions will not be saved")


def save_expansion(product_id: str, description: str, expanded_description: str, is_query: bool = False):
    """Save a single expansion to the persistent storage"""
    global DOCUMENT_EXPANSIONS_LIST, QUERY_EXPANSIONS_LIST
    
    # Add to in-memory list
    expansion_entry = {
        'product_id': product_id,
        'description': description,
        'expanded_description': expanded_description
    }
    
    # Determine which file to save to
    if is_query:
        QUERY_EXPANSIONS_LIST.append(expansion_entry)
        file_path = QUERY_EXPANSIONS_FILE_PATH
        data_to_save = QUERY_EXPANSIONS_LIST
    else:
        DOCUMENT_EXPANSIONS_LIST.append(expansion_entry)
        file_path = DOCUMENT_EXPANSIONS_FILE_PATH
        data_to_save = DOCUMENT_EXPANSIONS_LIST
    
    # Save to file
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data_to_save, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.warning(f"Failed to save expansion to file: {e}")


def get_openai_client():
    """Get or initialize OpenAI client"""
    global OPENAI_CLIENT
    if OPENAI_CLIENT is None and config.USE_LLM_EXPANSION:
        try:
            OPENAI_CLIENT = OpenAI(api_key=config.OPENAI_API_KEY)
            logger.info(f"Initialized OpenAI client with model: {config.LLM_MODEL}")
            # Initialize expansions file
            initialize_expansion_cache()
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI client: {e}")
            OPENAI_CLIENT = None
    return OPENAI_CLIENT


def call_llm_for_expansion(text: str, is_query: bool = False) -> str:
    """
    Internal function to call LLM for text expansion
    
    Args:
        text: Text to expand
        is_query: Whether this is a query expansion
        
    Returns:
        Expanded text or original text if expansion fails
    """
    client = get_openai_client()
    if not client or not text or not text.strip():
        return text
    
    prompt = config.LLM_EXPANSION_PROMPT.format(text=text)
    
    try:
        response = client.chat.completions.create(
            model=config.LLM_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": "You expand product descriptions precisely."
                },
                {"role": "user", "content": prompt}
            ],
            temperature=config.LLM_TEMPERATURE,
            max_tokens=config.LLM_MAX_TOKENS
        )
        
        expanded = response.choices[0].message.content.strip()
        
        # Remove quotes if present
        if expanded.startswith('"') and expanded.endswith('"'):
            expanded = expanded[1:-1]
        if expanded.startswith("'") and expanded.endswith("'"):
            expanded = expanded[1:-1]
        
        # Log the expansion
        logger.info(f"{'QUERY' if is_query else 'DOCUMENT'} ORIGINAL: {text}")
        logger.info(f"{'QUERY' if is_query else 'DOCUMENT'} EXPANDED: {expanded}")
        
        return expanded
        
    except Exception as e:
        logger.warning(f"Failed to expand text: {e}")
        return text


def expand_text(text: str, product_id: str = None, is_query: bool = False) -> str:
    """
    Expand terse product descriptions using OpenAI or from existing expansions
    
    Args:
        text: Product description to expand
        product_id: Product ID for cache lookup and saving to persistent storage
        is_query: If True, this is a query expansion. If False, this is a document expansion.
        
    Returns:
        Expanded description or original if expansion fails
    """
    if not text or not text.strip():
        return text
    
    # Check if we should use cache
    use_cache = config.USE_EXISTING_QUERY_EXPANSIONS if is_query else config.USE_EXISTING_DOCUMENT_EXPANSIONS
    
    if use_cache and product_id:
        # Use cache: check cache first using product_id, call LLM only if missing
        cache = QUERY_EXPANSION_CACHE if is_query else DOCUMENT_EXPANSION_CACHE
        
        # Check cache first (loaded from file) using product_id as key
        if product_id in cache:
            return cache[product_id]
    
    # Call LLM for expansion (either cache miss or cache disabled)
    expanded = call_llm_for_expansion(text, is_query)
    
    # Cache result if caching is enabled and product_id is provided
    if use_cache and product_id:
        cache = QUERY_EXPANSION_CACHE if is_query else DOCUMENT_EXPANSION_CACHE
        cache[product_id] = expanded
        
        # Save to persistent storage
        save_expansion(product_id, text, expanded, is_query=is_query)
    
    return expanded


def expand_batch(texts: list[tuple[str, str, bool]]) -> dict[str, str]:
    """
    Expand multiple texts in parallel using concurrent API calls
    
    Args:
        texts: List of tuples (text, product_id, is_query)
        
    Returns:
        Dictionary mapping product_id to expanded text
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    
    client = get_openai_client()
    if not client:
        logger.warning("OpenAI client not available for batch expansion")
        return {product_id: text for text, product_id, _ in texts}
    
    results = {}
    items_to_expand = []
    
    # Check cache first (only if caching is enabled)
    for text, product_id, is_query in texts:
        if not text or not text.strip():
            results[product_id] = text
            continue
        
        # Check if we should use cache
        use_cache = config.USE_EXISTING_QUERY_EXPANSIONS if is_query else config.USE_EXISTING_DOCUMENT_EXPANSIONS
        
        if use_cache and product_id:
            # Use cache: check cache first using product_id, add to expansion list only if missing
            cache = QUERY_EXPANSION_CACHE if is_query else DOCUMENT_EXPANSION_CACHE
            
            if product_id in cache:
                results[product_id] = cache[product_id]
            else:
                # Cache miss - needs expansion
                items_to_expand.append((text, product_id, is_query))
        else:
            # Cache disabled or no product_id - always expand
            items_to_expand.append((text, product_id, is_query))
    
    if not items_to_expand:
        return results
    
    logger.info(f"Batch expanding {len(items_to_expand)} texts with {config.LLM_EXPANSION_WORKERS} workers...")
    
    # Expand in parallel
    def expand_one_item(item):
        text, product_id, is_query = item
        expanded = call_llm_for_expansion(text, is_query)
        return (text, product_id, is_query, expanded)
    
    # Execute in parallel
    with ThreadPoolExecutor(max_workers=config.LLM_EXPANSION_WORKERS) as executor:
        futures = {executor.submit(expand_one_item, item): item for item in items_to_expand}
        
        completed = 0
        for future in as_completed(futures):
            text, product_id, is_query, expanded = future.result()
            
            # Store result
            results[product_id] = expanded
            
            # Cache result if caching is enabled and product_id is provided
            use_cache = config.USE_EXISTING_QUERY_EXPANSIONS if is_query else config.USE_EXISTING_DOCUMENT_EXPANSIONS
            if use_cache and product_id:
                cache = QUERY_EXPANSION_CACHE if is_query else DOCUMENT_EXPANSION_CACHE
                cache[product_id] = expanded
                
                # Save to persistent storage
                save_expansion(product_id, text, expanded, is_query=is_query)
            
            completed += 1
            if completed % 100 == 0:
                logger.info(f"Completed {completed}/{len(items_to_expand)} expansions...")
    
    logger.info(f"Batch expansion complete: {len(items_to_expand)} texts processed")
    return results
