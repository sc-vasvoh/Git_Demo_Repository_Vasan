"""
Feature Engineering Module for Product Matching
Generates rich features for XGBoost reranking model
"""

import re
import logging
from typing import Dict, List, Set
from rapidfuzz import fuzz

logger = logging.getLogger(__name__)


class FeatureEngineer:
    """Generates features for product pair matching"""
    
    # Common units in plumbing/HVAC industry
    UNITS_PATTERN = r'\b(in|inch|inches|ft|feet|mm|cm|m|gal|gallon|gallons|oz|lb|lbs|kg|v|volt|volts|w|watt|watts|amp|amps|psi|gpm|cfm|btu)\b'
    
    def __init__(self):
        """Initialize feature engineer"""
        self.unit_regex = re.compile(self.UNITS_PATTERN, re.IGNORECASE)
        self.number_regex = re.compile(r'[-+]?\d*\.?\d+')
    
    def extract_numbers(self, text: str) -> Set[str]:
        """
        Extract all numbers from text (integers and decimals)
        
        Args:
            text: Input text
            
        Returns:
            Set of number strings
        """
        if not text:
            return set()
        return set(self.number_regex.findall(str(text)))
    
    def extract_units(self, text: str) -> Set[str]:
        """
        Extract measurement units from text
        
        Args:
            text: Input text
            
        Returns:
            Set of unit strings (lowercase)
        """
        if not text:
            return set()
        units = self.unit_regex.findall(str(text).lower())
        return set(units)
    
    def get_tokens(self, text: str) -> Set[str]:
        """
        Get unique tokens (words) from text
        
        Args:
            text: Input text
            
        Returns:
            Set of lowercase tokens
        """
        if not text:
            return set()
        # Remove special characters, split on whitespace
        cleaned = re.sub(r'[^\w\s]', ' ', str(text).lower())
        return set(cleaned.split())
    
    def compute_fuzzy_features(self, text1: str, text2: str) -> Dict[str, float]:
        """
        Compute fuzzy string matching features
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Dictionary of fuzzy matching scores
        """
        text1 = str(text1) if text1 else ""
        text2 = str(text2) if text2 else ""
        
        return {
            'fuzz_token_sort_ratio': fuzz.token_sort_ratio(text1, text2) / 100.0,
            'fuzz_token_set_ratio': fuzz.token_set_ratio(text1, text2) / 100.0,
            'fuzz_partial_ratio': fuzz.partial_ratio(text1, text2) / 100.0,
            'fuzz_ratio': fuzz.ratio(text1, text2) / 100.0,
            'description_length_diff': abs(len(text1) - len(text2)),
            'description_length_ratio': min(len(text1), len(text2)) / max(len(text1), len(text2)) if max(len(text1), len(text2)) > 0 else 0.0
        }
    
    def compute_number_features(self, text1: str, text2: str) -> Dict[str, float]:
        """
        Compute number-based features (critical for technical products)
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Dictionary of number matching features
        """
        nums1 = self.extract_numbers(text1)
        nums2 = self.extract_numbers(text2)
        
        # Jaccard similarity for numbers
        intersection = len(nums1.intersection(nums2))
        union = len(nums1.union(nums2))
        jaccard = intersection / union if union > 0 else 0.0
        
        # Exact overlap count
        exact_overlap = intersection
        
        # Number count difference
        count_diff = abs(len(nums1) - len(nums2))
        
        # Check if any numbers match
        any_number_match = 1.0 if intersection > 0 else 0.0
        
        # Check if all numbers match (only if both have numbers)
        all_numbers_match = 1.0 if (len(nums1) > 0 and len(nums2) > 0 and nums1 == nums2) else 0.0
        
        return {
            'numbers_jaccard_similarity': jaccard,
            'exact_number_overlap': exact_overlap,
            'number_count_diff': count_diff,
            'any_number_match': any_number_match,
            'all_numbers_match': all_numbers_match,
            'total_numbers_text1': len(nums1),
            'total_numbers_text2': len(nums2)
        }
    
    def compute_unit_features(self, text1: str, text2: str) -> Dict[str, float]:
        """
        Compute unit-based features (e.g., inches, volts, gallons)
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Dictionary of unit matching features
        """
        units1 = self.extract_units(text1)
        units2 = self.extract_units(text2)
        
        # Check if they share at least one unit
        shared_units = len(units1.intersection(units2))
        unit_match = 1.0 if shared_units > 0 else 0.0
        
        # Jaccard similarity for units
        union = len(units1.union(units2))
        unit_jaccard = shared_units / union if union > 0 else 0.0
        
        return {
            'unit_match_boolean': unit_match,
            'unit_jaccard_similarity': unit_jaccard,
            'shared_unit_count': shared_units,
            'unit_count_diff': abs(len(units1) - len(units2))
        }
    
    def compute_token_features(self, text1: str, text2: str) -> Dict[str, float]:
        """
        Compute token-based features
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Dictionary of token overlap features
        """
        tokens1 = self.get_tokens(text1)
        tokens2 = self.get_tokens(text2)
        
        # Jaccard similarity
        intersection = len(tokens1.intersection(tokens2))
        union = len(tokens1.union(tokens2))
        jaccard = intersection / union if union > 0 else 0.0
        
        # First word match
        words1 = str(text1).strip().lower().split()
        words2 = str(text2).strip().lower().split()
        first_word_match = 1.0 if (len(words1) > 0 and len(words2) > 0 and words1[0] == words2[0]) else 0.0
        
        # Last word match
        last_word_match = 1.0 if (len(words1) > 0 and len(words2) > 0 and words1[-1] == words2[-1]) else 0.0
        
        # Token count difference
        token_count_diff = abs(len(tokens1) - len(tokens2))
        
        return {
            'token_jaccard_similarity': jaccard,
            'token_overlap_count': intersection,
            'first_word_match': first_word_match,
            'last_word_match': last_word_match,
            'token_count_diff': token_count_diff,
            'total_tokens_text1': len(tokens1),
            'total_tokens_text2': len(tokens2)
        }
    
    def compute_all_features(
        self, 
        branded_text: str, 
        ob_text: str, 
        vector_score: float,
        hierarchy_level1: str = None
    ) -> Dict[str, float]:
        """
        Compute all features for a (branded, OB) product pair
        
        Args:
            branded_text: Branded product description
            ob_text: OB product description
            vector_score: Semantic similarity score from embeddings
            hierarchy_level1: Level 1 hierarchy category (optional)
            
        Returns:
            Dictionary of all features
        """
        features = {}
        
        # 1. Semantic feature (from embedding search)
        features['embedding_cosine_similarity'] = vector_score
        
        # 2. Fuzzy string features
        fuzzy_features = self.compute_fuzzy_features(branded_text, ob_text)
        features.update(fuzzy_features)
        
        # 3. Number features (CRITICAL for technical products)
        number_features = self.compute_number_features(branded_text, ob_text)
        features.update(number_features)
        
        # 4. Unit features
        unit_features = self.compute_unit_features(branded_text, ob_text)
        features.update(unit_features)
        
        # 5. Token overlap features
        token_features = self.compute_token_features(branded_text, ob_text)
        features.update(token_features)
        
        # 6. Hierarchy context (if provided)
        if hierarchy_level1:
            features['hierarchy_level1'] = hierarchy_level1
        
        return features
    
    def compute_features_batch(
        self, 
        pairs: List[Dict]
    ) -> List[Dict[str, float]]:
        """
        Compute features for a batch of product pairs
        
        Args:
            pairs: List of dictionaries with 'branded_text', 'ob_text', 'vector_score', 
                   and optional 'hierarchy_level1'
            
        Returns:
            List of feature dictionaries
        """
        features_list = []
        
        for pair in pairs:
            features = self.compute_all_features(
                branded_text=pair['branded_text'],
                ob_text=pair['ob_text'],
                vector_score=pair.get('vector_score', 0.0),
                hierarchy_level1=pair.get('hierarchy_level1')
            )
            features_list.append(features)
        
        return features_list


if __name__ == "__main__":
    # Test feature engineering
    logging.basicConfig(level=logging.INFO)
    
    engineer = FeatureEngineer()
    
    # Test case 1: Good match with numbers
    branded1 = "2 inch PVC ball valve with lever handle"
    ob1 = "Ball valve, PVC, 2 in, lever"
    
    features1 = engineer.compute_all_features(branded1, ob1, vector_score=0.95)
    
    print("\n=== Test 1: Good Match ===")
    print(f"Branded: {branded1}")
    print(f"OB: {ob1}")
    print("\nTop Features:")
    print(f"  Embedding Score: {features1['embedding_cosine_similarity']:.3f}")
    print(f"  Token Sort Ratio: {features1['fuzz_token_sort_ratio']:.3f}")
    print(f"  Number Jaccard: {features1['numbers_jaccard_similarity']:.3f}")
    print(f"  Exact Number Overlap: {features1['exact_number_overlap']}")
    print(f"  Unit Match: {features1['unit_match_boolean']}")
    print(f"  Token Jaccard: {features1['token_jaccard_similarity']:.3f}")
    
    # Test case 2: Wrong size (should score low on numbers)
    branded2 = "2 inch PVC ball valve"
    ob2 = "3 inch PVC ball valve"
    
    features2 = engineer.compute_all_features(branded2, ob2, vector_score=0.98)
    
    print("\n=== Test 2: Wrong Size ===")
    print(f"Branded: {branded2}")
    print(f"OB: {ob2}")
    print("\nTop Features:")
    print(f"  Embedding Score: {features2['embedding_cosine_similarity']:.3f}")
    print(f"  Token Sort Ratio: {features2['fuzz_token_sort_ratio']:.3f}")
    print(f"  Number Jaccard: {features2['numbers_jaccard_similarity']:.3f}")
    print(f"  All Numbers Match: {features2['all_numbers_match']}")
    
    # Test case 3: Different units
    branded3 = "5 ft copper pipe"
    ob3 = "5 inch copper nipple"
    
    features3 = engineer.compute_all_features(branded3, ob3, vector_score=0.85)
    
    print("\n=== Test 3: Different Units ===")
    print(f"Branded: {branded3}")
    print(f"OB: {ob3}")
    print("\nTop Features:")
    print(f"  Embedding Score: {features3['embedding_cosine_similarity']:.3f}")
    print(f"  Number Jaccard: {features3['numbers_jaccard_similarity']:.3f}")
    print(f"  Unit Match: {features3['unit_match_boolean']}")
    print(f"  Unit Jaccard: {features3['unit_jaccard_similarity']:.3f}")
