"""
LLM-based Exact Match Reranker for Ferguson Product Matching Pipeline

This module provides an additional layer of reranking after the initial retrieval 
and reranking, using an LLM to score exact matches between query and candidate products.
"""

import logging
import json
from typing import List, Dict, Optional
import openai
from openai import OpenAI
from common import config

logger = logging.getLogger(__name__)


class LLMExactMatchReranker:
    """
    Uses LLM to score exact matches between query and candidate products.
    Provides matching scores between 0 and 1 based on semantic and exact value matching.
    """
    
    def __init__(self):
        """Initialize the LLM-based exact match reranker"""
        # Initialize OpenAI client with API key from config
        logger.info("Initializing LLM Exact Match Reranker...")
        logger.info(f"API Key configured: {bool(config.OPENAI_API_KEY)}")
        logger.info(f"API Key length: {len(config.OPENAI_API_KEY) if config.OPENAI_API_KEY else 0}")
        
        self.client = OpenAI(api_key=config.OPENAI_API_KEY)
        self.model = config.LLM_EXACT_MATCH_MODEL
        self.temperature = config.LLM_EXACT_MATCH_TEMPERATURE
        self.max_tokens = config.LLM_EXACT_MATCH_MAX_TOKENS
        
        logger.info(f"✓ LLM Exact Match Reranker initialized successfully")
        logger.info(f"  Model: {self.model}")
        logger.info(f"  Temperature: {self.temperature}")
        logger.info(f"  Max Tokens: {self.max_tokens}")
    
    def create_matching_prompt(
        self, 
        query_id: str,
        query_text: str, 
        candidates: List[Dict]
    ) -> str:
        """
        Create a prompt for the LLM to score matches using template from config
        
        Args:
            query_id: ID of the query product
            query_text: Text description of the query
            candidates: List of candidate results with id and text
        Returns:
            Formatted prompt string
        """
        # Build candidates list string
        candidates_list = ""
        for idx, candidate in enumerate(candidates, 1):
            candidate_id = candidate.get('product_id', candidate.get('id'))
            candidate_text = candidate.get('text', candidate.get('description',''))
            candidates_list += f"\n{idx}. ID: {candidate_id}\n   Description: {candidate_text}\n"
        
        # Use prompt template from config
        prompt = config.LLM_EXACT_MATCH_PROMPT_TEMPLATE.format(
            query_id=query_id,
            query_text=query_text,
            candidates_list=candidates_list,
            num_candidates=len(candidates)
        )

        return prompt
    
    def parse_llm_response(self, response_text: str) -> Dict:
        """
        Parse the LLM response to extract matching scores
        
        Args:
            response_text: Raw response from LLM
            
        Returns:
            Dictionary with product_id to score mapping
        """
        try:
            # Try to extract JSON from response (handles markdown code blocks)
            response_text = response_text.strip()
            
            # Remove markdown code blocks if present
            if response_text.startswith("```"):
                lines = response_text.split("\n")
                response_text = "\n".join([l for l in lines if not l.startswith("```")])
                response_text = response_text.strip()
            
            # Remove "json" prefix if present
            if response_text.startswith("json"):
                response_text = response_text[4:].strip()
            
            parsed = json.loads(response_text)
            
            # Convert to dict for easy lookup and detect duplicates
            score_dict = {}
            reason_dict = {}
            duplicate_count = 0
            total_entries = len(parsed.get('matches', []))
            
            for match in parsed.get('matches', []):
                product_id = str(match.get('product_id', match.get('id', '')))
                score = float(match.get('score', 0.0))
                reason_for_score = str(match.get('reason',''))

                # Check for duplicates
                if product_id in score_dict:
                    duplicate_count += 1
                    logger.debug(f"Duplicate product_id in LLM output: {product_id} (existing score: {score_dict[product_id]:.4f}, new score: {score:.4f})")
                    # Keep the higher score
                    if score > score_dict[product_id]:
                        logger.debug(f"  → Keeping higher score: {score:.4f}")
                        score_dict[product_id] = score
                        reason_dict[product_id] = reason_for_score
                    else:
                        logger.debug(f"  → Keeping existing higher score: {score_dict[product_id]:.4f}")
                else:
                    score_dict[product_id] = score
                    reason_dict[product_id] = reason_for_score
            
            # Log duplicate info at debug level (duplicates are handled, not a critical error)
            if duplicate_count > 0:
                logger.debug(f"ℹ️  LLM output contained {duplicate_count} duplicate entries (handled by keeping highest scores)")
                logger.debug(f"   Total LLM output entries: {total_entries}, Unique products after dedup: {len(score_dict)}")
            
            return score_dict, reason_dict
            
        except Exception as e:
            logger.error(f"Failed to parse LLM response: {e}")
            logger.debug(f"Response text: {response_text}")
            return {}
    
    def rerank(
        self,
        query_id: str,
        query_text: str,
        results: List[Dict],
        top_n: Optional[int] = None
    ) -> List[Dict]:
        """
        Rerank results using LLM-based exact matching scores
        
        Args:
            query_id: ID of the query product
            query_text: Query text description
            results: List of candidate results from previous reranking
            top_n: Number of top results to return (optional)
            
        Returns:
            Reranked list of results with llm_exact_match_score added
        """
        if not results:
            return results
        
        if top_n is None:
            top_n = len(results)
        
        try:
            # Log initial scores before LLM reranking
            logger.info(f"\n{'='*80}")
            logger.info(f"LLM EXACT MATCH RERANKING - Query ID: {query_id}")
            logger.info(f"Query: {query_text}")
            logger.info(f"{'='*80}")
            logger.info(f"\nINITIAL SCORES (before LLM reranking):")
            for idx, result in enumerate(results[:10], 1):  # Log top 10
                product_id = result.get('product_id', result.get('id', ''))
                text = result.get('text') or result.get('description', '')
                initial_score = result.get('score', 0.0)
                rerank_score = result.get('rerank_score', None)
                
                if rerank_score is not None:
                    logger.info(f"  Rank {idx}: ID={product_id}, Initial={initial_score:.4f}, Rerank={rerank_score:.4f}")
                else:
                    logger.info(f"  Rank {idx}: ID={product_id}, Score={initial_score:.4f}")
                logger.info(f"           Text: {text}...")
            
            # Create prompt
            prompt = self.create_matching_prompt(query_id, query_text, results)

            # logger.info(f"\nPROMPT SENT TO LLM:\n{prompt}")
            for handler in logger.handlers:
                try:
                    handler.flush()
                except Exception:
                    pass

            # Call LLM
            logger.info(f"\nCalling LLM ({self.model}) for exact match scoring of {len(results)} candidates...")
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=self.temperature,
                max_tokens=self.max_tokens
            )
            
            # Log token usage
            if hasattr(response, 'usage') and response.usage:
                input_tokens = response.usage.prompt_tokens
                output_tokens = response.usage.completion_tokens
                total_tokens = response.usage.total_tokens
                logger.info(f"\n📊 LLM TOKEN USAGE:")
                logger.info(f"  Input tokens:  {input_tokens:,}")
                logger.info(f"  Output tokens: {output_tokens:,}")
                logger.info(f"  Total tokens:  {total_tokens:,}")
            
            response_text = response.choices[0].message.content
            # logger.info(f"\nLLM RAW RESPONSE:")
            # logger.info(f"{response_text}")
            
            # Parse response
            score_dict, reason_dict = self.parse_llm_response(response_text)
            retry_score_dict = {}  # Track which scores came from retry
            
            if not score_dict:
                logger.warning("No scores extracted from LLM response, returning original results")
                return results[:top_n]
            
            # Validate expected count - compare unique input products vs LLM output
            # Count unique product IDs in the input
            input_unique_products = set(str(r.get('product_id', r.get('id', ''))) for r in results)
            expected_count = len(input_unique_products)
            actual_count = len(score_dict)
            
            logger.info(f"\n{'='*80}")
            logger.info(f"LLM OUTPUT VALIDATION:")
            logger.info(f"  Input (unique products sent to LLM):     {expected_count}")
            logger.info(f"  Output (unique products from LLM):       {actual_count}")
            
            if actual_count != expected_count:
                logger.error(f"⚠️  COUNT MISMATCH DETECTED!")
                logger.error(f"{'='*80}")
                if actual_count < expected_count:
                    missing = input_unique_products - set(score_dict.keys())
                    logger.error(f"❌ LLM FAILED TO SCORE {len(missing)} PRODUCTS:")
                    logger.error(f"   Missing product IDs: {sorted(list(missing))[:10]}{'...' if len(missing) > 10 else ''}")
                    logger.error(f"   This means the LLM did not return scores for all input products!")
                    
                    # RETRY MISSING PRODUCTS
                    logger.info(f"\n🔄 RETRYING MISSING PRODUCTS...")
                    missing_results = [r for r in results if str(r.get('product_id', r.get('id', ''))) in missing]
                    if missing_results:
                        logger.info(f"   Retrying {len(missing_results)} missing products...")
                        retry_prompt = self.create_matching_prompt(query_id, query_text, missing_results)
                        
                        try:
                            retry_response = self.client.chat.completions.create(
                                model=self.model,
                                messages=[
                                    {"role": "system", "content": "You are a precise product matching expert. Always respond with valid JSON only."},
                                    {"role": "user", "content": retry_prompt}
                                ],
                                temperature=self.temperature,
                                max_tokens=self.max_tokens
                            )
                            
                            retry_response_text = retry_response.choices[0].message.content
                            logger.info(f"\n📝 RETRY LLM RESPONSE:")
                            logger.info(f"{retry_response_text}")
                            
                            retry_scores, retry_reason_dict = self.parse_llm_response(retry_response_text)
                            
                            if retry_scores:
                                # Merge retry scores with original scores
                                for product_id, score in retry_scores.items():
                                    score_dict[product_id] = score
                                    retry_score_dict[product_id] = True  # Mark as from retry
                                for product_id, reason_for in retry_reason_dict.items():
                                    reason_dict[product_id] = reason_for
                                logger.info(f"✅ Successfully retrieved {len(retry_scores)} scores from retry")
                                logger.info(f"   Retry scored products: {sorted(list(retry_scores.keys()))}")
                            else:
                                logger.warning(f"⚠️  Retry did not return valid scores")
                                
                        except Exception as e:
                            logger.error(f"❌ Error during retry: {str(e)}")
                    
                    # Re-validate after retry
                    actual_count = len(score_dict)
                    if actual_count < expected_count:
                        still_missing = input_unique_products - set(score_dict.keys())
                        logger.error(f"⚠️  STILL MISSING {len(still_missing)} PRODUCTS AFTER RETRY:")
                        logger.error(f"   Missing IDs: {sorted(list(still_missing))}")
                    else:
                        logger.info(f"✅ ALL PRODUCTS SCORED AFTER RETRY!")
                        
                else:
                    extra = set(score_dict.keys()) - input_unique_products
                    logger.error(f"❌ LLM HALLUCINATED {len(extra)} PRODUCTS:")
                    logger.error(f"   Extra product IDs: {sorted(list(extra))[:10]}{'...' if len(extra) > 10 else ''}")
                    logger.error(f"   These products were NOT in the input but appeared in LLM output!")
                logger.error(f"{'='*80}")
            else:
                logger.info(f"✅ VALIDATION PASSED: All {actual_count} unique products scored correctly")
            logger.info(f"{'='*80}\n")
            
            logger.info(f"\nPARSED LLM SCORES:")
            for product_id, score in sorted(score_dict.items(), key=lambda x: x[1], reverse=True)[:10]:
                source = " (from retry)" if product_id in retry_score_dict else ""
                logger.info(f"  Product {product_id}: LLM Score = {score:.4f}{source}")
            
            # Add LLM scores to results
            for result in results:
                product_id = str(result.get('product_id', result.get('id', '')))
                llm_score = score_dict.get(product_id, 0.0)
                reason_for_llm_response = reason_dict.get(product_id, "")
                result['llm_exact_match_score'] = llm_score
                result['llm_exact_match_reason_for_score'] = reason_for_llm_response
                
                # Store previous score for reference
                if 'rerank_score' in result:
                    result['previous_rerank_score'] = result['rerank_score']
                elif 'score' in result:
                    result['previous_score'] = result['score']
            
            # Sort by LLM exact match score
            results.sort(key=lambda x: x.get('llm_exact_match_score', 0.0), reverse=True)
            
            # Update ranks
            for idx, result in enumerate(results[:top_n], 1):
                result['rank'] = idx
            
            # Log final reranked results
            logger.info(f"\nFINAL RERANKED RESULTS (after LLM reranking):")
            for idx, result in enumerate(results[:10], 1):  # Log top 10
                product_id = result.get('product_id', result.get('id', ''))
                text = (result.get('text') or result.get('description', ''))[:80]
                llm_score = result.get('llm_exact_match_score', 0.0)
                prev_rerank = result.get('previous_rerank_score', None)
                prev_score = result.get('previous_score', result.get('score', 0.0))
                reason_for_the_score = result.get('llm_exact_match_reason_for_score', '')
                
                if prev_rerank is not None:
                    logger.info(f"  Rank {idx}: ID={product_id}, LLM={llm_score:.4f}, PrevRerank={prev_rerank:.4f}, Initial={prev_score:.4f}")
                else:
                    logger.info(f"  Rank {idx}: ID={product_id}, LLM={llm_score:.4f}, PrevScore={prev_score:.4f}")
                logger.info(f"           Text: {text}...")
                logger.info(f"           Reason: {reason_for_the_score}...")
            
            logger.info(f"\n{'='*80}")
            logger.info(f"LLM exact match reranking completed. Top score: {results[0].get('llm_exact_match_score', 0):.3f}")
            logger.info(f"{'='*80}\n")
            return results[:top_n]
            
        except Exception as e:
            logger.error(f"LLM exact match reranking failed: {e}")
            logger.warning("Falling back to previous results")
            return results[:top_n]
    
    def batch_rerank(
        self,
        queries: List[Dict],
        all_results: Dict[str, List[Dict]],
        top_n: Optional[int] = None
    ) -> Dict[str, List[Dict]]:
        """
        Rerank results for multiple queries in batch
        
        Args:
            queries: List of query dictionaries with 'product_id' and 'text'
            all_results: Dictionary mapping query product_id to list of results
            top_n: Number of top results to return per query
            
        Returns:
            Dictionary with reranked results for each query
        """
        reranked_results = {}
        
        for i, query in enumerate(queries):
            if (i + 1) % 10 == 0:
                logger.info(f"LLM reranking query {i + 1}/{len(queries)}")
            
            query_id = query.get('query_row_id', query.get('branded_product_id'))
            query_text = query['text']
            
            if query_id in all_results:
                results = all_results[query_id]
                reranked = self.rerank(query_id, query_text, results, top_n=top_n)
                reranked_results[query_id] = reranked
            else:
                logger.warning(f"No results found for query {query_id}")
                reranked_results[query_id] = []
        
        logger.info(f"Completed LLM exact match reranking for {len(queries)} queries")
        return reranked_results


if __name__ == "__main__":
    # Test the LLM exact match reranker
    logging.basicConfig(level=logging.INFO)
    
    # Sample query and results
    query_id = "Q123"
    query_text = "2 inch bronze ball valve with lever handle"
    
    sample_results = [
        {
            'product_id': 'P001',
            'text': '2 inch bronze ball valve lever operated',
            'score': 0.85,
            'rank': 1
        },
        {
            'product_id': 'P002',
            'text': '3 inch bronze ball valve with handle',
            'score': 0.82,
            'rank': 2
        },
        {
            'product_id': 'P003',
            'text': '2 inch brass ball valve lever handle',
            'score': 0.80,
            'rank': 3
        },
        {
            'product_id': 'P004',
            'text': '2 inch bronze gate valve',
            'score': 0.75,
            'rank': 4
        }
    ]
    
    # Initialize reranker
    reranker = LLMExactMatchReranker()
    
    # Rerank
    reranked_results = reranker.rerank(query_id, query_text, sample_results)
    
    # Print results
    print(f"\nQuery: {query_text}")
    print("\nReranked Results:")
    for result in reranked_results:
        print(f"\nRank {result['rank']}: {result['text']}")
        print(f"  Product ID: {result['product_id']}")
        print(f"  Original Score: {result.get('score', 0):.3f}")
        print(f"  LLM Exact Match Score: {result.get('llm_exact_match_score', 0):.3f}")
